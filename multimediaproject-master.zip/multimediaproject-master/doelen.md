Gezichtsherkenning
=======
 * Oogkleur
 * Meerdere mensen
 * Grootte hoofd
 * Emotie gezicht (mond, wenkbrauw, ogen)
 * Oren herkennen (grootte, uitsteken, vorm)
 * (kleine database van gezichten)
 * **Automatisch aanwezigheid doen voor assistenten enzo**

 ---

 * Gezichten vergelijken
   * Oogkleur
   * Afstand ogen
   * Vorm hoofd
   * Vorm / afstand mond - neus

 ---

### Easter eggs
 * ninja filter *realtime*
 * ninjas verstopt in het plaatje
 * gezicht vervangen door nicolas cage *realtime*
 (Stalkr ?)
