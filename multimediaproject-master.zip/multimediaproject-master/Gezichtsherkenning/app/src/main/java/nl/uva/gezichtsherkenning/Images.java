package nl.uva.gezichtsherkenning;

import android.graphics.Bitmap;
import android.util.Log;

import com.google.android.gms.vision.face.Face;

import java.util.ArrayList;

public class Images {
    public static ArrayList<Bitmap> bitmaps = new ArrayList<>();
    public static ArrayList<String> names = new ArrayList<>();
    public static ArrayList<String> numbers = new ArrayList<>();

    public static void addImage(Bitmap bitmap, Face face) {
        int x = (int) Math.max(face.getPosition().x, 0);
        int y = (int) Math.max(face.getPosition().y, 0);
        int w = (int) (face.getWidth() - (face.getPosition().x - x));
        w = Math.min(w, bitmap.getWidth() - x);
        int h = (int) (face.getHeight() - (face.getPosition().y - y));
        h = Math.min(h, bitmap.getHeight() - y);
        
        Log.d("face", String.format("x: %d; y: %d; w: %d; h: %d", x, y, w, h));

        Bitmap faceBitmap = Bitmap.createBitmap(bitmap, x, y, w, h);
        bitmaps.add(faceBitmap);
    }

    public static void addName(String name) {
        names.add(name);
    }

    public static void addNumber(String number) {
        numbers.add(number);
    }

    public static Bitmap getImage(int pos) {
        return bitmaps.get(pos);
    }

    public static String getName(int pos) {
        return names.get(pos);
    }

    public static String getNumber(int pos) {
        return numbers.get(pos);
    }

}
