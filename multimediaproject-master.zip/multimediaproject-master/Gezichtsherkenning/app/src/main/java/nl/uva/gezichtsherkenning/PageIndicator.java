package nl.uva.gezichtsherkenning;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.widget.ImageView;

public class PageIndicator extends ImageView {
    private int pageCount   = 0;
    private int currentPage = 0;
    Paint smallDotPaint;
    Paint bigDotPaint;

    public PageIndicator(Context context) {
        super(context);
        initPaint();
    }

    public PageIndicator(Context context, AttributeSet attrs) {
        super(context, attrs);
        initPaint();
    }

    public PageIndicator(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        initPaint();
    }

    /* Draw the dots on the view. */
    @Override
    protected void onDraw(Canvas canvas) {
        float spaceBetweenDots  = 30f;
        float smallDotSize      = 6f;
        float bigDotSize        = 12f;

        /* Calculate the position of the left most dot. */
        float leftDot;
        if (this.pageCount % 2 == 0) {
            leftDot = (getWidth() / 2f) - (spaceBetweenDots / 2f) -
                    (((this.pageCount / 2f) - 1) * spaceBetweenDots);
        } else {
            leftDot = (getWidth() / 2f) - ((this.pageCount - 1) * spaceBetweenDots / 2f);
        }

        /* Draw the dots. */
        for(int i = 0; i < pageCount; i++) {
            float x = leftDot + (i * spaceBetweenDots);
            float y = getHeight() / 2f;

            if(this.currentPage == i) {
                canvas.drawCircle(x, y, bigDotSize, bigDotPaint);
            } else {
                canvas.drawCircle(x, y, smallDotSize, smallDotPaint);
            }
        }
    }

    /* Initialize the paint of the small dots and the big dot. */
    private void initPaint() {
        this.smallDotPaint = new Paint();
        this.smallDotPaint.setColor(Color.BLACK);

        this.bigDotPaint = new Paint();
        this.bigDotPaint.setColor(Color.GREEN);
    }

    /* Set the number of pages and redraw the dots. */
    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
        this.currentPage = 0;
        this.invalidate();
    }

    /* Change position of the big dot to the same number as the page and redraw the dots. */
    public void onPageChange(int pageNumber) {
        this.currentPage = pageNumber;
        this.invalidate();
    }

    public int getPage() {
        return currentPage;
    }
}
