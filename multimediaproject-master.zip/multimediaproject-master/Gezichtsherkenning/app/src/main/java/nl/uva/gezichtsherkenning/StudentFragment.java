package nl.uva.gezichtsherkenning;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

public class StudentFragment extends Fragment {

    Bitmap bitmap;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.student_layout, container, false);

        this.bitmap = Images.getImage(this.getArguments().getInt("position"));

        FaceView faceDetectionView = ((FaceView) view.findViewById(R.id.face_view));
        TextView nameText = ((TextView) view.findViewById(R.id.name));
        TextView numberText = ((TextView) view.findViewById(R.id.number));

        faceDetectionView.updateImage(this.bitmap);

        /* USE NEXT TWO LINES TO SET NAME AND STUDENT NUMBER. */
        nameText.setText(Images.getName(this.getArguments().getInt("position")));
        numberText.setText(Images.getNumber(this.getArguments().getInt("position")));

        return view;
    }
}
