package nl.uva.gezichtsherkenning;

import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.face.Face;
import com.google.android.gms.vision.face.FaceDetector;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class MainActivity extends FragmentActivity {

    public static int SOURCE_LOAD   = 1;
    public static int SOURCE_CAMERA = 2;

    ViewPager       pager;
    PageIndicator   indicator;
    PageAdapter     pageAdapter;
    Uri             uriCamera;
    String          cameraPath;

    List<FaceInfo> databaseFaces;
    List<FaceInfo> imageFaces;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.main_layout);

        this.indicator = (PageIndicator)findViewById(R.id.page_indicator);
        this.imageFaces = new LinkedList<FaceInfo>();

        this.pager = (ViewPager)findViewById(R.id.pager);

        /* Set up the listener that is being called when the page that is being displayed changes. */
        pager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrollStateChanged(int state) {}

            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {}

            @Override
            public void onPageSelected(int position) {
                PageIndicator pageIndicator = (PageIndicator)findViewById(R.id.page_indicator);
                pageIndicator.onPageChange(position);
            }
        });

        /* Load the faces */
        loadFaces();
    }

    @Override
    public void onStop() {
        super.onStop();
        saveFaces();
    }

    private void loadFaces() {
        this.databaseFaces = new LinkedList<FaceInfo>();
        try {
            FileInputStream fis = openFileInput("faces.json");
            int size = fis.available();
            byte buffer[] = new byte[size];
            fis.read(buffer, 0, size);
            fis.close();
            String json = new String(buffer, "utf-8");

            JSONObject object = new JSONObject(json);
            JSONArray faces = object.getJSONArray("faces");
            for (int i = 0; i < faces.length(); i++) {
                JSONObject face = faces.getJSONObject(i);

                /* What the ...., JSON library... */
                JSONArray featuresJson = face.getJSONArray("features");
                double[] features = new double[featuresJson.length()];
                for (int j = 0; j < featuresJson.length(); j++)
                    features[j] = featuresJson.getDouble(j);

                JSONArray infoJson = face.getJSONArray("info");
                String[] info = new String[infoJson.length()];
                for (int j = 0; j < infoJson.length(); j++)
                    info[j] = infoJson.getString(j);

                this.databaseFaces.add(new FaceInfo(features, info));
            }
        } catch (IOException | JSONException ex) {
            ex.printStackTrace();
            Toast.makeText(this, "Could not load faces database", Toast.LENGTH_LONG).show();
        }
    }

    private void saveFaces() {
        String json = "";
        try {
            JSONObject object = new JSONObject();
            JSONArray faces = new JSONArray();
            for (FaceInfo face : this.databaseFaces) {
                JSONObject jsonFace = new JSONObject();
                JSONArray features = new JSONArray();
                for (double f : face.features)
                    features.put(f);

                JSONArray info = new JSONArray();
                for (String i : face.info)
                    info.put(i);

                jsonFace.put("features", features);
                jsonFace.put("info", info);
                faces.put(jsonFace);
            }
            object.put("faces", faces);
            json = object.toString(4);
        } catch (JSONException e) {
            Toast.makeText(this, "Could not create faces database", Toast.LENGTH_LONG).show();
            e.printStackTrace();
            return;
        }
        System.out.println(json);

        try {
            FileOutputStream fos = openFileOutput("faces.json", MODE_PRIVATE);
            byte[] buffer = json.getBytes();
            fos.write(buffer, 0, buffer.length);
            fos.close();
            System.out.println("SAVED");
        } catch (IOException e) {
            Toast.makeText(this, "Could not write faces database", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    public void onSave(View view) {
        int page = indicator.getPage();
        final FaceInfo saveFace = this.imageFaces.get(page);
        LayoutInflater inflater = this.getLayoutInflater();
        View popupLayout = inflater.inflate(R.layout.save_popup, null);
        final EditText name = (EditText) popupLayout.findViewById(R.id.name);
        final EditText number = (EditText) popupLayout.findViewById(R.id.number);

        AlertDialog.Builder popup = new AlertDialog.Builder(this);
        popup.setView(popupLayout);
        popup.setTitle(getResources().getString(R.string.save_dialog_title));
        popup.setCancelable(true);
        popup.setNegativeButton(getResources().getString(R.string.close_dialog), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getBaseContext(), "Cancel clicked", Toast.LENGTH_SHORT).show();
            }});

        /* This is the place to put the code to save the data. */
        popup.setPositiveButton(getResources().getString(R.string.save_dialog), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String nameStr = name.getText().toString();
                String numberStr = number.getText().toString();
                saveFace.info[0] = nameStr;
                saveFace.info[1] = numberStr;
                databaseFaces.add(saveFace);
                Toast.makeText(getBaseContext(), "Naam: " + nameStr + " Nummer: " + numberStr, Toast.LENGTH_SHORT).show();
            }});
        AlertDialog dialog = popup.create();
        dialog.show();
    }

    /* Called when Button Load Image is pressed in Main Activity Fragment.
     * Starts a new activity that show the Gallery, so the user
     * can choose an Image. */
    public void onLoadImage(View view) {
        Intent i = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(i, 1);
    }

    /* Called when Button Camera is pressed in Main Activity Fragment.
     * Starts a new activity showing the camera to take a picture. */
    public void onOpenCamera(View view) {
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        uriCamera = getOutputMediaFile();
        i.putExtra(MediaStore.EXTRA_OUTPUT, uriCamera);
        startActivityForResult(i, 2);
    }

    /* This function gets the faces and saves it in the image class. It also creates a fragment for
     * every face it has detected. After that it notifies the page adapter and page indicator, that
     * the data has changed, so these views can update themselves. */
    private void setBitmap(Bitmap bitmap) {
        /* Clear the page adapter and image container and the list of faces. */
        Images.bitmaps.clear();
        Images.names.clear();
        Images.numbers.clear();
        this.imageFaces.clear();

        /* Initialize the page adapter. */
        this.pageAdapter = new PageAdapter(this, getSupportFragmentManager());
        this.pageAdapter.init();

        /* Detect the faces in the bitmap. */
        SparseArray faces = detectFaces(bitmap);

        /* Add images to the array and create new fragments for every face in the bitmap. */
        for (int i = 0; i < faces.size(); i++) {
          /* Send a face and a bitmap to the array of bitmaps.*/
            Images.addImage(bitmap, (Face)faces.valueAt(i));
            String[] string = new String[2];
            FaceInfo faceInfo = new FaceInfo((Face)faces.valueAt(i), string);
            this.imageFaces.add(faceInfo);

            /* Initialize all the fragments for the pager. */
            FaceInfo bestFace = this.searchForPerson(faceInfo);
            Bundle b = new Bundle();
            b.putInt("position", i);

            if(bestFace != null)  {
                Images.addName(bestFace.info[FaceInfo.NAME]);
                Images.addNumber(bestFace.info[FaceInfo.STUDENT_NUMBER]);
            }
            else {
                Images.addName(getString(R.string.unknown_person));
                Images.addNumber(getString(R.string.unknown_id));
            }

            pageAdapter.add(StudentFragment.class, "title", b);
        }

        /* Set the number of pages to the page indicator and notify the page adapter that the
         * data has changed. */
        indicator.setPageCount(pageAdapter.getCount());
        pageAdapter.notifyDataSetChanged();
        this.pager.setAdapter(pageAdapter);

        /* Displays a toast if there was no faces found. */
        if(faces.size() == 0)
            Toast.makeText(getApplicationContext(), getString(R.string.no_face_detected), Toast.LENGTH_LONG).show();
    }

    /* Called when the Camera or Load Activity is finished and has the image
     * data as a param. */
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Bitmap bitmap = null;

        /* Check if the request was cancelled or if there are errors. */
        if(resultCode == RESULT_CANCELED) {
            return;
        } else if (resultCode != RESULT_OK || (requestCode != SOURCE_LOAD && requestCode != SOURCE_CAMERA)) {
            showErrorDialog();
            return;
        }

        /* Check the source and create a bitmap. */
        if (requestCode == SOURCE_LOAD) {
            bitmap = getImageFromUri(data.getData(), getContentResolver());
        } else {
            bitmap = BitmapFactory.decodeFile(cameraPath);
        }

        /* Set the bitmap and update the views with the new data. */
        if (bitmap != null) {
            this.setBitmap(bitmap);
        }

    }

    /* Creates bitmap from File Image Source. */
    public static Bitmap getImageFromUri(Uri image, ContentResolver cr) {
        try {
            /* Get the path to the picture. */
            return MediaStore.Images.Media.getBitmap(cr, image);
        }
        catch (Exception e) {
            Log.d("exception: ", ""+e);
            return null;
        }
    }

    /* Create a Uri with a File for saving an image. */
    private Uri getOutputMediaFile(){
        /* Create the storage directory if it does not exist. */
        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "FaceNinja");
        if (! mediaStorageDir.exists()){
            if (! mediaStorageDir.mkdirs()){
                return null;
            }
        }
        cameraPath = mediaStorageDir.getPath() + File.separator + "IMG_"+ "CAMERA_SOURCE" +  ".jpg";
        return Uri.fromFile(new File(cameraPath));
    }

    public void showErrorDialog() {
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setMessage(R.string.image_load_error)
                .setPositiveButton(R.string.close_dialog, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });
        alert.show();
    }

    /* This functions detects if there are faces in the imageBitmap and returns all the faces
     * in a sparse array. */
    private SparseArray detectFaces(Bitmap bitmap) {
        /* Create the Face Detector. */
        FaceDetector detector = new FaceDetector.Builder(getApplicationContext())
                .setClassificationType(FaceDetector.ALL_CLASSIFICATIONS)
                .setTrackingEnabled(false)
                .build();

        Frame frame = new Frame.Builder().setBitmap(bitmap).build();
        SparseArray faces = detector.detect(frame);
        detector.release();
        return faces;
    }

    private FaceInfo searchForPerson(FaceInfo info) {
        if (this.databaseFaces == null || this.imageFaces.size() == 0 || this.databaseFaces.size() == 0)
            return null;

        FaceInfo currentDatabaseFace;
        FaceInfo mostSimilarFace = null;
        double lowestDeviation = 100000000;
        double prevDev = 0;

        int[][] triCom = {  {FaceInfo.EYE_DISTANCE,FaceInfo.LEFT_EYE_NOSE_DIST,FaceInfo.RIGHT_EYE_NOSE_DIST,3},
                            {FaceInfo.EYE_DISTANCE,FaceInfo.LEFT_EYE_LEFT_CHEEK,FaceInfo.RIGHT_EYE_LEFT_CHEEK,2},
                            {FaceInfo.EYE_DISTANCE,FaceInfo.LEFT_EYE_RIGHT_CHEEK,FaceInfo.RIGHT_EYE_RIGHT_CHEEK,2},
                            {FaceInfo.LEFT_EYE_NOSE_DIST,FaceInfo.LEFT_EYE_LEFT_CHEEK,FaceInfo.LEFT_CHEEK_NOSE_DIST,0},
                            {FaceInfo.RIGHT_EYE_RIGHT_CHEEK,FaceInfo.RIGHT_EYE_NOSE_DIST,FaceInfo.RIGHT_CHEEK_NOSE_DIST,0},
                            {FaceInfo.CHEEK_DISTANCE,FaceInfo.LEFT_CHEEK_NOSE_DIST,FaceInfo.RIGHT_CHEEK_NOSE_DIST,1},
                            {FaceInfo.RIGHT_EYE_LEFT_CHEEK,FaceInfo.LEFT_CHEEK_NOSE_DIST,FaceInfo.RIGHT_EYE_NOSE_DIST,0},
                            {FaceInfo.LEFT_EYE_NOSE_DIST,FaceInfo.LEFT_EYE_RIGHT_CHEEK,FaceInfo.RIGHT_CHEEK_NOSE_DIST,0},
                            {FaceInfo.LEFT_EYE_RIGHT_CHEEK,FaceInfo.LEFT_EYE_LEFT_CHEEK,FaceInfo.CHEEK_DISTANCE,2},
                            {FaceInfo.RIGHT_EYE_LEFT_CHEEK,FaceInfo.RIGHT_EYE_RIGHT_CHEEK,FaceInfo.CHEEK_DISTANCE,2},
                            {FaceInfo.MOUTH_DIST,FaceInfo.LEFT_EYE_LEFT_MOUTH_DIST,FaceInfo.LEFT_EYE_RIGHT_MOUTH_DIST,0},
                            {FaceInfo.MOUTH_DIST,FaceInfo.RIGHT_EYE_RIGHT_MOUTH_DIST,FaceInfo.RIGHT_EYE_LEFT_MOUTH_DIST,0},
                            {FaceInfo.MOUTH_DIST,FaceInfo.NOSE_LEFT_MOUTH_DIST,FaceInfo.NOSE_RIGHT_MOUTH_DIST,0},
                            {FaceInfo.MOUTH_DIST,FaceInfo.LEFT_CHEEK_LEFT_MOUTH_DIST,FaceInfo.LEFT_CHEEK_RIGHT_MOUTH_DIST,0},
                            {FaceInfo.MOUTH_DIST,FaceInfo.RIGHT_CHEEK_LEFT_MOUTH_DIST,FaceInfo.RIGHT_CHEEK_LEFT_MOUTH_DIST,0},
                            {FaceInfo.MOUTH_DIST,FaceInfo.BOT_MOUTH_LEFT_MOUTH_DIST,FaceInfo.BOT_MOUTH_RIGHT_MOUTH_DIST,0},
                            {FaceInfo.BOT_MOUTH_RIGHT_MOUTH_DIST,FaceInfo.LEFT_EYE_BOT_MOUTH_DIST,FaceInfo.LEFT_EYE_RIGHT_MOUTH_DIST,0},
                            {FaceInfo.BOT_MOUTH_RIGHT_MOUTH_DIST,FaceInfo.RIGHT_EYE_RIGHT_MOUTH_DIST,FaceInfo.RIGHT_EYE_BOT_MOUTH_DIST,0},
                            {FaceInfo.BOT_MOUTH_RIGHT_MOUTH_DIST,FaceInfo.LEFT_CHEEK_BOT_MOUTH_DIST,FaceInfo.LEFT_CHEEK_RIGHT_MOUTH_DIST,0},
                            {FaceInfo.BOT_MOUTH_RIGHT_MOUTH_DIST,FaceInfo.RIGHT_CHEEK_BOT_MOUTH_DIST,FaceInfo.RIGHT_CHEEK_RIGHT_MOUTH_DIST,0},
                            {FaceInfo.BOT_MOUTH_RIGHT_MOUTH_DIST,FaceInfo.NOSE_RIGHT_MOUTH_DIST,FaceInfo.NOSE_BOT_MOUTH_DIST,0},
                            {FaceInfo.BOT_MOUTH_LEFT_MOUTH_DIST,FaceInfo.LEFT_EYE_BOT_MOUTH_DIST,FaceInfo.LEFT_EYE_LEFT_MOUTH_DIST,0},
                            {FaceInfo.BOT_MOUTH_LEFT_MOUTH_DIST,FaceInfo.RIGHT_EYE_LEFT_MOUTH_DIST,FaceInfo.RIGHT_EYE_BOT_MOUTH_DIST,0},
                            {FaceInfo.BOT_MOUTH_LEFT_MOUTH_DIST,FaceInfo.LEFT_CHEEK_BOT_MOUTH_DIST,FaceInfo.LEFT_CHEEK_LEFT_MOUTH_DIST,0},
                            {FaceInfo.BOT_MOUTH_LEFT_MOUTH_DIST,FaceInfo.RIGHT_CHEEK_BOT_MOUTH_DIST,FaceInfo.RIGHT_CHEEK_LEFT_MOUTH_DIST,0},
                            {FaceInfo.BOT_MOUTH_LEFT_MOUTH_DIST,FaceInfo.NOSE_LEFT_MOUTH_DIST,FaceInfo.NOSE_BOT_MOUTH_DIST,0}};

        for(int i = 0; i < this.databaseFaces.size(); i++) {
            currentDatabaseFace = this.databaseFaces.get(i);
            double dev = 0;

            for (int j=0; j < triCom.length; j++) {
                if (info.features[triCom[j][0]] != 0 && info.features[triCom[j][1]] != 0 && info.features[triCom[j][2]] != 0) {
                    dev += triangle(info.features[triCom[j][0]], info.features[triCom[j][1]], info.features[triCom[j][2]],
                                    currentDatabaseFace.features[triCom[j][0]],
                                    currentDatabaseFace.features[triCom[j][1]],
                                    currentDatabaseFace.features[triCom[j][2]], triCom[j][3]);
                }
            }

            Log.d("devation", " id = " + currentDatabaseFace.info[FaceInfo.NAME] + " dev = " + dev);

            if(dev < lowestDeviation) {
                prevDev = lowestDeviation;
                lowestDeviation = dev;
                mostSimilarFace = currentDatabaseFace;
            }
        }

        if (lowestDeviation < 20 && (lowestDeviation*1.3 < prevDev && prevDev != 0)) {
            return mostSimilarFace;
        }
        else {
            Toast.makeText(this, R.string.no_face_recognized, Toast.LENGTH_LONG).show();
            return null;
        }
    }

    public double triangle(double a, double b, double c, double aa, double bb, double cc, double priority) {
        double dif1 = aa / a;
        double dif2 = bb / b;
        double dif3 = cc / c;
        double avg = (dif1 + dif2 + dif3) / 3.0;
        return (Math.abs(dif1 - avg) + Math.abs(dif2 - avg) + Math.abs(dif3 - avg))*(1+(2.2*(0.55*(priority*0.7))));
    }
}
