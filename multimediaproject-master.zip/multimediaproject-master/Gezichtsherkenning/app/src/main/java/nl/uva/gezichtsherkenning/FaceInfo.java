package nl.uva.gezichtsherkenning;

import android.graphics.PointF;
import android.util.Log;

import com.google.android.gms.vision.face.Face;
import com.google.android.gms.vision.face.Landmark;

import java.util.List;

public class FaceInfo {
    /* constants */
    public static final int EYE_DISTANCE = 0;
    public static final int CHEEK_DISTANCE = 1;
    public static final int RIGHT_EYE_NOSE_ANGLE = 2;
    public static final int LEFT_EYE_NOSE_ANGLE = 3;
    public static final int RIGHT_EYE_NOSE_DIST = 4;
    public static final int LEFT_EYE_NOSE_DIST = 5;
    public static final int RIGHT_EYE_RIGHT_CHEEK = 6;
    public static final int RIGHT_EYE_LEFT_CHEEK = 7;
    public static final int LEFT_EYE_RIGHT_CHEEK = 8;
    public static final int LEFT_EYE_LEFT_CHEEK = 9;
    public static final int RIGHT_CHEEK_NOSE_DIST = 10;
    public static final int LEFT_CHEEK_NOSE_DIST = 11;
    public static final int LEFT_CHEEK_RIGHT_MOUTH_DIST = 12;
    public static final int LEFT_CHEEK_LEFT_MOUTH_DIST = 13;
    public static final int LEFT_CHEEK_BOT_MOUTH_DIST = 14;
    public static final int RIGHT_CHEEK_RIGHT_MOUTH_DIST = 15;
    public static final int RIGHT_CHEEK_LEFT_MOUTH_DIST = 16;
    public static final int RIGHT_CHEEK_BOT_MOUTH_DIST = 17;
    public static final int NOSE_RIGHT_MOUTH_DIST = 18;
    public static final int NOSE_LEFT_MOUTH_DIST = 19;
    public static final int NOSE_BOT_MOUTH_DIST = 20;
    public static final int LEFT_EYE_LEFT_MOUTH_DIST = 21;
    public static final int LEFT_EYE_RIGHT_MOUTH_DIST = 22;
    public static final int LEFT_EYE_BOT_MOUTH_DIST = 23;
    public static final int RIGHT_EYE_BOT_MOUTH_DIST = 24;
    public static final int RIGHT_EYE_LEFT_MOUTH_DIST = 25;
    public static final int RIGHT_EYE_RIGHT_MOUTH_DIST = 26;
    public static final int BOT_MOUTH_RIGHT_MOUTH_DIST = 27;
    public static final int BOT_MOUTH_LEFT_MOUTH_DIST = 28;
    public static final int MOUTH_DIST = 29;

    public static final int NAME = 0;
    public static final int STUDENT_NUMBER = 1;

    List<Landmark> landmarks;
    public double[] features = new double[30];
    String[] info = new String[2];

    public FaceInfo(Face face, String[] info) {
        this.landmarks = face.getLandmarks();
        this.info = info;
        calcFeatures();
    }

    public FaceInfo(double[] features, String[] info) {
        this.features = features;
        this.info = info;
    }

    /* calculate pythagoras */
    private double pythagoras(float x, float y) {
        double result;
        result = Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));
        return result;
    }

    private double angle(PointF u, PointF v, PointF p) {
        double angle;
        /* transform points to (0,0) */
        PointF transPointV = new PointF();
        transPointV.x = v.x - p.x;
        transPointV.y = v.y - p.y;

        PointF transPointU = new PointF();
        transPointU.x = u.x - p.x;
        transPointU.y = u.y - p.y;

        /* calculate angle */
        PointF projection = projection(transPointU, transPointV);
        double projDist = pythagoras((p.x - projection.x), (p.y - projection.y));
        double noseEye = pythagoras((p.x - v.x), (p.y - v.y));
        angle = Math.cos((projDist / noseEye));

        return angle;
    }

    private PointF projection(PointF u, PointF v) {
        double scalar = ((u.x * v.x) + (u.y * v.y)) / (Math.pow(u.x, 2) + Math.pow(u.y, 2));
        PointF newPoint = new PointF();
        newPoint.x = (float) (u.x * scalar);
        newPoint.y = (float) (u.y * scalar);
        return newPoint;
    }

    private void calcFeatures() {
        PointF leftEye = null;
        PointF rightEye = null;
        PointF leftCheek = null;
        PointF rightCheek = null;
        PointF nose = null;
        PointF bottomMouth = null;
        PointF leftMouth = null;
        PointF rightMouth = null;

        double eyeDistance = 0;
        double cheekDistance = 0;
        double rightEyeNoseDist = 0;
        double leftEyeNoseDist = 0;
        double rightEyeRightCheek = 0;
        double rightEyeLeftCheek = 0;
        double leftEyeLeftCheek = 0;
        double leftEyeRightCheek = 0;
        double leftCheekNoseDist = 0;
        double rightCheekNoseDist = 0;
        double botMouthLeftEyeDist = 0;
        double botMouthRightEyeDist = 0;
        double botMouthLeftCheekDist = 0;
        double botMouthRightCheekDist = 0;
        double botMouthNoseDist = 0;
        double botMouthRightMouthDist = 0;
        double botMouthLeftMouthDist = 0;
        double leftMouthLeftEyeDist = 0;
        double leftMouthRightEyeDist = 0;
        double leftMouthLeftCheekDist = 0;
        double leftMouthRightCheekDist = 0;
        double leftMouthNoseDist = 0;
        double leftMouthRightMouthDist = 0;
        double rightMouthRightEyeDist = 0;
        double rightMouthLeftEyeDist = 0;
        double rightMouthLeftCheekDist = 0;
        double rightMouthRightCheekDist = 0;
        double rightMouthNoseDist = 0;

        for (int i=0; i < features.length; i++) {
            features[i] = 0;
        }

        for (Landmark lm : landmarks) {
            switch (lm.getType()) {
                case Landmark.LEFT_EYE: leftEye = lm.getPosition(); break;
                case Landmark.RIGHT_EYE: rightEye = lm.getPosition(); break;
                case Landmark.LEFT_CHEEK: leftCheek = lm.getPosition(); break;
                case Landmark.RIGHT_CHEEK: rightCheek = lm.getPosition(); break;
                case Landmark.NOSE_BASE: nose = lm.getPosition(); break;
                case Landmark.BOTTOM_MOUTH: bottomMouth = lm.getPosition(); break;
                case Landmark.LEFT_MOUTH: leftMouth = lm.getPosition(); break;
                case Landmark.RIGHT_MOUTH: rightMouth = lm.getPosition(); break;
            }
        }
        if (rightEye != null && leftEye != null && rightCheek != null && leftCheek != null && nose != null) {
            /* calculate eyedistance */
//            Log.d("RightEye", rightEye.x + ", " + rightEye.y);
//            Log.d("LeftEye", leftEye.x + ", " + leftEye.y);
//            Log.d("Nose", nose.x + ", " + nose.y);
            eyeDistance = pythagoras((rightEye.x - leftEye.x), (rightEye.y - leftEye.y));
            this.features[EYE_DISTANCE] = eyeDistance;

            /* calculate cheekdistance */
            cheekDistance = pythagoras((rightCheek.x - leftCheek.x), (rightCheek.y - leftCheek.y));
            this.features[CHEEK_DISTANCE] = cheekDistance;

            /* calculate distance right eye to bottom nose */
            rightEyeNoseDist = pythagoras((rightEye.x - nose.x), (rightEye.y - nose.y));
            this.features[RIGHT_EYE_NOSE_DIST] = rightEyeNoseDist;

            /* calculate distance left eye to bottom nose */
            leftEyeNoseDist = pythagoras((leftEye.x - nose.x), (leftEye.y - nose.y));
            this.features[LEFT_EYE_NOSE_DIST] = leftEyeNoseDist;

            /* calculate  distance right eye to right cheek */
            rightEyeRightCheek = pythagoras((rightEye.x - rightCheek.x), (rightEye.y - rightCheek.y));
            this.features[RIGHT_EYE_RIGHT_CHEEK] = rightEyeRightCheek;

            /* calculate distance right eye to left cheek */
            rightEyeLeftCheek = pythagoras((rightEye.x - leftCheek.x), (rightEye.y - leftCheek.y));
            this.features[RIGHT_EYE_LEFT_CHEEK] = rightEyeLeftCheek;

            /* calculate distance left eye to left cheek */
            leftEyeLeftCheek = pythagoras((leftEye.x - leftCheek.x), (leftEye.y - leftCheek.y));
            this.features[LEFT_EYE_LEFT_CHEEK] = leftEyeLeftCheek;

            /* calculate distance left eye to right cheek */
            leftEyeRightCheek = pythagoras((leftEye.x - rightCheek.x), (leftEye.y - rightCheek.y));
            this.features[LEFT_EYE_RIGHT_CHEEK] = leftEyeRightCheek;

            /* calculate distance left cheek to nose */
            leftCheekNoseDist = pythagoras((leftCheek.x - nose.x), (leftCheek.y - nose.y));
            this.features[LEFT_CHEEK_NOSE_DIST] = leftCheekNoseDist;

            /* calculate distance right cheek to nose */
            rightCheekNoseDist = pythagoras((rightCheek.x - nose.x), (rightCheek.y - nose.y));
            this.features[RIGHT_CHEEK_NOSE_DIST] = rightCheekNoseDist;
            /* ----------------------- */

            if (bottomMouth != null) {
                botMouthLeftEyeDist = pythagoras((bottomMouth.x - leftEye.x), (bottomMouth.y - leftEye.y));
                this.features[LEFT_EYE_BOT_MOUTH_DIST] = botMouthLeftEyeDist;

                botMouthRightEyeDist = pythagoras((bottomMouth.x - rightEye.x), (bottomMouth.y - rightEye.y));
                this.features[RIGHT_EYE_BOT_MOUTH_DIST] = botMouthRightEyeDist;

                botMouthLeftCheekDist = pythagoras((bottomMouth.x - leftCheek.x), (bottomMouth.y - leftCheek.y));
                this.features[LEFT_CHEEK_BOT_MOUTH_DIST] = botMouthLeftCheekDist;

                botMouthRightCheekDist = pythagoras((bottomMouth.x - rightCheek.x), (bottomMouth.y - rightCheek.y));
                this.features[RIGHT_CHEEK_BOT_MOUTH_DIST] = botMouthRightCheekDist;

                botMouthNoseDist = pythagoras((bottomMouth.x - nose.x), (bottomMouth.y - nose.y));
                this.features[NOSE_BOT_MOUTH_DIST] = botMouthNoseDist;

                if (rightMouth != null) {
                    botMouthRightMouthDist = pythagoras((bottomMouth.x - rightMouth.x), (bottomMouth.y - rightMouth.y));
                    this.features[BOT_MOUTH_RIGHT_MOUTH_DIST] = botMouthRightMouthDist;
                }
                if (leftMouth != null) {
                    botMouthLeftMouthDist = pythagoras((bottomMouth.x - leftMouth.x), (bottomMouth.y - leftMouth.y));
                    this.features[BOT_MOUTH_LEFT_MOUTH_DIST] = botMouthLeftMouthDist;
                }
            }
            /* ------------------------ */

            if (leftMouth != null) {
                leftMouthLeftEyeDist = pythagoras((leftMouth.x - leftEye.x), (leftMouth.y - leftEye.y));
                this.features[LEFT_EYE_LEFT_MOUTH_DIST] = leftMouthLeftEyeDist;

                leftMouthRightEyeDist = pythagoras((leftMouth.x - rightEye.x), (leftMouth.y - rightEye.y));
                this.features[RIGHT_EYE_LEFT_MOUTH_DIST] = leftMouthRightEyeDist;

                leftMouthLeftCheekDist = pythagoras((leftMouth.x - leftCheek.x), (leftMouth.y - leftCheek.y));
                this.features[LEFT_CHEEK_LEFT_MOUTH_DIST] = leftMouthLeftCheekDist;

                leftMouthRightCheekDist = pythagoras((leftMouth.x - rightCheek.x), (leftMouth.y - rightCheek.y));
                this.features[RIGHT_CHEEK_LEFT_MOUTH_DIST] = leftMouthRightCheekDist;

                leftMouthNoseDist = pythagoras((leftMouth.x - nose.x), (leftMouth.y - nose.y));
                this.features[NOSE_LEFT_MOUTH_DIST] = leftMouthNoseDist;

                if (rightMouth != null) {
                    leftMouthRightMouthDist = pythagoras((leftMouth.x - rightMouth.x), (leftMouth.y - rightMouth.y));
                    this.features[MOUTH_DIST] = leftMouthRightMouthDist;
                }
            }
            /* ----------------------- */

            if (rightMouth != null) {
                rightMouthRightEyeDist = pythagoras((rightMouth.x - rightEye.x), (rightMouth.y - rightEye.y));
                this.features[RIGHT_EYE_RIGHT_MOUTH_DIST] = rightMouthRightEyeDist;

                rightMouthLeftEyeDist = pythagoras((rightMouth.x - leftEye.x), (rightMouth.y - leftEye.y));
                this.features[LEFT_EYE_RIGHT_MOUTH_DIST] = rightMouthLeftEyeDist;

                rightMouthLeftCheekDist = pythagoras((rightMouth.x - leftCheek.x), (rightMouth.y - leftCheek.y));
                this.features[LEFT_CHEEK_RIGHT_MOUTH_DIST] = rightMouthLeftCheekDist;

                rightMouthRightCheekDist = pythagoras((rightMouth.x - rightCheek.x), (rightMouth.y - rightCheek.y));
                this.features[RIGHT_CHEEK_RIGHT_MOUTH_DIST] = rightMouthRightCheekDist;

                rightMouthNoseDist = pythagoras((rightMouth.x - nose.x), (rightMouth.y - nose.y));
                this.features[NOSE_RIGHT_MOUTH_DIST] = rightMouthNoseDist;
            }
        }
    }
}
