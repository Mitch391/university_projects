package nl.uva.gezichtsherkenning;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PointF;
import android.util.AttributeSet;
import android.widget.ImageView;

public class FaceView extends ImageView {

    private Bitmap bitmap;

    public FaceView(Context context) {
        super(context);
    }

    public FaceView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public FaceView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    public void updateImage(Bitmap bitmap) {
        this.bitmap = bitmap;
        this.invalidate();
    }

    @Override
    public void onDraw(Canvas canvas) {
        if (this.bitmap != null) {
            float bmWidth = bitmap.getWidth();
            float bmHeight = bitmap.getHeight();
            float cvWidth = canvas.getWidth();
            float cvHeight = canvas.getHeight();

            PointF newScales = getNewRes(bmWidth, bmHeight, cvWidth, cvHeight);

            Bitmap newBitmap = Bitmap.createScaledBitmap(bitmap, (int)newScales.x, (int)newScales.y, true);
            
            int startX = (int)((cvWidth/2) - (newScales.x/2));
            int startY = (int)((cvHeight/2) - (newScales.y/2));
            canvas.drawBitmap(newBitmap, startX, startY, null);
        }
    }

    public PointF getNewRes(float bmWidth, float bmHeight, float cvWidth, float cvHeight) {
        PointF result = new PointF();
        float newWidth, newHeight;
        float bmScale = bmWidth / bmHeight;

        if (bmWidth > cvWidth && bmHeight > cvHeight) {
            if (bmWidth/cvWidth > bmHeight/cvHeight) {
                newWidth = cvWidth;
                newHeight = (newWidth / bmScale);
            } else {
                newHeight = cvHeight;
                newWidth = (newHeight * bmScale);
            }
        } else if (bmWidth > cvWidth) {
            newWidth = cvWidth;
            newHeight = (newWidth / bmScale);
        } else if (bmHeight > cvHeight) {
            newHeight = cvHeight;
            newWidth = (newHeight * bmScale);
        } else {
            newWidth = bmWidth;
            newHeight = bmHeight;
        }

        result.set(newWidth, newHeight);
        return result;
    }
}
