package nl.uva.gezichtsherkenning;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class PageAdapter extends FragmentPagerAdapter {
    public static int pos = 0;

    private List<Fragment> fragments;
    private ArrayList<String> students;
    private Context context;

    public PageAdapter(Context c, FragmentManager fragmentManager) {
        super(fragmentManager);
        this.context = c;
    }

    public void init() {
        this.fragments = new ArrayList<>();
        this.students = new ArrayList<>();
    }

    public void reset() {
        this.fragments.clear();
        this.students.clear();
    }

    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public int getCount() {
        return fragments.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        setPos(position);
        return students.get(position);
    }

    public static int getPos() {
        return pos;
    }

    public void add(Class<StudentFragment> c, String title, Bundle b) {
        fragments.add(Fragment.instantiate(context, c.getName(), b));
        students.add(title);
    }

    public static void setPos(int pos) {
        PageAdapter.pos = pos;
    }
}
