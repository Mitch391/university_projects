from django.apps import AppConfig


class StudieplanConfig(AppConfig):
    name = 'studieplan'
