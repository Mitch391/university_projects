from django.http import HttpResponse, HttpResponseForbidden, \
        HttpResponseNotAllowed
from django.template import loader
from django.contrib.auth import authenticate, login, logout
from django.shortcuts import redirect
from django.urls import reverse


def redirect_main():
    """
    Redirects to main page.
    """
    return redirect(reverse('main:index'))


def redirect_error(request):
    """
    Redirects to login page with error message.
    """
    response = redirect(reverse('login:index'))
    response['Location'] += '?error=1&next=' + request.POST['next'] \
        if 'next' in request.POST else ''
    return response


def login_auth(request):
    """
    Log the user in based on the data submitted with the POST request.
    """
    if request.user.is_authenticated:
        return HttpResponseForbidden()

    if 'uvanetid' not in request.POST or 'password' not in request.POST:
        return redirect_error(request)

    uvanetid = request.POST['uvanetid']
    password = request.POST['password']
    user = authenticate(username=uvanetid, password=password)

    if user is None:
        return redirect_error(request)

    login(request, user)
    return redirect(
        request.POST['next'] if 'next' in request.POST
        else reverse('main:index'))


def login_view(request):
    """
    Renders the view of the login page. If already logged in, simply logout.
    Also, redirect to the page where the user came from if he was redirected
    upon visiting a page requiring authentication.
    """
    if request.user.is_authenticated:
        logout(request)  # for Django version < 1.8
        request.session.flush()
        return redirect_main()

    template = loader.get_template('login.html')
    next_url = request.GET['next'] if 'next' in request.GET \
        else reverse('main:index')
    error = request.GET['error'] if 'error' in request.GET else None
    return HttpResponse(template.render(
        {'next': next_url, 'error': error}, request))


def index(request):
    """
    Entry point for login page.
    """
    if request.method == 'POST':
        return login_auth(request)
    elif request.method == 'GET':
        return login_view(request)
    return HttpResponseNotAllowed()
