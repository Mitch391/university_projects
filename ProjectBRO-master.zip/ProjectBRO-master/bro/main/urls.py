from django.contrib.auth.decorators import login_required
from django.conf.urls import url
from . import views

app_name = 'main'

urlpatterns = [
    url(r'^$', login_required(views.index), name="index"),
]
