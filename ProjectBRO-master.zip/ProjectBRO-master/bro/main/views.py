from django.http import HttpResponse
from django.template import loader
from django.urls import reverse

from studieplan.models import AcademicPlan
from persoonsgegevens.models import PersonalData
from vakbeheer.models import CourseInstance, CourseToAssistant, \
    CourseToStudent, CourseToLecturer, Announcement

MAX_ANNOUNCEMENTS = 5


def index(request):
    """
    Loads connected courses in Dashboard for each different user.
    """
    template = loader.get_template("dashboard.html")
    uvanetid = request.user.username
    args = dict()

    args['as_ta'] = list()
    for c in CourseToAssistant.objects.filter(assistant=uvanetid):
        args['as_ta'].append({
            'url': reverse('course_management:course', args=[c.course.id]),
            'name': c.course
        })

    args['as_student'] = list()
    for c in CourseToStudent.objects.filter(student=uvanetid):
        args['as_student'].append({
            'url': reverse('course_management:course', args=[c.course.id]),
            'name': c.course
        })

    args['as_coord'] = list()
    for c in CourseInstance.objects.filter(
            template__coordinator__uvanetid=uvanetid):
        args['as_coord'].append({
            'url': reverse('course_management:course', args=[c.id]),
            'name': c
        })

    args['as_adv'] = list()
    for p in PersonalData.objects.filter(
            user__groups__name__in=['Student'],
            academicplan__study__template__advisor=uvanetid).distinct():
        args['as_adv'].append({
            'url': reverse('personal_data:index_ext', args=[p.uvanetid]),
            'name': str(p)
        })

    args['as_lec'] = list()
    for c in CourseToLecturer.objects.filter(uvanetid=uvanetid):
        args['as_lec'].append({
            'url': reverse('course_management:course', args=[c.course.id]),
            'name': c.course
        })

    args['acad_plans'] = list()
    for a in AcademicPlan.objects.filter(student__uvanetid=uvanetid):
        args['acad_plans'].append({
            'url': reverse('academic_plan:index_id', args=[a.id]),
            'name': a.study.template.name
        })

    """
    Loads connected announcements in Dashboard for each course for each different user.
    """
    s_announcements = Announcement.objects.filter(
            course__id__in=CourseToStudent.objects.filter(
                student__user=request.user).values('id'))
    args['s_announcements'] = s_announcements[:min(
        len(s_announcements), MAX_ANNOUNCEMENTS)]

    d_announcements = Announcement.objects.filter(
        course__id__in=CourseToLecturer.objects.filter(
            uvanetid__user=request.user).values('id'))
    args['d_announcements'] = d_announcements[:min(
        len(d_announcements), MAX_ANNOUNCEMENTS)]

    ta_announcements = Announcement.objects.filter(
            course__id__in=CourseToAssistant.objects.filter(
                assistant_id__user=request.user).values('id'))
    args['ta_announcements'] = ta_announcements[:min(
        len(ta_announcements), MAX_ANNOUNCEMENTS)]

    co_announcements = Announcement.objects.filter(
        course__id__in=CourseInstance.objects.all().values('id'))
    args['co_announcements'] = co_announcements[:min(
        len(co_announcements), MAX_ANNOUNCEMENTS)]

    return HttpResponse(template.render(args, request))
