from json import dumps

from django.apps import apps
from django import forms
from django.core.serializers import serialize
from django.core.urlresolvers import reverse_lazy, reverse
from django.forms.models import model_to_dict
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, get_object_or_404
from django.template import loader
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.views.generic.list import ListView

from .forms import CourseTemplateForm, CourseRegReqTemplateForm, CourseRegReqGroupFormSet,\
    CourseRegReqFormSet, StudyToCourseFormSet
from .models import CourseTemplate, CourseRegReqGroup, CourseRegReqTemplate


def index(request):
    """
    Load index page for course setup.
    """
    template = loader.get_template('vakopbouw.html')
    return HttpResponse(template.render({}, request))


def return_form(request, mainform, finalformset, formset, studyformset):
    req_template_list = CourseRegReqTemplate.objects.all()
    return render(request, 'vakopbouw/coursetemplate_form.html',
                  {'mainform': mainform, 'formset': finalformset,
                   'formsetmanagement': formset, 'temps': req_template_list,
                   'studyformset': studyformset})


def study_add_formset(request, course):
    copy = request.POST.copy()
    copy['study-TOTAL_FORMS'] = int(copy['study-TOTAL_FORMS']) + 1
    return StudyToCourseFormSet(copy, prefix='study', instance=course)


def CourseTemplateCreate(request):
    """
    Create a new course template including default data about the course and
    the registration requirements.
    """
    # Create the main form
    mainform = CourseTemplateForm()
    maininstance = CourseTemplate()

    # Create a formset for the linked studies
    studyformset = StudyToCourseFormSet(instance=maininstance, prefix='study')

    # Create a formset for registration requirement groups and link it to
    # the instance of the course template.
    formset = CourseRegReqGroupFormSet(instance=maininstance)

    # For every form in the formset create a subformset for the actual
    # registration requirements per group.
    subformsets = []
    for i in range(len(formset)):
        forminstance = CourseRegReqGroup()
        subformsets.append(CourseRegReqFormSet(instance=forminstance,
                                               prefix=str(i)))

    # Here the form is validated and submitted if valid.
    if request.method == 'POST':
        # Autofill end_period if it is empty.
        post = request.POST.copy()
        if post['end_period'] == '':
            post['end_period'] = post['start_period']
            # Create a form for the course template using the post data.
        mainform = CourseTemplateForm(post)

        # If the form is valid save the course template to the database.
        # Else return the form showing the errors.
        if mainform.is_valid():
            mainforminstance = mainform.save()
            # Create a formset for the registration requirement groups using
            # the post data. and link it to the course template.
            formset = CourseRegReqGroupFormSet(
                request.POST, instance=mainforminstance)
            studyformset = StudyToCourseFormSet(
                request.POST, instance=mainforminstance, prefix='study')
            # If the form is valid save the registration requirement groups to
            # the database. Else return the form showing the errors.
            if formset.is_valid() and studyformset.is_valid():
                studyformset.save()
                mainforminstance.generate_course_id()

                forminstances = formset.save()

                # For every registration requirement group create a subformset
                # for the corresponding registration requirements. Use a
                # counter as prefix to determine which requirements belong to
                # which group.
                i = 0
                subformsets = []
                valid = True
                for inst in forminstances:
                    subformsets.append(CourseRegReqFormSet(
                        request.POST, instance=inst, prefix=str(i)))

                    # check if all subforms are valid.
                    valid &= subformsets[i].is_valid()
                    i += 1

                # If all subforms are valid save the registration requirements
                # to the database. Else return the form showing the errors.
                if valid:
                    for subformset in subformsets:
                        subformset.save()

                    return HttpResponseRedirect(
                        reverse('course_setup:index'))

                else:
                    mainforminstance.delete()
                    finalformset = zip(formset, subformsets)
                    return return_form(request, mainform, finalformset,
                                       formset, studyformset)
            else:
                mainforminstance.delete()
                finalformset = zip(formset, subformsets)
                return return_form(request, mainform, finalformset,
                                   formset, studyformset)

        else:
            finalformset = zip(formset, subformsets)
            return return_form(request, mainform, finalformset,
                               formset, studyformset)

    # Here the formset reaches its final form. This is needed to be able to
    # loop through the formset and the list of subformsets at the same time in
    # the template.
    finalformset = zip(formset, subformsets)
    return return_form(request, mainform, finalformset, formset, studyformset)


def CourseTemplateUpdate(request, pk):
    """
    Update an existing course template including default data about the course
    and the registration requirements.
    """
    # Find the coursetemplate in the database
    coursetemp = get_object_or_404(CourseTemplate, pk=pk)

    # Create the form and formset based on the information in the database.
    mainform = CourseTemplateForm(instance=coursetemp)
    formset = CourseRegReqGroupFormSet(instance=coursetemp)
    studyformset = StudyToCourseFormSet(instance=coursetemp, prefix='study')

    # For every group in the database create a formset with all the
    # registration requirements for this group in the database.
    forminstances = CourseRegReqGroup.objects.\
            filter(course_template=coursetemp)

    subformsets = []
    for i, instance in enumerate(forminstances):
        subformsets.append(CourseRegReqFormSet(
            instance=instance, prefix=str(i)))

        # Here the form is validated and submitted if valid.
    if request.method == 'POST':
        # Autofill end_period if it is empty.
            post = request.POST.copy()
            if post['end_period'] == '':
                post['end_period'] = post['start_period']
            # Create a form for the course template using the post data and link
            # it to the already existing course template.
            mainform = CourseTemplateForm(post, instance=coursetemp)

            # If the form is valid save the course template to the database.
            # Else return the form showing the errors.
            if mainform.is_valid():
                coursetemp = mainform.save()

                # Create a formset for the registration requirement groups using
                # the post data and link it to the course template.
                formset = CourseRegReqGroupFormSet(request.POST,
                                                   instance=coursetemp)
                studyformset = StudyToCourseFormSet(request.POST,
                                                    instance=coursetemp,
                                                    prefix='study')

                # If the form is valid save the registration requirement groups to
                # the database. Else return the form showing the errors.
                if formset.is_valid() and studyformset.is_valid():
                    studyformset.save()
                    coursetemp.generate_course_id()

                    formset.save()

                    # For every registration requirement group create a subformset
                    # for the corresponding registration requirements. Use a
                    # counter as prefix to determine which requirements belong to
                    # which group. Retrieve groups again from the database in case
                    # some of them weren't edited.
                    forminstances = CourseRegReqGroup.objects.\
                        filter(course_template=coursetemp)

                    i = 0
                    subformsets = []
                    valid = True
                    for inst in forminstances:
                        subformsets.append(CourseRegReqFormSet(
                            request.POST, instance=inst, prefix=str(i)))

                        # check if all subforms are valid.
                        valid &= subformsets[i].is_valid()
                        i += 1

                    # If all subforms are valid save the registration requirements
                    # To the database. Else return the form showing the errors.
                    if valid:
                        for subformset in subformsets:
                            subformset.save()
                        return HttpResponseRedirect(reverse('course_setup:index'))
                    else:
                        finalformset = zip(formset, subformsets)
                        return return_form(request, mainform, finalformset, formset, studyformset)

                else:
                    finalformset = zip(formset, subformsets)
                    return return_form(request, mainform, finalformset, formset, studyformset)
            else:
                finalformset = zip(formset, subformsets)
                return return_form(request, mainform, finalformset, formset, studyformset)

    # Here the formset reaches its final form. This is needed to be able to
    # loop through the formset and the list of subformsets at the same time in
    # the template.
    finalformset = list(zip(formset, subformsets))
    return return_form(request, mainform, finalformset, formset, studyformset)

def get_field_type(request):
    value = request.POST.get('template', '')
    method = CourseRegReqTemplate.objects.get(title=value).validation_method
    return HttpResponse(method, content_type='application/json')

def fill_dropdown(request):
    value = request.POST.get('template', '')
    req_template = CourseRegReqTemplate.objects.get(title=value)
    app, model = req_template.req_model_name.split('_', 1)
    info_string = app + '_' + model + '_'
    model = apps.get_model(app_label=app, model_name=model)
    to_list_instance = model._meta.get_field(req_template.req_field_name)\
                                  .rel.to
    to_list_template = to_list_instance._meta.get_field('template').rel.to
    instances = [[str(inst), info_string + str(inst.pk)]
                 for inst in to_list_template.objects.all()]
    instances = dumps(instances)
    return HttpResponse(instances, content_type='application/json')


class CourseTemplateDelete(DeleteView):
    """
    In this view a course template and all its corresponding requirements are
    deleted.
    """
    model = CourseTemplate
    template_name = 'delete_course.html'
    success_url = reverse_lazy('course_setup:index')


class CourseListView(ListView):
    model = CourseTemplate
    template_name = 'vakopbouw.html'


class CourseRegReqTemplateCreate(CreateView):
    form_class = CourseRegReqTemplateForm
    model = CourseRegReqTemplate

    def narrow_down_fields(request):
        """
        A bit of a workaround: we get the string representation of the 
        modelname instead of a model object, so we must gather the
        relevant data and then get the model from that data

        Then we return a list of all fields within that model
        """
        app, model = request.POST.get('model', '').split('_', 1)
        model = apps.get_model(app_label=app, model_name=model)
        fields = dumps(list([f.name for f in model._meta.fields] +
                            [name for name in dir(model)
                             if isinstance(getattr(model, name), property)]))
        return HttpResponse(fields, content_type='application/json')


class CourseRegReqTemplateUpdate(UpdateView):
    model = CourseRegReqTemplate
    fields = ['title', 'req_model_name', 'req_field_name',
              'student_field_name', 'validation_method', 'int_operator']


class CourseRegReqTemplateDelete(DeleteView):
    model = CourseRegReqTemplate
    success_url = reverse_lazy('course_setup:index')
