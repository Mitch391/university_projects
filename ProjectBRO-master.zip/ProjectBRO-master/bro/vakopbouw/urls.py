from django.conf.urls import url
from persoonsgegevens.decorators import is_member, ADMIN, STUD_COORD
from . import views

app_name = 'course_setup'
group = [ADMIN, STUD_COORD]

urlpatterns = [
    url(r'^$',
        is_member(group, views.CourseListView.as_view()),
        name='index'),

    # Course template routes
    url(r'coursetemplate/add/$',
        is_member(group, views.CourseTemplateCreate),
        name='coursetemplate_add'),

    url(r'coursetemplate/add/get_field_type/$',
        is_member(group, views.get_field_type),
        name='coursetemplate_get_field_type'),

    url(r'coursetemplate/add/fill_dropdown/$',
        is_member(group, views.fill_dropdown),
        name='coursetemplate_fill_dropdown'),

    url(r'coursetemplate/(?P<pk>[0-9]+)/$',
        is_member(group, views.CourseTemplateUpdate),
        name='coursetemplate_update'),

    url(r'coursetemplate/(?P<pk>[0-9]+)/delete/$',
        is_member(group, views.CourseTemplateDelete.as_view()),
        name='coursetemplate_delete'),

    # Requirement template routes
    url(r'requirementtemplate/add/$',
        is_member(group, views.CourseRegReqTemplateCreate.as_view()),
        name='coursetemplate_regreq_add'),

    url(r'requirementtemplate/narrow_down_fields/$',
        is_member(group, views.CourseRegReqTemplateCreate.narrow_down_fields),
        name='coursetemplate_regreq_narrow'),

    url(r'requirementtemplate/(?P<pk>[0-9]+)/$',
        is_member(group, views.CourseRegReqTemplateUpdate.as_view()),
        name='coursetemplate_regreq_update'),

    url(r'requirementtemplate/(?P<pk>[0-9]+)/delete/$',
        is_member(group, views.CourseRegReqTemplateDelete.as_view()),
        name='coursetemplate_regreq_delete'),
]
