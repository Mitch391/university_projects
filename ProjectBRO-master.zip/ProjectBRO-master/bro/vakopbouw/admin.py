from django.contrib import admin
from .models import CourseTemplate, CourseRegReqGroup, CourseRegReqTemplate,\
    CourseRegReq

# Register your models here.
admin.site.register(CourseTemplate)
admin.site.register(CourseRegReqGroup)
admin.site.register(CourseRegReqTemplate)
admin.site.register(CourseRegReq)
