import operator

from django.db import models
from django.apps import apps
from django.core.urlresolvers import reverse
from django.core.validators import MinValueValidator, MaxValueValidator,\
    RegexValidator

from persoonsgegevens.models import PersonalData
from persoonsgegevens.decorators import LECTURER


class CourseTemplate(models.Model):
    """
    Template for a course. This includes basic information about the course
    and the requirements to enter the course. Also contains the functionality
    to validate those requirements.
    """
    name = models.CharField(max_length=256)
    EC = models.IntegerField(validators=[MinValueValidator(0)])
    coordinator = models.ForeignKey(
        PersonalData,
        limit_choices_to={'user__groups__name__in': [LECTURER]})
    course_id = models.CharField(max_length=12, blank=True, default='')
    course_code = models.CharField(
        unique=True, max_length=4, validators=[RegexValidator(
            regex=r'[A-Z]{4}',
            message="Course code must consist of four uppercase characters.")])
    start_period = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(6)])
    end_period = models.PositiveSmallIntegerField(
        blank=True, validators=[MinValueValidator(1), MaxValueValidator(6)])

    def generate_course_id(self):
        """
        Generates a course id from its course code and the
        first study it was added to.
        """
        from studieopbouw.models import StudyTemplate
        study_code = StudyTemplate.objects.filter(
            studytocoursetemplate__course=self).first().study_code
        course_code = self.course_code
        self.course_id = study_code + course_code + str(self.EC) + "Y"
        self.save(update_fields=['course_id'])

    def validate_all(self, student_id):
        """
        Checks if from all groups enough requirements are valid.
        This is based on 'pick n from many' boxes and an implicit
        and between those boxes.
        """
        groups = CourseRegReqGroup.objects.filter(course_template=self.pk)

        for group in groups:
            valid_reqs = 0
            reqs = CourseRegReq.objects.filter(req_group=group.pk)
            invalid = []
            for req in reqs:
                model = req.template.req_model_name.split("_")[1]
                student = student_id.uvanetid if model == "personaldata" else student_id
                if CourseTemplate.validate_req(req, student):
                    valid_reqs += 1
                else:
                    invalid.append(str(req))

            if valid_reqs < group.req_amount:
                return False, invalid, group.req_amount - valid_reqs
        return True, None, None

    @staticmethod
    def validate_req(req, student_id):
        """
        Calls the right validation function for a specific requirement.
        """
        if req.template.validation_method == 0:
            return CourseTemplate.validate_entry(req, student_id)
        elif req.template.validation_method == 1:
            return CourseTemplate.validate_string(req, student_id)
        elif req.template.validation_method == 2:
            return CourseTemplate.validate_int(req, student_id)
        return False

    @staticmethod
    def validate_entry(req, student_id):
        """
        Validation function to check if a certain entry exists in the database.
        Example: Check if a student completed a certain course.
        """
        models = req.template.req_model_name.split("_")
        model_name = apps.get_model(models[0], models[1])
        app_name, model, pk = req.accepted_value.split("_")
        accepted_model = apps.get_model(app_name, model)
        accepted_obj = accepted_model.objects.get(pk=pk)
        entries = model_name.objects.filter(
            **{req.template.student_field_name: student_id},
            **{req.template.req_field_name: accepted_obj}
        )

        return len(entries) > 0

    @staticmethod
    def validate_string(req, student_id):
        """
        Validation function to check if two strings in the database are equal.

        """
        models = req.template.req_model_name.split("_")
        model_name = apps.get_model(models[0], models[1])
        model_instance = model_name.objects.get(
            **{req.template.student_field_name: student_id})

        field_value = getattr(model_instance, req.template.req_field_name)
        return field_value == req.accepted_value

    @staticmethod
    def validate_int(req, student_id):
        """
        Validation function to check the relation between two integers.
        Example: a students EC has to be >= 30
        """
        models = req.template.req_model_name.split("_")
        model_name = apps.get_model(models[0], models[1])
        model_instance = model_name.objects.get(
            **{req.template.student_field_name: student_id})
        field_value = getattr(model_instance, req.template.req_field_name)
        operators = {'<': operator.lt, '<=': operator.le, '==': operator.eq,
                     '>=': operator.ge, '>': operator.gt}

        return operators[req.template.int_operator](
            int(field_value), int(req.accepted_value))

    @staticmethod
    def get_absolute_url():
        return reverse('course_setup:index')

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['name']


class CourseRegReqGroup(models.Model):
    """
    Data representation of a 'pick n from many' box. Contains information
    about the needed amount of valid requirements aswell as the CourseTemplate
    it is part of.
    """
    course_template = models.ForeignKey(CourseTemplate, blank=False,
                                        on_delete=models.CASCADE)
    req_amount = models.PositiveSmallIntegerField(blank=False)

    def __str__(self):
        return str(self.pk)


class CourseRegReqTemplate(models.Model):
    """
    Will be used in vakopbouw. Template for possible requirements. Contains a
    title to display to the user. Contains the table and field name to find the
    value that has to be validated aswell a the field name that identifies the
    student. Lastly it contains inforation about the validation method that is
    needed and if needed the operator that has to be used to validate two
    integers.
    """
    title = models.CharField(max_length=128)
    req_model_name = models.CharField(max_length=128)
    req_field_name = models.CharField(max_length=128)
    student_field_name = models.CharField(max_length=128)
    validation_method = models.PositiveSmallIntegerField()
    int_operator = models.CharField(max_length=2)

    def get_absolute_url(self):
        return reverse('course_setup:index')

    def __str__(self):
        return '{}: Pertaining {} in {}'\
            .format(self.title, self.req_field_name, self.req_model_name)


class CourseRegReq(models.Model):
    """
    This is the actual requirement. Has a foreign key to a requirement
    template, but also contains the group it is part of aswell as the value it
    needs to be valid.
    """
    req_group = models.ForeignKey(CourseRegReqGroup, blank=False,
                                  on_delete=models.CASCADE)
    template = models.ForeignKey(CourseRegReqTemplate, blank=False,
                                 on_delete=models.CASCADE)
    accepted_value = models.CharField(max_length=128, blank=False)

    def get_accepted_value(self):
        acc = self.accepted_value
        if len(self.accepted_value.split("_")) == 3:
            model = self.accepted_value.split("_")
            model_name = apps.get_model(model[0], model[1])
            acc = model_name.objects.get(pk=model[2])
        return acc

    def __str__(self):
        return '{}: {}'\
            .format(self.template.req_field_name, self.get_accepted_value())
