from django.apps import AppConfig


class VakopbouwConfig(AppConfig):
    name = 'vakopbouw'
