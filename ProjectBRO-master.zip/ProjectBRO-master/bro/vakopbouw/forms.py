from django.apps import apps
from django import forms
from studieopbouw.models import StudyToCourseTemplate
from .models import CourseTemplate, CourseRegReqGroup, CourseRegReq,\
    CourseRegReqTemplate


class CourseRegReqGroupForm(forms.ModelForm):
    """
    Form to create a group of registration requirements.
    """
    class Meta:
        model = CourseRegReqGroup
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super(forms.ModelForm, self).__init__(*args, **kwargs)
        self.fields['req_amount'].label = "Required amount"


# Create a formset for Registration Requirement Groups.
CourseRegReqGroupFormSet = forms.inlineformset_factory(
    CourseTemplate,
    CourseRegReqGroup,
    form=CourseRegReqGroupForm,
    extra=0
)


class CourseRegReqForm(forms.ModelForm):
    """
    Form to create a Registration Requirement
    """
    class Meta:
        model = CourseRegReq
        fields = '__all__'


# Create a formset for Registration Requirement.
CourseRegReqFormSet = forms.inlineformset_factory(
    CourseRegReqGroup,
    CourseRegReq,
    form=CourseRegReqForm,
    extra=0
)


class CourseTemplateForm(forms.ModelForm):
    """
    Create the main form for the Course Template.
    """
    class Meta:
        model = CourseTemplate
        exclude = ('course_id',)

    def __init__(self, *arg, **kwarg):
        super(CourseTemplateForm, self).__init__(*arg, **kwarg)
        # Form is not allowed to stay empty.
        self.empty_permitted = False


class BaseStudyToCourseFormSet(forms.BaseInlineFormSet):
    def is_valid(self):
        valid = super(BaseStudyToCourseFormSet, self).is_valid()

        if not valid:
            return valid

        for form in self.forms:
            study = form.cleaned_data.get('study')
            if study:
                duration = study.duration
                if form.cleaned_data['year'] > duration:
                    form.add_error('year', 'The year selected is not in the duration of the study')
                    return False

        return True


StudyToCourseFormSet = forms.inlineformset_factory(
    CourseTemplate,
    StudyToCourseTemplate,
    formset=BaseStudyToCourseFormSet,
    fields=['study', 'year'],
    extra=1
)


class CourseRegReqTemplateForm(forms.ModelForm):
    """
    Create the form for the Course Registration Requirement
    Template. Overrides some formfields to allow the choice
    of model in req_field_name to reflect in a modified
    selection of req and student _field_name.
    """
    # The second element is the repr in the dropdownlist, the first the
    # returned value
    model_names = [(model._meta.db_table, model._meta.db_table)
                   for model in apps.get_models()]
    oper = ['<', '<=', '==', '>=', '>']

    req_model_name = forms.ChoiceField(
            choices=[("", "Required model")] + model_names,
            widget=forms.Select(attrs={'onchange': "narrow_down_fields();"}))
    req_field_name = forms.CharField(widget=forms.Select(
            choices=[("", "Requirement field")]))
    student_field_name = forms.CharField(widget=forms.Select(
            choices=[("", "Student field")]))
    validation_method = forms.ChoiceField(
            choices=[("", "Validation method"), (0, 'Database entry'),
                     (1, 'String'), (2, 'Integer')])
    int_operator = forms.ChoiceField(
        choices=[("", "Operator")] +
        list(zip(oper, oper)))

    def __init__(self, *args, **kwargs):
        super(forms.ModelForm, self).__init__(*args, **kwargs)
        self.fields['title'].label = "How the template should be displayed to users"
        self.fields['req_model_name'].label = "The model of importance"
        self.fields['req_field_name'].label = "Field to be checked for requirement"
        self.fields['student_field_name'].label = "Field with reference to student ID"
        self.fields['validation_method'].label = "The type of requirement"
        self.fields['int_operator'].label = "Operator when using integer validation method"

    class Meta:
        model = CourseRegReqTemplate
        fields = ['title', 'req_model_name', 'req_field_name',
                  'student_field_name', 'validation_method', 'int_operator']
