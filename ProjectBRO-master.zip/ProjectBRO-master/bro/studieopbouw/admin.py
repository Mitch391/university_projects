from django.contrib import admin
from .models import StudyInstance, StudyTemplate, StudyToCourseInstance,\
    StudyToCourseTemplate

admin.site.register(StudyInstance)
admin.site.register(StudyToCourseInstance)
admin.site.register(StudyTemplate)
admin.site.register(StudyToCourseTemplate)
