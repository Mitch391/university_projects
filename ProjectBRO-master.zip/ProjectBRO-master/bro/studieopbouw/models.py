from django.db import models
from django.urls import reverse
from django.core.validators import RegexValidator

from vakopbouw.models import CourseTemplate
from vakbeheer.models import CourseInstance
from persoonsgegevens.models import PersonalData
from persoonsgegevens.decorators import STUD_ADV, STUD_COORD


class StudyTemplate(models.Model):
    TYPES = [
        (0, 'Bachelor'),
        (1, 'Master')
    ]
    name = models.CharField(max_length=256)
    type = models.PositiveSmallIntegerField(choices=TYPES)
    coordinator = models.ForeignKey(
        PersonalData,
        limit_choices_to={'user__groups__name__in': [STUD_COORD]},
        related_name='coordinator')
    advisor = models.ForeignKey(
        PersonalData,
        limit_choices_to={'user__groups__name__in': [STUD_ADV]},
        related_name='advisor')
    current = models.BooleanField(default=True)
    duration = models.PositiveSmallIntegerField()
    study_code = models.CharField(
        unique=True, max_length=4,
        validators=[RegexValidator(
            regex=r'[0-9]{4}', message="Study code must be four numbers."
        )])

    @staticmethod
    def get_absolute_url():
        return reverse('study_setup:index')

    def __str__(self):
        return str(self.TYPES[self.type][1]) + " " + self.name


class StudyToCourseTemplate(models.Model):
    study = models.ForeignKey(StudyTemplate)
    course = models.ForeignKey(CourseTemplate)
    year = models.PositiveSmallIntegerField(null=True)


class StudyInstance(models.Model):
    template = models.ForeignKey(StudyTemplate)
    start_year = models.IntegerField()

    class Meta:
        unique_together = ('template', 'start_year')

    def __str__(self):
        return self.template.name


class StudyToCourseInstance(models.Model):
    study = models.ForeignKey(StudyInstance)
    course = models.ForeignKey(CourseInstance)
