from datetime import datetime

from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.core.urlresolvers import reverse_lazy
from django.views.generic.list import ListView
from django.shortcuts import redirect, get_object_or_404

from vakopbouw.models import CourseTemplate
from vakbeheer.models import CourseInstance
from persoonsgegevens.decorators import owns_study_or_403, ADMIN

from .models import StudyTemplate, StudyInstance, StudyToCourseInstance
from django.urls import reverse


class StudyCreate(CreateView):
    model = StudyTemplate
    fields = ['name', 'type', 'study_code', 'coordinator', 'advisor',
              'duration']
    template_name = 'create_study.html'


class StudyUpdate(UpdateView):
    model = StudyTemplate
    fields = ['name', 'type', 'study_code', 'coordinator', 'advisor',
              'duration']
    template_name = 'update_study.html'

    def get_id(self):
        return self.object.id

    def get(self, request, pk):
        owns_study_or_403(request, get_object_or_404(StudyTemplate, pk=pk))
        return super(StudyUpdate, self).get(request, pk)


class StudyDelete(DeleteView):
    model = StudyTemplate
    template_name = 'delete_study.html'
    success_url = reverse_lazy('study_setup:index')


class StudyListView(ListView):
    model = StudyTemplate
    template_name = 'studieopbouw.html'

    def get_queryset(self):
        bachelors = StudyTemplate.objects.filter(type=0)
        masters = StudyTemplate.objects.filter(type=1)
        return zip(['Bachelors', 'Masters'], [bachelors, masters])

    def get_context_data(self, **kwargs):
        context = super(StudyListView, self).get_context_data(**kwargs)
        context['year'] = datetime.now().year
        context['next'] = context['year'] + 1
        context['has_button'] = False
        #  try:
        #      context['started'] = StudyInstance.objects.filter(start_year=2017)
        #  except:
        #      pass
        if StudyInstance.objects.filter(start_year=2017):
            context['started'] = StudyInstance.objects.filter(start_year=2017)

        if self.request.user.groups.filter(name=ADMIN).exists():
            context['has_button'] = True

        return context


class CourseListView(ListView):
    model = CourseTemplate
    template_name = 'add_study_course.html'
    context_object_name = 'course_list'

    def get_context_data(self, **kwargs):
        context = super(CourseListView, self).get_context_data(**kwargs)
        study = StudyTemplate.objects.get(pk=self.kwargs['study_template'])

        year_list = []
        for year in range(1, study.duration + 1):
            courses = CourseTemplate.objects.filter(
                studytocoursetemplate__study=study,
                studytocoursetemplate__year=year
            )
            year_list.append(courses)

        context['course_list'] = CourseTemplate.objects.exclude(
            studytocoursetemplate__study=study)
        context['study'] = study
        context['yearlist'] = year_list

        return context


def start_year(request):
    year = datetime.now().year
    studies = StudyTemplate.objects.filter(current=True)
    try:
        for study in studies:
            s = StudyInstance.objects.create(template=study, start_year=year)
            for course in CourseTemplate.objects.filter(
                    studytocoursetemplate__study=study):
                c = CourseInstance.objects.create(template=course)
                StudyToCourseInstance.objects.create(study=s, course=c)
        return redirect('study_setup:index')

    except:
        return redirect(reverse('study_setup:index') + '?error=1')
