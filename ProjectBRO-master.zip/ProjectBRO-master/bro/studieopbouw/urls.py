from django.conf.urls import url
from persoonsgegevens.decorators import is_member, ADMIN, STUD_COORD
from . import views

app_name = 'study_setup'
groups = [ADMIN, STUD_COORD]

urlpatterns = [
    url(r'^$', is_member(groups, views.StudyListView.as_view()), name='index'),
    url(r'^create/$', is_member(groups, views.StudyCreate.as_view()),
        name='create'),

    url(r'^update/(?P<pk>[0-9]+)/$',
        is_member(groups, views.StudyUpdate.as_view()), name='update'),

    url(r'^delete/(?P<pk>[0-9]+)$',
        is_member(groups, views.StudyDelete.as_view()), name='delete'),

    # NEW URLS: kijk naar consistentie / group beheer shit
    url(r'^courses/(?P<study_template>[0-9]+)/$',
        is_member(groups, views.CourseListView.as_view()), name='courses'),

    # ??? is_member??, JA!!!
    url(r'^start_year/',
        is_member(groups, views.start_year), name='start_year'),
]
