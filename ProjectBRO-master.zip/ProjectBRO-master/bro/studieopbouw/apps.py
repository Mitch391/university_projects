from django.apps import AppConfig


class StudieopbouwConfig(AppConfig):
    name = 'studieopbouw'
