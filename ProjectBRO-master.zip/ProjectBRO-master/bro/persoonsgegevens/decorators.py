from functools import wraps

from django.contrib.auth import REDIRECT_FIELD_NAME
from django.core.exceptions import PermissionDenied
from django.utils.decorators import available_attrs
from django.contrib.auth.views import redirect_to_login
from django.shortcuts import resolve_url
from urllib.parse import urlparse
from django.conf import settings

from .models import PersonalData

# Constants for user groups
BUREAU_EXAM = 'Bureau Examens'
CSA = 'Centrale Studenten Administratie'
LECTURER = 'Docent'
ADMIN = 'Functioneel Beheerder'
STUD_COORD = 'Opleidingscoordinator'
PLANNING = 'Planning'
SD = 'Servicedesk'
STUD = 'Student'
STUD_ADV = 'Studieadviseur'
TA = 'TA'


def user_passes_test_or_403(test_func, login_url=None,
                            redirect_field_name=REDIRECT_FIELD_NAME):
    """
    Decorator for views that checks that the user passes the given test,
    redirecting to the log-in page if necessary. The test should be a callable
    that takes the user object and returns True if the user passes.

    Based on user_passes_test(), Django built-in function, but instead gives
    a 403 instead of a redirect to the login page.
    """

    def decorator(view_func):
        @wraps(view_func, assigned=available_attrs(view_func))
        def _wrapped_view(request, *args, **kwargs):
            # everything in this if statement is taken from the
            # django login_required source code
            if not request.user.is_authenticated():
                path = request.build_absolute_uri()
                resolved_login_url = resolve_url(login_url or
                                                 settings.LOGIN_URL)

                login_scheme, login_netloc = urlparse(resolved_login_url)[:2]
                current_scheme, current_netloc = urlparse(path)[:2]
                if ((not login_scheme or login_scheme == current_scheme) and
                   (not login_netloc or login_netloc == current_netloc)):
                        path = request.get_full_path()
                return redirect_to_login(
                       path, resolved_login_url, redirect_field_name)

            if test_func(request.user):
                return view_func(request, *args, **kwargs)
            raise PermissionDenied
        return _wrapped_view
    return decorator


def is_member(groups, fun=None, redirect_field_name=REDIRECT_FIELD_NAME,
              login_url=None):
    """
    Decorator for views that checks that the user belongs to one of the groups
    specified. Returns a 403 otherwise.

    Based on login_required(), Django built-in function, but instead checks
    for group membership.
    """

    actual_decorator = user_passes_test_or_403(
        lambda u: u.groups.filter(name__in=groups).exists(),
        login_url=login_url,
        redirect_field_name=redirect_field_name
    )
    return actual_decorator(fun) if fun else actual_decorator


def owns_course_or_403(request, course, admins=None, ta=True, stud=False):
    """
    If the user is only Lecturer and/or TA, check whether the user should have
    access to the course.
    """
    from vakbeheer.models import CourseToAssistant, CourseToLecturer,\
        CourseToStudent

    if admins is None:
        admins = [ADMIN]

    if request.user.groups.filter(name__in=admins).exists():
        return

    is_lecturer = request.user.groups.filter(name=LECTURER).exists()

    coordinator = course.template.coordinator.uvanetid
    if is_lecturer and coordinator == request.user.username:
        return

    user = PersonalData.objects.get(uvanetid=request.user.username)
    if is_lecturer and CourseToLecturer.objects.filter(
            course=course.pk, uvanetid=user).exists():
        return

    ta = ta and request.user.groups.filter(name=TA).exists()
    if ta and CourseToAssistant.objects.filter(course=course.pk,
                                               assistant=user).exists():
        return

    stud = stud and request.user.groups.filter(name=STUD).exists()
    if stud and CourseToStudent.objects.filter(
            course=course.pk, student=user).exists():
        return
    raise PermissionDenied


def has_student_or_403(user, uvanetid, admins=None):
    """
    If the user is only Lecturer and/or TA, check whether the user should have
    access to the student's personal data (i.e. the student follows or has
    followed a course to which the current user is connected).
    """
    from vakbeheer.models import CourseToAssistant, CourseToLecturer, \
        CourseToStudent
    from studieopbouw.models import StudyTemplate
    from studieplan.models import AcademicPlan

    if admins is None:
        admins = [ADMIN]

    if user.username == uvanetid:
        return

    if user.groups.filter(name__in=admins).exists():
        return

    if user.groups.filter(name=LECTURER).exists():
        # Check if user is coordinator of student's course
        has_student = CourseToStudent.objects.filter(
            student__uvanetid=uvanetid,
            course__template__coordinator__uvanetid=user.username).exists()

        if has_student:
            return

        # Check if user is lecturer of student's course
        lect_courses = CourseToLecturer.objects.filter(
            uvanetid__uvanetid=user.username)
        if lect_courses.exists() and CourseToStudent.objects.filter(
                student__uvanetid=uvanetid,
                course__id__in=lect_courses.values('course')).exists():
            return

    if user.groups.filter(name=TA).exists():
        ta_groups = CourseToAssistant.objects.filter(
            assistant__uvanetid=user.username)
        if ta_groups.exists() and CourseToStudent.objects.filter(
                course__in=ta_groups.values('course')):
            return

    if user.groups.filter(name=STUD_ADV).exists():
        for study in StudyTemplate.objects.filter(advisor=PersonalData.objects.filter(user=user)):
            if AcademicPlan.objects.filter(student__uvanetid=uvanetid, study__template=study).exists():
                return

    raise PermissionDenied


def owns_study_or_403(request, study, admins=None):

    if admins is None:
        admins = [ADMIN]

    if request.user.groups.filter(name__in=admins).exists():
        return

    coordinator = study.coordinator.uvanetid
    if coordinator == request.user.username:
        return

    raise PermissionDenied
