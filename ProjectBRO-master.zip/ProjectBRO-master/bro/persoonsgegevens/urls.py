from django.conf.urls import url
from django.contrib.auth.decorators import login_required

from . import views
from .decorators import is_member, ADMIN, STUD_COORD,\
    STUD, STUD_ADV, SD, CSA, LECTURER, TA

app_name = "personal_data"

# TODO Figure out which groups may do this
group = [ADMIN, STUD_COORD, STUD, STUD_ADV, SD, CSA, LECTURER, TA]
admingroup = [ADMIN]

urlpatterns = [
    # /personal_data
    url(r'^$',
        login_required(views.IndexOwnView.as_view()),
        name="index"),

    # /personal_data/add
    url(r'^add/$',
        is_member(admingroup, views.create_user),
        name="create_user"),

    url(r'^update/$',
        is_member(group, views.update_user),
        name="update_user"),

    # /personal_data/message/add
    url(r'^message/add/(?P<uvanetid>[a-zA-Z0-9_.-]+)',
        is_member([STUD_ADV], views.message_add),
        name="message_add"),

    # /personal_data/<uvanetid>
    url(r'^(?P<uvanetid>[a-zA-Z0-9_.-]+)/$',
        is_member(group, views.IndexExtView.as_view()),
        name="index_ext")
]
