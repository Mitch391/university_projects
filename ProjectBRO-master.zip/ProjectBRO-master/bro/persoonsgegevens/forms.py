from django.contrib.auth.models import Group
from django import forms
from studieopbouw.models import StudyInstance

from .models import PersonalData, StudentFile


class UserForm(forms.ModelForm):
    group = forms.ModelMultipleChoiceField(
        queryset=Group.objects.all(), required=True)
    study = forms.ModelMultipleChoiceField(
        queryset=StudyInstance.objects.all(), required=False)

    class Meta:
        model = PersonalData
        exclude = ('user', )

    def is_valid(self):
        valid = super(UserForm, self).is_valid()

        if not valid:
            return valid

        if self.cleaned_data['group'].filter(name="Student").exists():
            if not self.cleaned_data['study']:
                self.add_error('study', 'No study selected')
                return False

        return True


class UpdateUserForm(forms.ModelForm):
    class Meta:
        model = PersonalData
        exclude = ('user', 'name', 'surname', 'uvanetid')


class MessageForm(forms.ModelForm):
    message = forms.CharField(required=True, widget=forms.Textarea(attrs={'cols': 50}))
    # student = forms.CharField(required=True, widget=forms.TextInput())

    class Meta:
        model = StudentFile
        exclude = ('date', 'id', 'student')
