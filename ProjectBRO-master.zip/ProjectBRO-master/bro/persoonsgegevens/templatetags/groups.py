from django import template
from django.contrib.auth.models import User

register = template.Library()

@register.filter
def has_group(user, group):
    """
    Returns whether the user belongs to the requested group. Used in the side-
    bar to determine whether the user should see a specific button.
    """
    return user.groups.filter(name=group).exists()

@register.filter
def groups(user):
    """
    Returns all the groups the user is assigned as string
    """
    output = str()
    groups = user.groups
    for g in groups.all():
        if groups.first() == g:
            output += " " + str(g)
        else:
            output += ", " + str(g)

    return output
