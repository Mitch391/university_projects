# -*- coding: utf-8 -*-

from django.contrib import admin
from .models import PersonalData, StudentFile

# Register your models here.
admin.site.register(PersonalData)
admin.site.register(StudentFile)
