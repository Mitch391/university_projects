from django.db import models
from django.core.validators import RegexValidator
from django.core.urlresolvers import reverse
from django.contrib.auth.models import User
import datetime

class PersonalData(models.Model):
    phone_regex = RegexValidator(
        regex=r'^\+?1?\d{9,15}$',
        message="Phone number must be entered in the format: '+999999999'. Up to 15 digits allowed."
    )
    user = models.OneToOneField(User)
    uvanetid = models.CharField(max_length=64, primary_key=True)
    name = models.CharField(max_length=32)
    surname = models.CharField(max_length=32)
    street_name = models.CharField(max_length=64, blank=True)
    house_number = models.CharField(max_length=16, blank=True)
    postal_code = models.CharField(max_length=16, blank=True)
    city = models.CharField(max_length=32, blank=True)
    email = models.EmailField(max_length=32)
    telephone_number = models.CharField(
        max_length=16, blank=True, validators=[RegexValidator(
            regex=r'^\+?1?\d{9,15}$',
            message="Phone number must be entered in the format: '+999999999'."
                    " Up to 15 digits allowed."
        )]
    )

    @property
    def address(self):
        return self.street_name + " " + self.house_number

    @staticmethod
    def get_absolute_url():
        return reverse('personal_data:index')

    def get_student(self):
        return self

    @property
    def studies(self):
        from studieplan.models import AcademicPlan
        studies = []
        study_links = AcademicPlan.objects.filter(student=self)
        for study_link in study_links:
            studies.append(study_link.study)

        return studies

    def get_all(self):
        return self.uvanetid, self.name, self.surname, self.street_name,\
               self.house_number, self.postal_code, self.city,\
               self.telephone_number

    @property
    def EC(self):
        from vakbeheer.models import CourseToStudent
        EC = 0
        courses = CourseToStudent.objects.filter(student=self)
        course_links = [course for course in courses if course.passed]
        for course_link in course_links:
            EC += course_link.course.template.EC

        return EC

    def __str__(self):
        return self.name + " " + self.surname

class StudentFile(models.Model):
    student = models.ForeignKey(PersonalData)
    date = models.DateField(default=datetime.date.today)
    message = models.CharField(max_length=4096, blank=True)

    @staticmethod
    def get_absolute_url():
        return reverse('personal_data:index')

    def __str__(self):
        return self.message


