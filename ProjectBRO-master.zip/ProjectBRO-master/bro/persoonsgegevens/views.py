import hashlib

from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.http import HttpResponseRedirect
from django.shortcuts import render, get_object_or_404
from django.core.urlresolvers import reverse_lazy
from django.views.generic import TemplateView
from django.contrib.auth.models import User, Group
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash

from cijferbeheer.models import GradeInstance
from studieplan.models import AcademicPlan
from vakbeheer.models import CourseToStudent

from .decorators import has_student_or_403, ADMIN, STUD_ADV, SD, CSA
from .models import PersonalData, StudentFile
from .forms import UserForm, UpdateUserForm, MessageForm


class AbstractIndexView(TemplateView):
    model = PersonalData
    context_object_name = 'data'
    template_name = 'studentinfo.html'

    def get_uvanetid(self, kwargs):
        """
        Return UvAnetID of which the personal data must be shown.
        Must be implemented by inheriting classes.
        """
        pass

    def get_object(self):
        return PersonalData.objects.get(uvanetid=self.request.user.username)

    def get_context_data(self, **kwargs):
        has_student_or_403(self.request.user, self.get_uvanetid(kwargs))
        context = super(AbstractIndexView, self).get_context_data(**kwargs)
        context['data'] = get_object_or_404(
            PersonalData.objects,
            uvanetid=self.get_uvanetid(kwargs))

        courses = CourseToStudent.objects.filter(
            student__uvanetid=self.get_uvanetid(kwargs))
        context['form'] = MessageForm
        context['courses'] = courses
        context['grades'] = GradeInstance.objects.filter(
            student=context['data'])

        context['show_grades'] = \
            self.request.user.username == self.get_uvanetid(kwargs) \
            or self.request.user.groups.filter(
                name__in=[ADMIN, STUD_ADV, SD, CSA]).exists()

        m = hashlib.md5()
        m.update(context['data'].email.encode('utf-8'))
        context['hash'] = m.hexdigest()

        context['show_messages'] = self.request.user.groups.filter(
                name__in=[STUD_ADV]).exists()

        context['messages'] = StudentFile.objects.all()

        return context


class IndexExtView(AbstractIndexView):
    redirect_name = 'personal_data:index_ext'

    def get_uvanetid(self, kwargs):
        return kwargs['uvanetid']


class IndexOwnView(AbstractIndexView):
    redirect_name = "personal_data:index"

    def get_uvanetid(self, kwargs):
        return self.request.user.username


def message_add(request, uvanetid):
    if request.method == "POST":
        form = MessageForm(request.POST)

        if form.is_valid():
            f = form.save(commit=False)
            f.student = PersonalData.objects.get(uvanetid=uvanetid)
            f.save()

    return HttpResponseRedirect(reverse_lazy('personal_data:index'))


def create_user(request):
    if request.method == "POST":
        form = UserForm(request.POST)
        if form.is_valid():
            groups = form.cleaned_data['group']
            studies = form.cleaned_data['study']
            password = 'pass1234' #User.objects.make_random_password()
            form = form.save(commit=False)
            user = User.objects.create_user(
                username=form.uvanetid, password=password,
                first_name=form.name, last_name=form.surname, email=form.email)

            for group in groups:
                group = Group.objects.get(name=group)
                group.user_set.add(user)

            form.user = user
            form.save()

            # Create academic plan when user is a student
            if user.groups.filter(name="Student").exists():
                for study in studies:
                    AcademicPlan.objects.create(student=form, study=study)
            return HttpResponseRedirect(reverse_lazy('personal_data:index'))
    else:
        form = UserForm()
    return render(request, 'create_personal_data.html',
                  {'form': form})


def update_user(request):
    personal_data = PersonalData.objects.get(uvanetid=request.user)
    if request.method == "POST":
        form = UpdateUserForm(request.POST, request.FILES, instance=personal_data)
        form2 = PasswordChangeForm(request.user, request.POST)
        if 'update_data' in request.POST:
            if form.is_valid():
                form.save()
                return HttpResponseRedirect(reverse_lazy('personal_data:index'))
        if 'update_password' in request.POST:
            if form2.is_valid():
                user = form2.save()
                update_session_auth_hash(request, user)
                return HttpResponseRedirect(reverse_lazy('personal_data:index'))
    else:
        form = UpdateUserForm(instance=personal_data)
        form2 = PasswordChangeForm(request.user)

    context = {'form': form, 'form2': form2}
    context['data'] = personal_data

    return render(request, 'update_personal_data.html', context)
