from django.conf.urls import url, include
from django.contrib import admin
from django.contrib.auth import views as auth_views

urlpatterns = [
    url(r'^', include('main.urls')),
    url(r'^login/', include('login.urls')),
    url(r'^study_setup/', include('studieopbouw.urls')),
    url(r'^course_setup/', include('vakopbouw.urls')),
    url(r'^academic_plan/', include('studieplan.urls')),
    url(r'^grade_management/', include('cijferbeheer.urls')),
    url(r'^course_management/', include('vakbeheer.urls')),
    url(r'^personal_data/', include('persoonsgegevens.urls')),
    url(r'^admin/', admin.site.urls),
]
