from django.contrib import admin
from .models import AcademicPlan, AcademicYearPlan, CoursePlan

# Register your models here.

admin.site.register(AcademicPlan)
admin.site.register(AcademicYearPlan)
admin.site.register(CoursePlan)
