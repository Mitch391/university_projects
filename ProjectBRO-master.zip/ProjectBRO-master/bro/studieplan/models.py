from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from persoonsgegevens.models import PersonalData
from persoonsgegevens.decorators import STUD
from studieopbouw.models import StudyInstance
from vakbeheer.models import CourseInstance


class AcademicPlan(models.Model):
    """Academic plan should be student-specific over all the years."""
    student = models.ForeignKey(
        PersonalData,
        limit_choices_to={'user__groups__name__in': [STUD]},
        on_delete=models.CASCADE)
    study = models.ForeignKey(StudyInstance, on_delete=models.CASCADE)

    def __str__(self):
        return 'Academic plan for student {} with study {}'\
                .format(str(self.student), str(self.study))


class AcademicYearPlan(models.Model):
    academic_plan = models.ForeignKey(AcademicPlan, on_delete=models.CASCADE)
    time_block = models.IntegerField(validators=[MinValueValidator(1),
                                                 MaxValueValidator(3)])

    def __str__(self):
        return 'Academic yearplan {} of {}'\
                .format(self.time_block, self.academic_plan)


class CoursePlan(models.Model):
    academic_yearplan = models.ForeignKey(
            AcademicYearPlan, on_delete=models.CASCADE)
    course = models.ForeignKey(CourseInstance, on_delete=models.CASCADE)

    def __str__(self):
        return 'Course {} of {}'\
                .format(self.course, self.academic_yearplan)
