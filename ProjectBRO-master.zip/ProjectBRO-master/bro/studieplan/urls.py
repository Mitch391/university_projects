from django.conf.urls import url
from django.contrib.auth.decorators import login_required
from persoonsgegevens.decorators import is_member, BUREAU_EXAM, CSA, ADMIN, \
        STUD, STUD_COORD, SD, STUD_ADV
from . import views

app_name = 'academic_plan'
group_index_ext = [BUREAU_EXAM, CSA, ADMIN, STUD_COORD, SD, STUD_ADV]
group_unenroll = [STUD, ADMIN, SD]
group_enroll = [STUD, ADMIN, SD]

# How to both show YearView and Enroll at the same time?
urlpatterns = [
    url(r'^$',
        is_member([STUD], views.IndexOwnView.as_view()),
        name="index_own"),

    url(r'^courselist/$',
        is_member([STUD], views.CourseListView),
        name="courselist"),

    url(r'^courselist/(?P<studypk>[0-9]+)$',
        is_member([STUD], views.CourseListViewId.as_view()),
        name="courselist_id"),

    url(r'^unenroll/(?P<pk>[0-9]+)/$',
        is_member(group_unenroll, views.unenroll),
        name="unenroll"),

    #  url(r'^enroll/(?P<pk>[0-9]+)/(?P<year>[0-9])/$',
    url(r'^enroll/(?P<studypk>[0-9]+)/(?P<pk>[0-9]+)/$',
        is_member(group_enroll, views.enroll),
        name="enroll"),

    url(r'^(?P<uvanetid>[a-zA-Z0-9_.-]+)/$',
        is_member(group_index_ext, views.IndexExtView.as_view()),
        name="index_ext"),

    url(r'^id/(?P<id>[0-9]+)/$', login_required(views.IndexIdView.as_view()),
        name="index_id"),
]
