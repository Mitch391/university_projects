from django.http import HttpResponseRedirect
from django.shortcuts import get_object_or_404, redirect
from django.core.exceptions import PermissionDenied
from django.views.generic import ListView
from django.views.generic.edit import ModelFormMixin

from persoonsgegevens.models import PersonalData
from vakbeheer.models import CourseInstance, CourseToStudent
from vakopbouw.models import CourseTemplate

from .models import AcademicPlan, AcademicYearPlan, CoursePlan


class AbstractIndexView(ModelFormMixin, ListView):
    # Form variables
    model = CoursePlan
    fields = ['course', 'academic_yearplan']
    exclude = []

    # Object variables
    template_name = 'studieplan.html'
    redirect_name = None

    def get_academic_plans(self, uvanetid):
        return AcademicPlan.objects.filter(student__uvanetid=uvanetid)[:]

    def get_academic_yearplans(self, academic_plan):
        return AcademicYearPlan.objects.filter(
                academic_plan__exact=academic_plan)[:]

    def get_academic_yearplan(self, uvanetid, pk):
        plan = self.get_academic_plans(uvanetid).first()
        yearplans = self.get_academic_yearplans(plan)
        return yearplans.get(pk=pk)

    def get_uvanetid(self, kwargs):
        pass

    def post(self, request, *args, **kwargs):
        form = self.get_form()
        if form.is_valid():
            tmp_form = form.save(commit=False)
            tmp_form.academic_yearplan = self.get_academic_yearplan(
                self.get_uvanetid(kwargs),
                pk=form['academic_yearplan'].value())

            tmp_form.save()
        return redirect(self.redirect_name, **kwargs)

    def get_context_data(self, **context):
        uvanetid = self.get_uvanetid(self.kwargs)

        context['form'] = self.get_form()

        # XXX Can't we make this a join?
        context['academic_plans'] = []
        for plan in self.get_academic_plans(uvanetid):
            planlist = []
            for yearplan in self.get_academic_yearplans(plan):
                courseplan = CoursePlan.objects.filter(academic_yearplan__exact=yearplan)
                planlist.append([yearplan.time_block, courseplan])
            EC = self.get_total_ec([row[1] for row in planlist])
            context['academic_plans'].append([planlist, plan.study, plan.study.pk, EC])
        return context

    @staticmethod
    def get_total_ec(course_list):
        ec = 0
        for block in course_list:
            for course in block:
                ec += course.course.template.EC
        return ec


def CourseListView(request):
    studypk = AcademicPlan.objects.filter(student__uvanetid=request.user.username).first().study.pk
    return redirect('academic_plan:courselist_id', studypk)


class CourseListViewId(ListView):
    model = CourseInstance
    template_name = 'vaklijst.html'
    context_object_name = 'courses'

    def get_context_data(self, **context):
        from cijferbeheer.models import GradeTemplateGroup
        context['studypk'] = self.kwargs['studypk']
        context['amount'] = self.request.session.pop('amount', None)
        context['errors'] = self.request.session.pop('error', None)
        context['success'] = self.request.session.pop('success', None)
        context['enrolled_course'] = self.request.session.pop(
                'enrolled_course', None)

        context['courses'] = list()
        courses = CourseInstance.objects\
            .exclude(
                coursetostudent__student__uvanetid=self.request.user.username)

        for course in courses.all():
            obj = {'course': course}
            groups = GradeTemplateGroup.objects.filter(
                    course=course, is_root=True)

            if groups.count() == 1:
                obj['reqs_single'] = True
                obj['req'] = groups.first()
            else:
                obj['reqs_multi'] = True
                obj['reqs'] = groups
            context['courses'].append(obj)

        return context


class IndexExtView(AbstractIndexView):
    redirect_name = "academic_plan:index_ext"

    def get_uvanetid(self, kwargs):
        return kwargs['uvanetid']


class IndexOwnView(AbstractIndexView):
    redirect_name = "academic_plan:index_own"

    def get_uvanetid(self, kwargs):
        return self.request.user.username


class IndexIdView(AbstractIndexView):
    redirect_name = "academic_plan:index_id"

    def get_uvanetid(self, kwargs):
        return self.request.user.username

    def get_academic_plans(self, uvanetid):
        plan = get_object_or_404(AcademicPlan, id=self.kwargs['id'])
        if plan.student.uvanetid != uvanetid:
            raise PermissionDenied

        return [plan]


def unenroll(request, pk):
    courseplan = CoursePlan.objects.get(pk=pk)
    uvanetid = PersonalData.objects.get(uvanetid=request.user.username)
    CourseToStudent.objects.get(
            course=courseplan.course_id, student=uvanetid).delete()
    courseplan.delete()

    return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))


def enroll(request, pk, studypk):
    from cijferbeheer.models import GradeTemplateGroup

    if 'passing_req' not in request.POST:
        request.session['error'] = 'No passing option submitted.'
        request.session['amount'] = 1
        return redirect('academic_plan:courselist_id', studypk=studypk)
    academicplan = AcademicPlan.objects\
        .filter(student__uvanetid=request.user.username)\
        .filter(study__pk=studypk)
    yearplan = AcademicYearPlan.objects\
        .filter(academic_plan=academicplan)\
        .order_by('time_block').last()
    student = PersonalData.objects.get(uvanetid=request.user.username)
    course = CourseInstance.objects.get(pk=pk)
    template = CourseTemplate.objects.get(courseinstance=course)

    passing_req = GradeTemplateGroup.objects.filter(
            course=course, pk=request.POST['passing_req'])

    if not passing_req.exists():
        request.session['error'] = 'Invalid passing option submitted.'
        request.session['amount'] = 1
        return redirect('academic_plan:courselist_id', studypk=studypk)
    request.session['enrolled_course'] = str(course)

    valid, error, amount = template.validate_all(student)
    if not valid:
        request.session['error'] = error
        request.session['amount'] = amount
        return redirect('academic_plan:courselist_id', studypk=studypk)

    if not yearplan:
        yearplan = AcademicYearPlan.objects.create(
                academic_plan=academicplan.first(), time_block=1)

    CoursePlan.objects.create(academic_yearplan=yearplan, course=course)
    CourseToStudent.objects.create(
        student=student, course=course, course_grading=passing_req.first())

    request.session['success'] = True
    return redirect('academic_plan:courselist_id', studypk=studypk)
