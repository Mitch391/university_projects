from django.http import HttpResponse, HttpResponseBadRequest
from django.db.models import Q
from django.shortcuts import render, get_object_or_404, Http404, redirect
from django.contrib import messages
from django.template import loader

from cijferbeheer.models import GradeInstance, GradeTemplate, \
    GradeTemplateGroup
from persoonsgegevens.decorators import owns_course_or_403, ADMIN, CSA, SD, \
    STUD, TA
from persoonsgegevens.models import PersonalData

from .forms import StudentAddToCourseForm, AddAnnouncementForm
from .models import CourseToAssistant, CourseToStudent, CourseToLecturer, \
                    CourseInstance, CourseTemplate, Announcement


ADD_STUDENT_ID = 'add_student_'
ADD_TA_ID = 'add_ta_'
REMOVE_TA_ID = 'remove_ta_'
group = [ADMIN, CSA, SD, TA]


def index(request):
    """
    Loads connected courses in Dashboard.
    """
    courses = CourseInstance.objects.filter(
        # coordinator
        Q(template__coordinator_id=request.user.username) |
        # lecturers
        Q(coursetolecturer__uvanetid_id=request.user.username) |
        # ta's
        Q(coursetoassistant__assistant_id=request.user.username)
    )

    context = {
        'courses': courses,
    }

    template = loader.get_template('new_vakbeheer.html')
    return HttpResponse(template.render(context, request))


def add_student(request, course, uvanetid):
    student = get_object_or_404(PersonalData.objects, uvanetid=uvanetid)
    if CourseToStudent.objects.filter(course=course, student=student):
        return 0
    CourseToStudent.objects.create(student=student, course=course)
    return 1


def add_ta(request, course, uvanetid):
    assistant = get_object_or_404(PersonalData.objects, uvanetid=uvanetid)
    if CourseToAssistant.objects.filter(course=course, assistant=assistant):
        return 0
    CourseToAssistant.objects.create(assistant=assistant, course=course)
    return 1


def remove_ta(request, course, uvanetid):
    assistant = get_object_or_404(PersonalData.objects, uvanetid=uvanetid)
    if not CourseToAssistant.objects.filter(course=course, assistant=assistant):
        return 0
    assistant = CourseToAssistant.objects.get(assistant=assistant, course=course)
    assistant.delete()
    return 1


def modify_course(request, course):
    for key, val in request.POST.items():
        if key.startswith(ADD_STUDENT_ID) and val == 'on':
            if not add_student(request, course, key.split(ADD_STUDENT_ID)[1]):
                return HttpResponseBadRequest(
                    'Student already following course.')
        elif key.startswith(ADD_TA_ID) and val == 'on':
            if not add_ta(request, course, key.split(ADD_TA_ID)[1]):
                return HttpResponseBadRequest(
                    'Assistant already managing course.')
        elif key.startswith(REMOVE_TA_ID) and val == 'on':
            if not remove_ta(request, course, key.split(REMOVE_TA_ID)[1]):
                return HttpResponseBadRequest(
                    'Assistant is not managing this course')
    return redirect('course_management:students_and_tas', course_id=course.id)


def course(request, course_id):
    courses = CourseInstance.objects.filter(
        # coordinator
        Q(template__coordinator_id=request.user.username) |
        # lecturers
        Q(coursetolecturer__uvanetid_id=request.user.username) |
        # ta's
        Q(coursetoassistant__assistant_id=request.user.username)
    )

    course = get_object_or_404(CourseInstance.objects, id=course_id)
    if request.POST:
        return modify_course(request, course)

    return redirect('course_management:announcements', course_id=course.id)


def add_student_to_course(request, course_id):
    """
    Specialenroll for students who do not meet requirements but will be
    enrolled anyway
    """
    course = get_object_or_404(CourseInstance.objects, id=course_id)
    owns_course_or_403(request, course, admins=group, ta=False)

    if request.method == "POST":
        form = StudentAddToCourseForm(request.POST)
        if form.is_valid():
            s = form.cleaned_data['student_id']
            c = course
            d = form.cleaned_data['exception_description']

            try:
                CourseToStudent.objects.create(
                    student=s, course=c, exception_description=d)

                messages.add_message(
                    request, messages.SUCCESS,
                    "Successfully enrolled the student to the course")
            except Exception as e:
                raise Http404(e)
    else:
        form = StudentAddToCourseForm(initial={'course_id': course_id})

    return render(request, 'vakbeheer/student_add_form.html', {'form': form})


def student_view(request, course_id):
    template = loader.get_template('new_vakbeheer.html')
    course = get_object_or_404(CourseInstance.objects, id=course_id)

    assistants = CourseToAssistant.objects.filter(course=course)

    context = {
        'course_name': course,
        'course_assistance': assistants,
        'course_id': int(course_id),
    }
    return HttpResponse(template.render(context, request))


def add_announcement(request, course_id):
    """
    Add announcement to course
    """
    course = get_object_or_404(CourseInstance.objects, id=course_id)
    user = get_object_or_404(PersonalData.objects, uvanetid=request.user)
    owns_course_or_403(request, course, admins=group, ta=True)

    if request.method == "POST":
        form = AddAnnouncementForm(request.POST)
        if form.is_valid():
            c = course
            t = form.cleaned_data['text']

            try:
                Announcement.objects.create(author=user, course=c, text=t)
                messages.add_message(request, messages.SUCCESS,
                                     "Announcement added to course")
                return redirect("course_management:announcements", course_id=course_id)
            except Exception as e:
                raise Http404(e)
    else:
        form = AddAnnouncementForm()

    return render(request, 'vakbeheer/announcement_add_form.html', {'form': form})


def announcements(request, course_id):

    uvanetid = request.user.username
    args = dict()

    args['as_student'] = list()
    for c in CourseToStudent.objects.filter(student=uvanetid):
        args['as_student'].append({
            'name': c.course.template.name
        })

    course = get_object_or_404(CourseInstance.objects, id=course_id)
    annoucements = Announcement.objects.filter(course__id=course_id).order_by('-date')

    template = loader.get_template("announcements_vakbeheer.html");
    context = {
        'messages': annoucements,
        'course_name': course,
        'course_id': int(course_id),
        'edit': not (
            request.user.groups.filter(name=STUD).exists() and
            CourseToStudent.objects.filter(
                course=course,
                student__uvanetid=request.user.username).exists()),
    }

    return HttpResponse(template.render(context, request))


def passing(request, course_id):
    """
    View that lists the passing requirements for a course.
    """
    course = get_object_or_404(CourseInstance.objects, id=course_id)
    groups = GradeTemplateGroup.objects.filter(course=course)
    template = loader.get_template("vakbeheer_passing.html")
    context = {
        'course_name': course,
        'course_id': int(course_id),
        'edit': not (
            request.user.groups.filter(name=STUD).exists() and
            CourseToStudent.objects.filter(
                course=course,
                student__uvanetid=request.user.username).exists()),
        'groups': groups,
    }
    return HttpResponse(template.render(context, request))


def grades(request, course_id):
    course = get_object_or_404(CourseInstance.objects, id=course_id)

    grade_instances = GradeInstance.objects.filter(template__course_id=course)

    template = loader.get_template("grades_vakbeheer.html");
    context = {
        'course_name': course,
        'course_id': int(course_id),
        'edit': not (
            request.user.groups.filter(name=STUD).exists() and
            CourseToStudent.objects.filter(
                course=course,
                student__uvanetid=request.user.username).exists()),
        'grade_instances': grade_instances,
        'uvanetid': request.user.username,
    }

    return HttpResponse(template.render(context, request))


def students_and_tas(request, course_id):
    args = dict()

    args['as_admin'] = list()
    if request.user.groups.filter(name__in=[ADMIN]).exists():
        for c in CourseInstance.objects.all():
            args['as_admin'].append({
                'name': c.template.name
            })

    course = get_object_or_404(CourseInstance.objects, id=course_id)

    assistants = CourseToAssistant.objects.filter(course=course)
    students = CourseToStudent.objects.filter(course=course)
    all_assistants = PersonalData.objects.filter(user__groups__name__in=[TA])\
        .exclude(coursetoassistant__in=assistants)\
        .exclude(coursetostudent__in=students)
    all_students = PersonalData.objects.filter(user__groups__name__in=[STUD])

    template = loader.get_template("students_vakbeheer.html");
    context = {
        'course_name': course,
        'course_assistance': assistants,
        'course_id': int(course_id),
        'course_students': students,
        'all_assistants': all_assistants,
        'all_students': all_students,
        'ta_id': ADD_TA_ID,
        'remove_ta_id': REMOVE_TA_ID,
        'stud_id': ADD_STUDENT_ID,
        'edit': not (
            request.user.groups.filter(name=STUD).exists() and
            CourseToStudent.objects.filter(
                course=course,
                student__uvanetid=request.user.username).exists()),
    }

    return HttpResponse(template.render(context, request))
