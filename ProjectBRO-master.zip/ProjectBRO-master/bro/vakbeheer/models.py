from django.db import models

from vakopbouw.models import CourseTemplate
from persoonsgegevens.models import PersonalData
from persoonsgegevens.decorators import LECTURER, STUD, TA

DEFAULT_TEMPLATES = ['Exam', 'Exam (resit)']
DEFAULT_INNER_GROUPS = ['Exam grade']
DEFAULT_ROOT = 'Final grade'


def setup_grading(course):
    """
    Creates the default grading scheme for a course (instance).
    """
    from cijferbeheer.models import GradeTemplate, GradeTemplateGroup
    default_templates = list()
    default_inner_groups = list()

    for t_name in DEFAULT_TEMPLATES:
        template = GradeTemplate(course_id=course, grade_name=t_name)
        template.save()
        default_templates.append(template)

    for g_name in DEFAULT_INNER_GROUPS:
        group = GradeTemplateGroup(
                course=course, name=g_name, minimum_abs=5.0, minimum_avg=5.5)
        group.save()
        default_inner_groups.append(group)

    default_root = GradeTemplateGroup(
            course=course, name=DEFAULT_ROOT, is_root=True,
            relation=GradeTemplateGroup.AND, minimum_abs=5.5)
    default_root.save()

    # Hardcoded creation of the default grading scheme
    for template in default_templates:
        default_inner_groups[0].templates.add(template)
    default_inner_groups[0].save()

    for group in default_inner_groups:
        default_root.groups.add(group)
    default_root.save()


class CourseInstance(models.Model):
    template = models.ForeignKey(CourseTemplate, on_delete=models.CASCADE)

    def save(self, *args, **kwargs):
        if not self.id:
            super(CourseInstance, self).save(*args, **kwargs)
            setup_grading(self)
        else:
            super(CourseInstance, self).save(*args, **kwargs)

    def __str__(self):
        from studieopbouw.models import StudyToCourseInstance
        year = StudyToCourseInstance.objects.filter(course=self)
        if year.exists():
            year = year.first().study.start_year
            return self.template.name + " " + str(year) + "/" + str(year+1)
        return self.template.name + ' (unkown year)'


class Announcement(models.Model):
    course = models.ForeignKey(CourseInstance)
    author = models.ForeignKey(
            PersonalData,
            limit_choices_to={'user__groups__name__in': [LECTURER, TA]})
    date = models.DateTimeField(auto_now_add=True, blank=True)
    text = models.TextField()

    def __str__(self):
        return "Announcement for " + self.course.template.name + ": " \
                + self.text


class CourseToLecturer(models.Model):
    course = models.ForeignKey(CourseInstance)
    uvanetid = models.ForeignKey(
        PersonalData,
        limit_choices_to={'user__groups__name__in': [LECTURER]})

    class Meta:
        unique_together = ('course', 'uvanetid')


class CourseToAssistant(models.Model):
    course = models.ForeignKey(CourseInstance)
    assistant = models.ForeignKey(
        PersonalData,
        limit_choices_to={'user__groups__name__in': [TA]})

    class Meta:
        unique_together = ('course', 'assistant')


class CourseToStudent(models.Model):
    from cijferbeheer.models import GradeTemplateGroup

    course = models.ForeignKey(CourseInstance)
    student = models.ForeignKey(
            PersonalData,
            limit_choices_to={'user__groups__name__in': [STUD]})
    course_grading = models.ForeignKey(
            GradeTemplateGroup,
            limit_choices_to={'is_root': True}
            )
    exception_description = models.CharField(max_length=256, blank=True)

    @property
    def grades_as_list(self):
        """
        Returns the GradeTemplateGroup and its descendants as a nested list
        in a human readable format. With grades of the current student.
        """
        return self.course_grading.as_list_stud(self.student.uvanetid)

    @property
    def passed(self):
        return self.course_grading.has_passed(self.student.uvanetid) \
                if self.course_grading else False

    @property
    def final_grade(self):
        """
        Final grade for course. Based on FNWI OER rounding rules.
        """
        if not self.course_grading or not self.passed:
            return 0.0
        grade = self.course_grading.get_grade(self.student.uvanetid)
        if 4.75 < grade < 5.49:
            return 5.0
        return round((grade * 2) / 2)

    def save(self, *args, **kwargs):
        if not self.id:
            super(CourseToStudent, self).save(*args, **kwargs)

            from cijferbeheer.models import GradeTemplate, GradeInstance
            assignments = GradeTemplate.objects.filter(course_id=self.course)
            for assignment in assignments:
                grade = GradeInstance.objects.create(student=self.student,
                                                     template=assignment,
                                                     grade=1.0,
                                                     feedback="Automagically generated",
                                                     attempt=1
                )
                grade.save()
        else:
            super(CourseToStudent, self).save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        """
        When a student unenrolls, also delete his grades.
        """
        from cijferbeheer.models import GradeInstance
        GradeInstance.objects.filter(
                template__course_id=self.course, student=self.student).delete()
        super(CourseToStudent, self).delete(*args, **kwargs)

    class Meta:
        unique_together = ('course', 'student')
