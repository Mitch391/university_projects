from django.conf.urls import url
from persoonsgegevens.decorators import is_member, ADMIN, STUD, TA, LECTURER, \
        CSA, SD
from . import views

app_name = 'course_management'
group1 = [ADMIN, STUD, TA, LECTURER, CSA, SD]
group2 = [ADMIN, LECTURER, SD, TA]
group_add = group2 + [CSA]

urlpatterns = [
    url(r'^$',
        is_member(group1, views.index),
        name="index"),

    url(r'^(?P<course_id>[0-9]+)/$',
        is_member(group1, views.course), name="course"),

    # Student enrollment to courses by admins (BRO-72)
    url(r'^(?P<course_id>[0-9]+)/student/add/$',
        is_member(group_add, views.add_student_to_course),
        name="add_student_to_course"),

    url(r'^(?P<course_id>[0-9]+)/add_announcement$',
        is_member(group2, views.add_announcement),
        name="add_announcement"),


    url(r'^(?P<course_id>[0-9]+)/info/$',
        is_member(group1, views.student_view),
        name="student_view"),

    url(r'^(?P<course_id>[0-9]+)/announcements/$',
        is_member(group1, views.announcements),
        name="announcements"),

    url(r'^(?P<course_id>[0-9]+)/passing/$',
        is_member(group1, views.passing),
        name="passing"),

    url(r'^(?P<course_id>[0-9]+)/grades/$',
        is_member(group1, views.grades),
        name="grades"),

    url(r'^(?P<course_id>[0-9]+)/students_and_tas/$',
        is_member(group1, views.students_and_tas),
        name="students_and_tas")
]
