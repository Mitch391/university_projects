from django.contrib import admin
from .models import CourseToStudent, CourseInstance, CourseToAssistant,\
    CourseToLecturer, Announcement

admin.site.register(CourseInstance)
admin.site.register(CourseToAssistant)
admin.site.register(CourseToStudent)
admin.site.register(CourseToLecturer)
admin.site.register(Announcement)
