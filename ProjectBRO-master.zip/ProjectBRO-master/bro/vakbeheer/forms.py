from django import forms
from persoonsgegevens.models import PersonalData
from .models import Announcement, CourseInstance


#
#   Form for letting an admin add a student to a course
#
#   BRO-72 (Tijs)
#
class StudentAddToCourseForm(forms.Form):
    student_id = forms.ModelChoiceField(queryset=PersonalData.objects.filter(
        user__groups__name='Student'))
    # Hidden input because it's retrieved from the URL
    # course_id = forms.CharField(max_length=10, widget=forms.HiddenInput())

    exception_description = forms.CharField()


class AddAnnouncementForm(forms.ModelForm):
    class Meta:
        model = Announcement
        exclude = ('course', 'date', 'author')
