from django.apps import AppConfig


class VakbeheerConfig(AppConfig):
    name = 'vakbeheer'
