from django.apps import AppConfig


class CijferbeheerConfig(AppConfig):
    name = 'cijferbeheer'
