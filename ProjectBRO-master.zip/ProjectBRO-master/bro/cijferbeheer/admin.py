from django.contrib import admin
from .models import GradeTemplate, GradeInstance, GradeTemplateGroup

admin.site.register(GradeTemplate)
admin.site.register(GradeInstance)
admin.site.register(GradeTemplateGroup)
