from django.conf.urls import url
from persoonsgegevens.decorators import is_member, ADMIN, LECTURER, TA, \
        STUD, STUD_COORD
from . import views

app_name = 'grade_management'
groups = [ADMIN, LECTURER, TA, STUD_COORD]

urlpatterns = [
    url(r'^$', is_member(groups + [STUD], views.index), name="index"),

    url(r'grades/(?P<course_id>[0-9]+)/$',
        is_member(groups, views.course_grades), name="course_grades"),
    url(r'template/(?P<course_id>[0-9]+)$',
        is_member(groups, views.manage_grades), name="template"),
    url(r'group/(?P<course_id>[0-9]+)$',
        is_member(groups, views.manage_groups), name="group"),

    # add/<course_id_pk>/<assingment_id>
    url(r'add/(?P<course_id>[0-9]+)/(?P<grade_id>[0-9]+)',
        is_member(groups, views.add_grades), name="add_grades"),

    url(r'tree/(?P<group_id>[0-9]+)$',
        is_member(groups, views.grade_tree), name="tree"),
    url(r'student_tree/(?P<course_id>[0-9]+)/(?P<uvanetid>[a-zA-Z0-9_.-]+)$',
        views.student_tree, name="student_tree")
]
