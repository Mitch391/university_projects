from django import forms
from django.core.exceptions import ValidationError

from vakbeheer.models import CourseInstance
from .models import GradeTemplate, GradeInstance, GradeTemplateGroup


class GradeTemplateForm(forms.ModelForm):
    class Meta:
        model = GradeTemplate
        exclude = ()


GradeTemplateFormSet = forms.inlineformset_factory(
    CourseInstance,
    GradeTemplate,
    form=GradeTemplateForm,
    extra=1
)


class GradeInstanceForm(forms.ModelForm):
    class Meta:
        model = GradeInstance
        exclude = ('attempt', 'student')


GradeInstanceFormSet = forms.inlineformset_factory(
    GradeTemplate,
    GradeInstance,
    form=GradeInstanceForm,
    extra=0,
    can_delete=False
)


class GradeTemplateGroupForm(forms.ModelForm):

    class Meta:
        model = GradeTemplateGroup
        exclude = ()

    def clean(self):
        cleaned_data = super(GradeTemplateGroupForm, self).clean()
        templates = cleaned_data.get('templates')
        groups = cleaned_data.get('groups')

        if groups.all().count() == templates.all().count() == 0:
            raise ValidationError(
                    'Both templates and groups empty forbidden.',
                    code='invalid')

        if groups.all().count() > 0 and templates.all().count() > 0:
            raise ValidationError(
                    'Both templates and groups non-empty forbidden.',
                    code='invalid')


GradeTemplateGroupFormSet = forms.inlineformset_factory(
        CourseInstance,
        GradeTemplateGroup,
        form=GradeTemplateGroupForm,
        extra=1
)
