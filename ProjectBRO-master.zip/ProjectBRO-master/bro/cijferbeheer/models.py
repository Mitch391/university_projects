from django.db import models
from django.db.models import Max
from django.core.validators import MinValueValidator, MaxValueValidator
from persoonsgegevens.decorators import STUD
from persoonsgegevens.models import PersonalData
from vakbeheer.models import CourseInstance


class GradeTemplate(models.Model):
    """
    Defines a gradeable object for which students can be graded. Defines what
    to do with multiple attempts and min/max of grades.
    """
    NO_REDO = 0
    REDO_HIGHEST = 1
    REDO_LATEST = 2

    ACTIONS = [
        (NO_REDO, 'No redo'),
        (REDO_HIGHEST, 'Redo: highest attempt'),
        (REDO_LATEST, 'Redo: latest attempt')
    ]

    course_id = models.ForeignKey(CourseInstance, on_delete=models.CASCADE)
    grade_name = models.CharField(max_length=1024)
    redo_action = models.PositiveSmallIntegerField(
            help_text='How to deal with multiple attempts.',
            choices=ACTIONS, default=REDO_HIGHEST)

    @property
    def avg(self):
        """
        Returns the average grades for this GradeTemplate.
        """
        grades = GradeInstance.objects.filter(
                template=self, attempt=1)
        return sum((g.final_grade for g in grades)) / grades.count()

    def get_final_grade(self, uvanetid):
        attempts = GradeInstance.objects.filter(
                student__uvanetid=uvanetid, template=self)

        if not attempts.exists():
            return 0.0

        if self.redo_action == GradeTemplate.NO_REDO:
            return attempts.first().grade

        attempts = attempts.all()
        if self.redo_action == GradeTemplate.REDO_HIGHEST:
            return attempts.aggregate(Max('grade'))['grade__max']
        elif self.redo_action == GradeTemplate.REDO_LATEST:
            return attempts.latest().grade
        raise ValueError('impossible situation created')

    def save(self, *args, **kwargs):
        if not self.id:
            super(GradeTemplate, self).save(*args, **kwargs)

            from vakbeheer.models import CourseToStudent
            students = CourseToStudent.objects.filter(course=self.course_id)
            for student in students:
                grade = GradeInstance.objects.create(student=student.student,
                                                     template=self,
                                                     grade=0.0,
                                                     feedback="Auto generated",
                                                     attempt=1)
                grade.save()
        else:
            super(GradeTemplate, self).save(*args, **kwargs)

    def __str__(self):
        return self.course_id.template.name + ': ' + self.grade_name

    class Meta:
        unique_together = ('course_id', 'grade_name')
        ordering = ['course_id__template__name', 'grade_name']


class GradeInstance(models.Model):
    """
    Defines the grade of a student for a gradeable object (GradeTemplate).
    Calculation of final grade takes place here.
    """
    student = models.ForeignKey(
            PersonalData, limit_choices_to={'user__groups__name__in': [STUD]},
            on_delete=models.CASCADE)
    template = models.ForeignKey(
            GradeTemplate, on_delete=models.CASCADE)
    grade = models.FloatField(
            default=10.0, validators=[MinValueValidator(0.0)])
    feedback = models.CharField(default='#paupercode', max_length=1500)
    attempt = models.PositiveSmallIntegerField(editable=False)

    @property
    def final_grade(self):
        try:
            return self.template.get_final_grade(
                    self.student.uvanetid)
        except ValueError:
            return 0.0

    def save(self, *args, **kwargs):
        from vakbeheer.models import CourseToStudent

        # Only create GradeInstances for students following course.
        if not CourseToStudent.objects.filter(
                course=self.template.course_id).exists():
            raise ValueError('cannot grade student not following course.')

        # No redo means only one attempt.
        if not self.id and GradeInstance.objects.filter(
                student=self.student,
                template=self.template,
                template__redo_action=GradeTemplate.NO_REDO):
            raise ValueError('attempt already exists for non-redoable item')

        # Detect attempt number. Only when creating new GradeInstance.
        attempts = GradeInstance.objects.filter(
                student=self.student,
                template=self.template)
        if not self.id:
            self.attempt = attempts.count() + 1

        # Continue GradeInstance creation
        super(GradeInstance, self).save(*args, **kwargs)

    def __str__(self):
        return self.template.grade_name + ' for ' \
                + self.student.uvanetid

    class Meta:
        unique_together = ('student', 'template', 'attempt')
        get_latest_by = 'attempt'
        ordering = ['template__course_id__template__name',
                    'student']


class GradeTemplateGroup(models.Model):
    """
    Forms a group of GradeTemplateGroups or GradeTemplates. Grade is calculated
    by using the grades of said groups. Passing could mean that only one or all
    items are passed. Calculation of grade also takes place here.
    """
    OR = 0
    AND = 1
    ACTIONS = [
            (OR, 'At least one GradeTemplate must be passed.'),
            (AND, 'All GradeTemplates must be passed.'),
    ]
    HIGHEST = 2
    AVG = 3
    ACTIONS_CALC = [
            (HIGHEST, 'Highest grade'),
            (AVG, 'Average grade'),
    ]

    name = models.CharField(max_length=128, help_text='Name of the group.')
    course = models.ForeignKey(CourseInstance, on_delete=models.CASCADE)
    is_root = models.BooleanField(
            default=False,
            help_text='Used to calculate final grade.',
            verbose_name='final group')
    relation = models.PositiveSmallIntegerField(
            help_text='All or just one of the items inside must be passed.',
            choices=ACTIONS, default=AND)
    templates = models.ManyToManyField(
            GradeTemplate, blank=True, symmetrical=False,
            help_text='Ctrl+click to select multiple.')
    groups = models.ManyToManyField(
            'self', blank=True, symmetrical=False,
            help_text='Ctrl+click to select multiple.')
    minimum_abs = models.FloatField(
            default=1.0,
            help_text='Smallest sufficient grade.',
            verbose_name='absolute minimum')
    minimum_avg = models.FloatField(
            default=1.0,
            help_text='Smallest sufficient average grade.',
            verbose_name='average minimum')
    m_pass = models.IntegerField(
            blank=True, null=True,
            help_text='Check this amount of the highest grades for passing.'
                      + ' If empty, all grades in the group are used.',
            verbose_name='amount needed to pass')
    m_calc = models.IntegerField(
            blank=True, null=True,
            help_text='Check this amount of the highest grades for final grade'
                      + ' calculation. If empty, all grades in the group are used.',
            verbose_name='amount that counts')
    final_grade_calc = models.PositiveSmallIntegerField(
            choices=ACTIONS_CALC, default=AVG,
            help_text='Take the highest or the average grade.',
            verbose_name='mode of calculation')
    weight = models.IntegerField(
            default=100,
            validators=[MinValueValidator(0), MaxValueValidator(100)],
            help_text='Relative weight in relation to other groups of the '
                      + 'same level, in percentages.')

    @property
    def as_list(self):
        """
        Returns the GradeTemplateGroup and its descendants as a nested list
        in a human readable format.
        """
        root = {'name': self.name}
        if self.templates.all().count() > 0:
            root['children'] = [
                {'name': str(t)}
                for t in self.templates.all()]
        else:
            root['children'] = [{'name': g.name, 'children': g.as_list_inner}
                                for g in self.groups.all()]
        return [root]

    @property
    def as_list_inner(self):
        """
        Returns the GradeTemplateGroup and its descendants as a nested list
        in a human readable format.
        """
        if self.templates.all().count() > 0:
            return [{'name': str(t)} for t in self.templates.all()]
        else:
            return [{'name': g.name, 'children': g.as_list_inner}
                    for g in self.groups.all()]

    def as_list_stud(self, uvanetid):
        """
        Returns the GradeTemplateGroup and its descendants as a nested list
        in a human readable format.
        """
        root = {'name': self.name + ' (' + str(
            self.get_grade(uvanetid) if self.has_passed(uvanetid) else '-')
                    + ')'}
        if self.templates.all().count() > 0:
            root['children'] = [{
                'children': [{'children': [{'name': a.feedback}],
                              'name': 'Attempt ' + str(a.attempt) + ' (' +
                              str(a.grade) + ')'} for
                             a in GradeInstance.objects.filter(
                                template=t,
                                student__uvanetid=uvanetid)], 'name': str(t) + ' (' + (str(t.get_final_grade(uvanetid))) + ')'} for t in self.templates.all()]
        else:
            root['children'] = [{'name': g.name + ' (' + (str(g.get_grade(uvanetid) if g.has_passed(uvanetid) else '-')) + ')', 'children': g.as_list_stud_inner(uvanetid)} for g in self.groups.all()]
        return [root]

    def as_list_stud_inner(self, uvanetid):
        """
        Returns the GradeTemplateGroup and its descendants as a nested list
        in a human readable format.
        """
        if self.templates.all().count() > 0:
            return [{'children': [{'children': [{'name': a.feedback}], 'name': 'Attempt ' + str(a.attempt) + ' (' + str(a.grade) + ')'} for a in GradeInstance.objects.filter(template=t, student__uvanetid=uvanetid)], 'name': str(t) + ' (' + (str(t.get_final_grade(uvanetid))) + ')'} for t in self.templates.all()]
        else:
            return [{'name': g.name + ' (' + str(g.get_grade(uvanetid) if g.has_passed(uvanetid) else '-') + ')', 'children': g.as_list_stud_inner} for g in self.groups.all()]

    class Meta:
        ordering = ['name']

    def has_passed(self, uvanetid):
        """
        Returns whether the grading requirements are passed.
        """
        from math import isnan

        if self.templates.all().count() != 0:
            passing = self.relation == GradeTemplateGroup.AND
            grades = sorted((t.get_final_grade(uvanetid)
                             for t in self.templates.all()), reverse=True)

            if self.m_pass:
                grades = grades[:self.m_pass]

            total_grade = sum(grades)

            if self.relation == GradeTemplateGroup.AND and isnan(total_grade):
                return False

            for g in grades:
                if self.relation == GradeTemplateGroup.AND \
                        and g < self.minimum_abs:
                    return False
                if self.relation == GradeTemplateGroup.OR \
                        and g >= self.minimum_abs:
                    passing = True

            return passing and ((total_grade / self.templates.all().count())
                                >= self.minimum_avg)

        if self.groups.all().count() != 0:
            group_pass = (g.has_passed(uvanetid) for g in self.groups.all())
            if self.relation == GradeTemplateGroup.OR:
                return True in group_pass
            elif self.relation == GradeTemplateGroup.AND:
                return not (False in group_pass)

        return False

    def __str__(self):
        s = self.course.template.name + ': ' + self.name
        if self.templates.all().count() > 0:
            return s + ' (group of gradeable objects)'
        return s + ' (group of gradeable object groups)'

    def print(self):
        """
        Returns a human-readable string of this object. Is much complexer than
        the __str__(self) implementation.
        """
        s = list()

        # Members
        members = 'The group consists of the following '
        members += 'GradeTemplates' if self.templates.count() > 0 else \
                   'GradeTemplateGroups'
        members += ': '
        if self.templates.count() > 0:
            for t in self.templates.all():
                members += t.grade_name + ', '
        else:
            for g in self.groups.all():
                members += '<li>' + g.name + ', '
        s.append(members[:-2])

        # Relation
        relation = 'One' if self.relation == self.OR else 'All'
        relation += ' of the underlying objects must be passed.'
        s.append(relation)

        # Minimum grade
        min_g = ' The minimum grade for each object is ' \
            + str(self.minimum_abs)
        s.append(min_g + '.')

        # Minimum average
        min_avg = 'The minimum average grade for the objects is '
        min_avg += str(self.minimum_avg) + '. '
        s.append(min_avg)

        # Check m highest grades for passing
        if self.m_pass:
            m1 = 'Only the ' + str(self.m_pass) + ' highest grades are checked'
            m1 += ' for meeting the passing requirements.'
            s.append(m1)
        # Calculate final grade based on m highest grades
        if self.m_calc:
            m2 = 'Only the ' + str(self.m_calc) + ' highest grades are used to'
            m2 += ' calculate the final grade for this group. '
            s.append(m2)
        # Highest or average?
        final = 'The final grade is the ' + (
            'highest' if self.final_grade_calc == self.HIGHEST else 'average')
        final += ' grade of the inner objects to be counted.'
        s.append(final)

        # Weight
        w = " Its relative weight with other groups on the same level is "
        w += str(self.weight) + '%.'
        s.append(w)
        return s

    def get_grade(self, uvanetid):
        """
        Returns the current grade for this grading group. Does not mean that
        the requirements are passed.
        """
        weight = self.weight / 100.0
        if self.relation == GradeTemplateGroup.OR:
            weight = 1.0

        if self.templates.all().count() != 0:
            grades = sorted((t.get_final_grade(uvanetid)
                             for t in self.templates.all()), reverse=True)
            if self.m_calc:
                grades = grades[:self.m_calc]
            if self.final_grade_calc == GradeTemplateGroup.AVG:
                return sum(grades) / len(grades)
            if self.final_grade_calc == GradeTemplateGroup.HIGHEST:
                return max(grades)
            return 0.0

        if self.groups.all().count() != 0:
            grades = sorted((g.get_grade(uvanetid) for g in self.groups.all()),
                            reverse=True)
            if self.m_calc:
                grades = grades[:self.m_calc]
            if self.final_grade_calc == GradeTemplateGroup.AVG:
                return weight * (sum(grades) / len(grades))
            if self.final_grade_calc == GradeTemplateGroup.HIGHEST:
                return weight * max(grades)

        return 0.0
