from django.db.models import Q
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django.core.urlresolvers import reverse_lazy
from django.shortcuts import get_object_or_404, render, redirect
from django.urls import reverse

from persoonsgegevens.models import PersonalData
from persoonsgegevens.decorators import owns_course_or_403
from vakbeheer.models import CourseInstance, CourseToStudent, CourseTemplate,\
    CourseToLecturer, CourseToAssistant

from .models import GradeTemplate, GradeInstance, GradeTemplateGroup
from .forms import GradeTemplateFormSet, GradeTemplateGroupFormSet, \
    GradeInstanceFormSet

GROUP_STUDENTS = 8
GROUP_TAS = 10


def index(request):
    """Loads connected courses in grade management."""
    template = loader.get_template("cijferbeheer.html")
    uvanetid = request.user.username
    args = dict()

    args['as_ta'] = list()
    for c in CourseToAssistant.objects.filter(assistant=uvanetid):
        args['as_ta'].append({
            'url': reverse('grade_management:course_grades', args=[c.id]),
            'name': c.course.template.name
        })

    args['as_student'] = list()
    for c in CourseToStudent.objects.filter(student=uvanetid):
        args['as_student'].append({
            'url': reverse('course_management:grades', args=[c.course.id]),
            'name': c.course.template.name,
            'grade_list': GradeInstance.objects.filter(
                student__uvanetid=uvanetid,
                template__course_id=c.course),
            'grade': c.final_grade if c.passed else '-',
            'passed': c.passed,
            'id': c.course.id
        })

    args['as_coord'] = list()
    for c in CourseInstance.objects.filter(
            template__in=CourseTemplate.objects.filter(
                coordinator__uvanetid=uvanetid)):
        args['as_coord'].append({
            'url': reverse('grade_management:course_grades', args=[c.id]),
            'name': str(c)
        })

    args['as_lec'] = list()
    for c in CourseToLecturer.objects.filter(uvanetid=uvanetid):
        args['as_lec'].append({
            'url': reverse('grade_management:course_grades', args=[c.id]),
            'name': c.course.template.name
        })

    return HttpResponse(template.render(args, request))


def get_default_context(request, course_id):
    courses = CourseInstance.objects.filter(
        # coordinator
        Q(template__coordinator_id=request.user.username) |
        # lecturers
        Q(coursetolecturer__uvanetid_id=request.user.username)
    )

    course = CourseInstance.objects.get(id=course_id)
    assistants = CourseToAssistant.objects.filter(course=course)
    students = CourseToStudent.objects.filter(course=course)

    all_assistants = PersonalData.objects\
        .filter(user__groups__in=[GROUP_TAS])
    all_students = PersonalData.objects\
        .filter(user__groups__in=[GROUP_STUDENTS])
    grade_templates = GradeTemplate.objects\
        .filter(course_id=course)

    context = {
        'courses': courses,
        'course_name': course,
        'course_assistance': assistants,
        'course_id': int(course_id),
        'course_students': students,
        'all_assistants': all_assistants,
        'all_students': all_students,
        'grade_templates': grade_templates,
    }
    return context


def course_grades(request, course_id):
    context = get_default_context(request, course_id)
    context['groups'] = GradeTemplateGroup.objects.filter(
            course=context['course_name'], is_root=True)
    template = loader.get_template('grade_overview.html')
    return HttpResponse(template.render(context, request))


def grades_form_add_row(request, course):
    copy = request.POST.copy()
    copy['template-TOTAL_FORMS'] = int(copy['template-TOTAL_FORMS']) + 1
    return GradeTemplateFormSet(copy, prefix='template', instance=course)


def grades_form_submit(request, course):
    formset = GradeTemplateFormSet(request.POST, prefix='template',
                                   instance=course)

    if formset.is_valid():
        forms = formset.save()
        students = CourseToStudent.objects.filter(course=course)\
                                          .values('student')

        for student in students:
            student_obj = get_object_or_404(PersonalData.objects,
                                            uvanetid=student['student'])

            for form in forms:
                template = get_object_or_404(GradeTemplate.objects, pk=form.id)
                GradeInstance.objects.create(student=student_obj,
                                             template=template,
                                             grade=0, feedback="")


def manage_grades(request, course_id):
    """Create new grade template for the course 'course_id'."""
    course = get_object_or_404(CourseInstance.objects, pk=course_id)
    owns_course_or_403(request, course)

    if request.method == "POST":
        if 'add-row' in request.POST:
            formset = grades_form_add_row(request, course)
        else:
            grades_form_submit(request, course)

            # TODO redirect to the right page
            return HttpResponseRedirect(
                reverse_lazy('grade_management:course_grades', args=course_id))
    else:
        formset = GradeTemplateFormSet(prefix='template', instance=course)

    # render the form: blank or with an extra row
    context = {**{'formset': formset},
               **get_default_context(request, course_id)}
    return render(request, 'update_grade_template.html', context)


def grades_group_add_row(request, course):
    copy = request.POST.copy()
    copy['group-TOTAL_FORMS'] = int(copy['group-TOTAL_FORMS']) + 1
    return GradeTemplateGroupFormSet(copy, prefix='group', instance=course)


def manage_groups(request, course_id):
    """Create new grade template group for the course 'courde_id'."""
    course = get_object_or_404(CourseInstance.objects, pk=course_id)
    owns_course_or_403(request, course)
    formset = GradeTemplateGroupFormSet(request.POST, prefix='group',
                                        instance=course)

    if request.method == "POST":
        if 'add-row' in request.POST:
            formset = grades_group_add_row(request, course)
        elif formset.is_valid():
            formset.save()
            return redirect('grade_management:group', course_id=course_id)
    else:
        formset = GradeTemplateGroupFormSet(prefix='group', instance=course)

    # render the form: blank or with an extra row
    context = {**{'formset': formset},
               **get_default_context(request, course_id)}
    return render(request, 'update_grade_template_groups.html', context)


def add_grades(request, course_id, grade_id):
    student_ids = []

    course = get_object_or_404(CourseInstance.objects, pk=course_id)
    owns_course_or_403(request, course)
    assign_template = get_object_or_404(GradeTemplate.objects, pk=grade_id)

    students = GradeInstance.objects.filter(
            template__id=grade_id).values('student')
    for student in students:
        student_ids.append(student['student'])

    if request.method == "POST":
        # The form is submitted
        formset = GradeInstanceFormSet(request.POST, instance=assign_template)
        if formset.is_valid():
            formset.save()
            # TODO redirect to the right page
            return HttpResponseRedirect(reverse_lazy(
                'grade_management:course_grades', args=course_id))
    else:
        # The form is blank
        formset = GradeInstanceFormSet(instance=assign_template)

    if students.count() == 0:
        context = {**{'formset': formset, 'data': None},
                   **get_default_context(request, course_id)}
    else:
        context = {**{'formset': formset, 'data': zip(formset, student_ids)},
                   **get_default_context(request, course_id)}

    return render(request, 'cijferbeheer/gradeinstance_form.html', context)


def grade_tree(request, group_id):
    group = get_object_or_404(GradeTemplateGroup, pk=group_id)
    owns_course_or_403(request, group.course)
    from django.http import JsonResponse
    return JsonResponse(group.as_list, safe=False)


def student_tree(request, course_id, uvanetid):
    obj = CourseToStudent.objects.filter(student__uvanetid=uvanetid, course_id__id=course_id)
    if not obj.exists():
        from django.http import Http404
        raise Http404
    from django.http import JsonResponse
    return JsonResponse(obj.first().grades_as_list, safe=False)
