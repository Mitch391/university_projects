$(document).ready(function(){
    $('.add-row').click(function() {
        add_req_row($(this).parent(), $('.add-row').index(this));
    });
    $('#add-block').click(function() {
        add_req_group($(this).parent().parent());
    });
    $('.requirement').find('select').change(function() {
        change_widget($(this).find(":selected").text().split(':')[0],
            $(this).parent().parent().find("[id$=accepted_value]").first());
    });
    $('#add-study').click(function() {
        add_study_row('div.studyform:last', 'study');
    })
    $('.del-study, .del-block, .del-row').click(function() {
        del_form($(this).parent());
    });
    $(document).find("[for$=DELETE]").attr('style', 'display: none');
    $(document).find("[name$=DELETE]").attr('style', 'display: none');
});

function create_group_element(){
    var group_html = $('<div>', {class: "req-group card"});

    del_button = $('<div>', {class: 'del-block flat button right'});
    del_button.append($('<img>', {src: '/static/images/trash.svg'}));
    $(del_button).click(function() {
        del_form($(this).parent());
    });
    group_html.append(del_button);

    input_div = $('<div>');
    input_div.append($('<h2>', {text: "Requirements block"}));
    group_html.append(input_div);

    extra_div = $('<div>', {class: "extra_padding"});
    input_div = $('<div>', {class: "sfinput"});
    input_div.append($('<label>', {text: "Req amount"}));
    input_div.append($('<input>', {min: "0", type: "number"}));
    extra_div.append(input_div);

    input_div = $('<div>', {class: "sfinput"});
    input_div.append($('<label>', {text: "Delete:", style: "display: none"}));
    input_div.append($('<input>', {type: "checkbox", style: "display: none"}));
    extra_div.append(input_div);

    input_div = $('<div>');
    input_div.append($('<input>', {type: "hidden"}));
    input_div.append($('<input>', {type: "hidden"}));
    extra_div.append(input_div);

    group_html.append(extra_div);


    button = $('<input>', {class: "add-row button right flat", value: "Add Requirement", type: "button"});
    button.click(function() {
        add_req_row($(this).parent(), $('.add-row').index(this));
    });
    group_html.append(button);

    input_div = $('<div>', {class: "newblock"});
    input_div.append($('<h3>', {text: "Requirements for this block"}));
    group_html.append(input_div);

    group_html.append($('<input>', {value: "0", type: "hidden"}));
    group_html.append($('<input>', {value: "0", type: "hidden"}));
    group_html.append($('<input>', {value: "0", type: "hidden"}));
    group_html.append($('<input>', {value: "0", type: "hidden"}));

    return group_html;
}

function create_req_element(){
    var req_html = $('<div>', {class: "requirement separated extra_padding"});

    del_button = $('<div>', {class: 'del-row flat button right'});
    del_button.append($('<img>', {src: '/static/images/trash.svg'}));
    $(del_button).click(function() {
        del_form($(this).parent());
    });
    req_html.append(del_button);

    input_div = $('<div>', {class: "sfinput extra_padding"});
    input_div.append($('<label>', {text: "Template:"}));
    select_list = $('<select>');
    $(template_list).each(function() {
        select_list.append(this.clone());
    });
    select_list.change(function() {
        change_widget($(this).find(":selected").text().split(':')[0],
            $(this).parent().parent().find("[id$=accepted_value]").first());
    });
    input_div.append(select_list);
    req_html.append(input_div);

    input_div = $('<div>', {class: "sfinput"});
    input_div.append($('<label>', {text: "Accepted Value"}));
    input_div.append($('<input>', {max_length: 128}));
    req_html.append(input_div);

    input_div = $('<div>', {class: "sfinput"});
    input_div.append($('<label>', {text: "Delete:", style: "display: none"}));
    input_div.append($('<input>', {type: "checkbox", style: "display: none"}));
    req_html.append(input_div);

    req_html.append($('<input>', {type: "hidden"}));
    req_html.append($('<input>', {type: "hidden"}));

    return req_html
}

function add_req_group(selector){
    var newElement = create_group_element();
    var this_id = 'courseregreqgroup_set';
    var total = $('#id_' + this_id + '-TOTAL_FORMS').val();

    var name_list = ['req_amount', 'DELETE', 'course_template', 'id', null,
        'TOTAL_FORMS', 'INITIAL_FORMS', 'MIN_NUM_FORMS', 'MAX_NUM_FORMS'];

    var inputs = newElement.find(':input');
    inputs.each(function() {
        if($(this).hasClass('del-block'))
            return;
        var index = inputs.index(this);
        var tag = index < 4 ? this_id + '-' : '';
        var name = tag + total + '-' + name_list[index];
        var id = 'id_' + tag + total + '-' + name_list[index];
        $(this).attr({'name': name, 'id': id}).removeAttr('checked');
    });
    var labels = newElement.find('label');
    labels.each(function() {
        var index = labels.index(this);
        var newFor = 'id_' + this_id + '-' + total + '-' + name_list[index];
        $(this).attr('for', newFor);
    });
    total++;
    $('#id_' + this_id + '-TOTAL_FORMS').val(total);
    $(selector).append(newElement);
}

function add_req_row(selector, group_id){
    var newElement = create_req_element();
    var total = $('#id_' + group_id + '-TOTAL_FORMS').val();
    var name_list = ['template', 'accepted_value', 'DELETE', 'req-group', 'id'];
    var inputs = newElement.find(':input');
    inputs.each(function() {
        if($(this).hasClass('del-row'))
            return;
        var index = inputs.index(this);
        var name = group_id + '-' + total + '-' + name_list[index];
        var id = 'id_' + group_id + '-' + total + '-' + name_list[index];
        $(this).attr({'name': name, 'id': id}).removeAttr('checked');
    });
    var labels = newElement.find('label');
    labels.each(function() {
        var index = labels.index(this);
        var newFor = 'id_' + group_id + '-' + total + '-' + name_list[index];
        $(this).attr('for', newFor);
    });
    total++;
    $('#id_' + group_id + '-TOTAL_FORMS').val(total);
    $(selector).append(newElement);
}

function del_form(form_div){
   form_div.find("[name$=DELETE]").attr('checked', true);
   form_div.attr('style', 'display: none');
}

function add_study_row(selector, type) {
    var newElement = $(selector).clone(true);
    var total = $('#id_' + type + '-TOTAL_FORMS').val();
    newElement.find(':input').each(function() {
        if($(this).hasClass('del-study')){
            $(this).removeAttr('checked');
            return;
        }
        var name = $(this).attr('name').replace('-' + (total-1) + '-','-' + total + '-');
        var id = 'id_' + name;
        $(this).attr({'name': name, 'id': id}).val('').removeAttr('checked');
    });
    newElement.find('label').each(function() {
        var newFor = $(this).attr('for').replace('-' + (total-1) + '-','-' + total + '-');
        $(this).attr('for', newFor);
    });
    total++;
    $('#id_' + type + '-TOTAL_FORMS').val(total);
    newElement.attr('style', '');
    $(selector).after(newElement);
}
