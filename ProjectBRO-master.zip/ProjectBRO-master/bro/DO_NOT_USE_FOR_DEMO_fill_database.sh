#! /bin/bash
set -e

# bachelor student: 1234
# master student en TA: 10985
# docent en coord: Teacher1
# docent: Teacher2
# adviseur: Advisor

# cd to bro folder
cd "$(dirname "$0")"

dropdb bro || true

createdb bro
rm -rf */migrations/__pycache__/
rm -f cijferbeheer/migrations/000*
rm -f persoonsgegevens/migrations/000*
rm -f s*/migrations/000*
rm -f v*/migrations/000*
python3 manage.py makemigrations
python3 manage.py migrate
python3 manage.py migrate --run-syncdb

# only execute in bro folder
#create superuser
echo "from django.contrib.auth.models import User; User.objects.create_superuser('admin', 'admin@example.com', 'pass1234')" | python3 manage.py shell

echo "Making accounts..."

# assign superuser groups and make PersonalData
echo "from django.contrib.auth.models import User; 
from persoonsgegevens.views import PersonalData;
from django.contrib.auth.models import Group; 
y=User.objects.get(id=1);
y.groups.add(Group.objects.get(name='Student'))
y.groups.add(Group.objects.get(name='Docent'))
y.groups.add(Group.objects.get(name='TA'))
y.groups.add(Group.objects.get(name='Functioneel Beheerder'))
y.save();
x=PersonalData();
x.user=y;
x.uvanetid='admin';
x.name='admin';
x.surname='admin';
x.email='admin@ad.min';
x.save();
" | python3 manage.py shell

# make Student
echo "from django.contrib.auth.models import User; 
from persoonsgegevens.views import PersonalData;
from django.contrib.auth.models import Group; 
y=User.objects.create_user('1234', 'henk.greve@student.uva.com', 'pass1234');
y.save();
y.groups.add(Group.objects.get(name='Student'));
y.save();
x=PersonalData();
x.user=y;
x.uvanetid='1234';
x.name='Henk';
x.surname='Greve';
x.email='henk.studentman@uva.co';
x.save();
" | python3 manage.py shell

# make Coordinator
echo "from django.contrib.auth.models import User; 
from persoonsgegevens.views import PersonalData;
from django.contrib.auth.models import Group; 
y=User.objects.create_user('Teacher1', 'doc.docentman@uva.co', 'pass1234');
y.save();
y.groups.add(Group.objects.get(name='Docent'));
y.groups.add(Group.objects.get(name='Opleidingscoordinator'));
y.save();
x=PersonalData();
x.user=y;
x.uvanetid='Teacher1';
x.name='Rein';
x.surname='van den Boomgaard';
x.email='doc.docentman@uva.com';
x.save()
" | python3 manage.py shell

# make Docent
echo "from django.contrib.auth.models import User; 
from persoonsgegevens.views import PersonalData;
from django.contrib.auth.models import Group; 
y=User.objects.create_user('Teacher2', 'teacher@teach.er', 'pass1234');
y.save();
y.groups.add(Group.objects.get(name='Docent'));
y.save();
x=PersonalData();
x.user=y;
x.uvanetid='Teacher2';
x.name='Leen';
x.surname='Torenvliet';
x.email='teacher@teach.er';
x.save()
" | python3 manage.py shell

# make TA that is also student
echo "from django.contrib.auth.models import User; 
from persoonsgegevens.views import PersonalData;
from django.contrib.auth.models import Group; 
y=User.objects.create_user('10985', 'maria.zwijger@student.uva.nl', 'pass1234');
y.save();
y.groups.add(Group.objects.get(name='Student'));
y.groups.add(Group.objects.get(name='TA'));
y.save();
x=PersonalData();
x.user=y;
x.uvanetid='10985';
x.name='Maria';
x.surname='Zwijger';
x.email='maria.student2@uva.co';
x.save();
" | python3 manage.py shell


# make Studieadviseur
echo "from django.contrib.auth.models import User; 
from persoonsgegevens.views import PersonalData;
from django.contrib.auth.models import Group; 
y=User.objects.create_user('Advisor', 'jan.deadviesman@uva.co', 'pass1234');
y.save();
y.groups.add(Group.objects.get(name='Studieadviseur'));
y.save();
x=PersonalData();
x.user=y;
x.uvanetid='Advisor';
x.name='Jan';
x.surname='de Adviesman';
x.email='jan.deadviesman@uva.co';
x.save();
" | python3 manage.py shell

echo "Making studies..."

# make StudyTemplate
echo "from studieopbouw.views import StudyTemplate;
from persoonsgegevens.views import PersonalData;
coord=PersonalData.objects.get(uvanetid='Teacher1');
advis=PersonalData.objects.get(uvanetid='Advisor');
bach=StudyTemplate();
bach.id=1;
bach.name='Informatica';
bach.type=0;
bach.coordinator=coord;
bach.advisor=advis;
bach.duration=3;
bach.study_code='1111';
bach.save();
mast=StudyTemplate();
mast.id=2;
mast.name='Computational Science';
mast.type=1;
mast.coordinator=coord;
mast.advisor=advis;
mast.duration=1;
mast.study_code='2222';
mast.save();
bach2=StudyTemplate();
bach.id=3;
bach.name='Wiskunde';
bach.type=0;
bach.coordinator=coord;
bach.advisor=advis;
bach.duration=3;
bach.study_code='3333';
bach.save();
" | python3 manage.py shell

# make StudyInstances
echo "from studieopbouw.views import StudyTemplate;
from studieopbouw.views import StudyInstance;
bach_temp=StudyTemplate.objects.get(name='Informatica');
bach_inst=StudyInstance();
bach_inst.template=bach_temp;
bach_inst.start_year=2016;
bach_inst.save();
mast_temp=StudyTemplate.objects.get(name='Computational Science');
mast_inst=StudyInstance();
mast_inst.template=mast_temp;
mast_inst.start_year=2016;
mast_inst.save();
bach_temp=StudyTemplate.objects.get(name='Wiskunde');
bach_inst=StudyInstance();
bach_inst.template=bach_temp;
bach_inst.start_year=2016;
bach_inst.save();
" | python3 manage.py shell

echo "Making courses..."

# make bachelor courses templates
echo "from vakopbouw.views import CourseTemplate;
from persoonsgegevens.views import PersonalData;
coord=PersonalData.objects.get(uvanetid='Teacher1');
course1=CourseTemplate();
course1.name='Programmeertalen';
course1.EC=6;
course1.coordinator=coord;
course1.course_id=1;
course1.course_code='PROG';
course1.start_period=1;
course1.end_period=2;
course1.save()
course2=CourseTemplate();
course2.name='Beeldbewerken';
course2.EC=6;
course2.coordinator=coord;
course2.course_id=2;
course2.course_code='BEEL';
course2.start_period=1;
course2.end_period=2;
course2.save()
course3=CourseTemplate();
course3.name='Lineaire Algebra';
course3.EC=6;
course3.coordinator=coord;
course3.course_id=3;
course3.course_code='PERI';
course3.start_period=1;
course3.end_period=2;
course3.save()
" | python3 manage.py shell

# make master courses templates
echo "from vakopbouw.views import CourseTemplate;
from persoonsgegevens.views import PersonalData;
coord=PersonalData.objects.get(uvanetid='Teacher1');
course1=CourseTemplate();
course1.name='Advanced Selforganisation';
course1.EC=6;
course1.coordinator=coord;
course1.course_id=4;
course1.course_code='MPRO';
course1.start_period=1;
course1.end_period=2;
course1.save()
course2=CourseTemplate();
course2.name='Bounded Rationality';
course2.EC=6;
course2.coordinator=coord;
course2.course_id=5;
course2.course_code='MBEE';
course2.start_period=1;
course2.end_period=2;
course2.save()
course3=CourseTemplate();
course3.name='Periodieke Algebra';
course3.EC=6;
course3.coordinator=coord;
course3.course_id=6;
course3.course_code='MPER';
course3.start_period=1;
course3.end_period=2;
course3.save()
" | python3 manage.py shell

# make bachelor courses
echo "from vakopbouw.views import CourseTemplate;
from vakbeheer.views import CourseInstance;
from vakbeheer.models import CourseToAssistant;
from vakbeheer.models import CourseToLecturer;
from vakbeheer.models import CourseToStudent;
from persoonsgegevens.views import PersonalData;
teach=PersonalData.objects.get(uvanetid='Teacher2');
course=CourseTemplate.objects.get(name='Programmeertalen');
c_instance=CourseInstance();
c_instance.template=course;
c_instance.save()
c_to_lec=CourseToLecturer();
c_to_lec.course=c_instance;
c_to_lec.uvanetid=teach;
c_to_lec.save();
course=CourseTemplate.objects.get(name='Beeldbewerken');
c_instance=CourseInstance();
c_instance.template=course;
c_instance.save()
c_to_lec=CourseToLecturer();
c_to_lec.course=c_instance;
c_to_lec.uvanetid=teach;
c_to_lec.save();
course=CourseTemplate.objects.get(name='Lineaire Algebra');
c_instance=CourseInstance();
c_instance.template=course;
c_instance.save()
c_to_lec=CourseToLecturer();
c_to_lec.course=c_instance;
c_to_lec.uvanetid=teach;
c_to_lec.save();
" | python3 manage.py shell

# make master courses
echo "from vakopbouw.views import CourseTemplate;
from vakbeheer.views import CourseInstance;
from vakbeheer.models import CourseToAssistant;
from vakbeheer.models import CourseToLecturer;
from vakbeheer.models import CourseToStudent;
from persoonsgegevens.views import PersonalData;
teach=PersonalData.objects.get(uvanetid='Teacher2');
course=CourseTemplate.objects.get(name='Advanced Selforganisation');
c_instance=CourseInstance();
c_instance.template=course;
c_instance.save()
c_to_lec=CourseToLecturer();
c_to_lec.course=c_instance;
c_to_lec.uvanetid=teach;
c_to_lec.save();
course=CourseTemplate.objects.get(name='Bounded Rationality');
c_instance=CourseInstance();
c_instance.template=course;
c_instance.save()
c_to_lec=CourseToLecturer();
c_to_lec.course=c_instance;
c_to_lec.uvanetid=teach;
c_to_lec.save();
course=CourseTemplate.objects.get(name='Periodieke Algebra');
c_instance=CourseInstance();
c_instance.template=course;
c_instance.save()
c_to_lec=CourseToLecturer();
c_to_lec.course=c_instance;
c_to_lec.uvanetid=teach;
c_to_lec.save();
" | python3 manage.py shell

echo "Assigning students to courses..."

# make bachelor course to student and course to assistants
echo "from vakopbouw.views import CourseTemplate;
from vakbeheer.views import CourseInstance;
from vakbeheer.models import CourseToAssistant;
from vakbeheer.models import CourseToLecturer;
from vakbeheer.models import CourseToStudent;
from persoonsgegevens.views import PersonalData;
student1=PersonalData.objects.get(uvanetid='1234');
ta=PersonalData.objects.get(uvanetid='10985');
temp=CourseTemplate.objects.get(name='Programmeertalen');
course=CourseInstance.objects.get(template=temp);
c_to_stud=CourseToStudent();
c_to_stud.course=course;
c_to_stud.student=student1;
c_to_stud.exception_description='null';
c_to_stud.save();
c_to_ta=CourseToAssistant();
c_to_ta.course=course;
c_to_ta.assistant=ta;
c_to_ta.save();
temp=CourseTemplate.objects.get(name='Beeldbewerken');
course=CourseInstance.objects.get(template=temp);
c_to_stud=CourseToStudent();
c_to_stud.course=course;
c_to_stud.student=student1;
c_to_stud.exception_description='null';
c_to_stud.save();
c_to_ta=CourseToAssistant();
c_to_ta.course=course;
c_to_ta.assistant=ta;
c_to_ta.save();
temp=CourseTemplate.objects.get(name='Lineaire Algebra');
course=CourseInstance.objects.get(template=temp);
c_to_stud=CourseToStudent();
c_to_stud.course=course;
c_to_stud.student=student1;
c_to_stud.exception_description='null';
c_to_stud.save();
c_to_ta=CourseToAssistant();
c_to_ta.course=course;
c_to_ta.assistant=ta;
c_to_ta.save();
" | python3 manage.py shell


# make master course to student
echo "from vakopbouw.views import CourseTemplate;
from vakbeheer.views import CourseInstance;
from vakbeheer.models import CourseToAssistant;
from vakbeheer.models import CourseToLecturer;
from vakbeheer.models import CourseToStudent;
from persoonsgegevens.views import PersonalData;
student1=PersonalData.objects.get(uvanetid='10985');
temp=CourseTemplate.objects.get(name='Advanced Selforganisation');
course=CourseInstance.objects.get(template=temp);
c_to_stud=CourseToStudent();
c_to_stud.course=course;
c_to_stud.student=student1;
c_to_stud.exception_description='null';
c_to_stud.save();
temp=CourseTemplate.objects.get(name='Bounded Rationality');
course=CourseInstance.objects.get(template=temp);
c_to_stud=CourseToStudent();
c_to_stud.course=course;
c_to_stud.student=student1;
c_to_stud.exception_description='null';
c_to_stud.save();
temp=CourseTemplate.objects.get(name='Periodieke Algebra');
course=CourseInstance.objects.get(template=temp);
c_to_stud=CourseToStudent();
c_to_stud.course=course;
c_to_stud.student=student1;
c_to_stud.exception_description='null';
c_to_stud.save();
" | python3 manage.py shell

echo "Making study to courses..."

# make study to course templates
echo "from vakopbouw.views import CourseTemplate;
from studieopbouw.models import StudyToCourseTemplate;
from studieopbouw.views import StudyTemplate;
bach=StudyTemplate.objects.get(name='Informatica');
mast=StudyTemplate.objects.get(name='Computational Science');
course=CourseTemplate.objects.get(name='Programmeertalen');
s_to_c=StudyToCourseTemplate();
s_to_c.study=bach;
s_to_c.course=course;
s_to_c.year=1;
s_to_c.save();
course=CourseTemplate.objects.get(name='Beeldbewerken');
s_to_c=StudyToCourseTemplate();
s_to_c.study=bach;
s_to_c.course=course;
s_to_c.year=1;
s_to_c.save();
course=CourseTemplate.objects.get(name='Lineaire Algebra');
s_to_c=StudyToCourseTemplate();
s_to_c.study=bach;
s_to_c.course=course;
s_to_c.year=1;
s_to_c.save();
course=CourseTemplate.objects.get(name='Advanced Selforganisation');
s_to_c=StudyToCourseTemplate();
s_to_c.study=mast;
s_to_c.course=course;
s_to_c.year=1;
s_to_c.save();
course=CourseTemplate.objects.get(name='Bounded Rationality');
s_to_c=StudyToCourseTemplate();
s_to_c.study=mast;
s_to_c.course=course;
s_to_c.year=1;
s_to_c.save();
course=CourseTemplate.objects.get(name='Periodieke Algebra');
s_to_c=StudyToCourseTemplate();
s_to_c.study=mast;
s_to_c.course=course;
s_to_c.year=1;
s_to_c.save();
" | python3 manage.py shell

# make study to course instances
echo "from vakopbouw.views import CourseTemplate;
from vakbeheer.views import CourseInstance;
from studieopbouw.views import StudyToCourseInstance;
from studieopbouw.views import StudyInstance;
from studieopbouw.views import StudyTemplate;
bach_temp=StudyTemplate.objects.get(name='Informatica');
mast_temp=StudyTemplate.objects.get(name='Computational Science');
bach=StudyInstance.objects.get(template=bach_temp);
mast=StudyInstance.objects.get(template=mast_temp);
temp=CourseTemplate.objects.get(name='Programmeertalen');
course=CourseInstance.objects.get(template=temp);
s_to_c=StudyToCourseInstance();
s_to_c.study=bach;
s_to_c.course=course;
s_to_c.save();
temp=CourseTemplate.objects.get(name='Beeldbewerken');
course=CourseInstance.objects.get(template=temp);
s_to_c=StudyToCourseInstance();
s_to_c.study=bach;
s_to_c.course=course;
s_to_c.save();
temp=CourseTemplate.objects.get(name='Lineaire Algebra');
course=CourseInstance.objects.get(template=temp);
s_to_c=StudyToCourseInstance();
s_to_c.study=bach;
s_to_c.course=course;
s_to_c.save();
temp=CourseTemplate.objects.get(name='Advanced Selforganisation');
course=CourseInstance.objects.get(template=temp);
s_to_c=StudyToCourseInstance();
s_to_c.study=mast;
s_to_c.course=course;
s_to_c.save();
temp=CourseTemplate.objects.get(name='Bounded Rationality');
course=CourseInstance.objects.get(template=temp);
s_to_c=StudyToCourseInstance();
s_to_c.study=mast;
s_to_c.course=course;
s_to_c.save();
temp=CourseTemplate.objects.get(name='Periodieke Algebra');
course=CourseInstance.objects.get(template=temp);
s_to_c=StudyToCourseInstance();
s_to_c.study=mast;
s_to_c.course=course;
s_to_c.save();
" | python3 manage.py shell

echo "Making academic plans..."

# make academic plan
echo "from studieplan.views import AcademicPlan;
from studieplan.views import AcademicYearPlan;
from persoonsgegevens.views import PersonalData;
from studieopbouw.views import StudyInstance;
from studieopbouw.views import StudyTemplate;
bach_temp=StudyTemplate.objects.get(name='Informatica');
bach_temp2=StudyTemplate.objects.get(name='Wiskunde');
mast_temp=StudyTemplate.objects.get(name='Computational Science');
bach=StudyInstance.objects.get(template=bach_temp);
bach2=StudyInstance.objects.get(template=bach_temp2);
mast=StudyInstance.objects.get(template=mast_temp);
student1=PersonalData.objects.get(uvanetid='1234');
student2=PersonalData.objects.get(uvanetid='10985');
academicplan1=AcademicPlan();
academicplan1.student=student1;
academicplan1.study=bach;
academicplan1.save();
yearplan1=AcademicYearPlan();
yearplan1.id=1;
yearplan1.academic_plan=academicplan1;
yearplan1.time_block=1;
yearplan1.save();
academicplan2=AcademicPlan();
academicplan2.student=student2;
academicplan2.study=mast;
academicplan2.save();
yearplan2=AcademicYearPlan();
yearplan2.id=2;
yearplan2.academic_plan=academicplan2;
yearplan2.time_block=1;
yearplan2.save();
academicplan3=AcademicPlan()
academicplan3.student=student2;
academicplan3.study=bach2;
academicplan3.save();
yearplan3=AcademicYearPlan();
yearplan3.id=3;
yearplan3.academic_plan=academicplan3;
yearplan3.time_block=1;
yearplan3.save();
" | python3 manage.py shell

# make courseplans
echo "from studieplan.views import AcademicYearPlan;
from vakbeheer.views import CourseInstance;
from studieplan.views import CoursePlan;
yearplan1=AcademicYearPlan.objects.get(id=1);
courseplan=CoursePlan();
courseplan.academic_yearplan=yearplan1;
courseplan.course=CourseInstance.objects.get(id=1);
courseplan.save();
courseplan=CoursePlan();
courseplan.academic_yearplan=yearplan1;
courseplan.course=CourseInstance.objects.get(id=2);
courseplan.save();
courseplan=CoursePlan();
courseplan.academic_yearplan=yearplan1;
courseplan.course=CourseInstance.objects.get(id=3);
courseplan.save();
yearplan2=AcademicYearPlan.objects.get(id=2);
courseplan=CoursePlan();
courseplan.academic_yearplan=yearplan2;
courseplan.course=CourseInstance.objects.get(id=4);
courseplan.save();
courseplan=CoursePlan();
courseplan.academic_yearplan=yearplan2;
courseplan.course=CourseInstance.objects.get(id=5);
courseplan.save();
courseplan=CoursePlan();
courseplan.academic_yearplan=yearplan2;
courseplan.course=CourseInstance.objects.get(id=6);
courseplan.save();
" | python3 manage.py shell

echo "Making grades..."

# make grade templates
for i in {1..6}; do
    echo "from cijferbeheer.views import GradeTemplate;
from vakbeheer.views import CourseInstance;
course=CourseInstance.objects.get(id=$i);
g_temp=GradeTemplate();
g_temp.course_id=course;
g_temp.grade_name='Assignments';
g_temp.redo_action=1;
g_temp.save();
g_temp=GradeTemplate();
g_temp.course_id=course;
g_temp.grade_name='Midterm Exam';
g_temp.redo_action=0;
g_temp.save();
g_temp=GradeTemplate();
g_temp.course_id=course;
g_temp.grade_name='Final Exam';
g_temp.redo_action=2;
g_temp.save();
" | python3 manage.py shell
done

echo "Making announcements..."

for i in {1..6}; do
    echo "from vakbeheer.models import Announcement;
from vakbeheer.models import CourseInstance;
from persoonsgegevens.models import PersonalData;
course=CourseInstance.objects.get(id=$i);
teacher=PersonalData.objects.get(uvanetid='Teacher1');
ann=Announcement();
ann.course=course;
ann.author=teacher;
ann.text='hallo dit is een Announcement';
ann.save();
" | python3 manage.py shell
done

for i in {1..4}; do
    echo "from vakbeheer.models import Announcement;
from vakbeheer.models import CourseInstance;
from persoonsgegevens.models import PersonalData;
course=CourseInstance.objects.get(id=1);
teacher=PersonalData.objects.get(uvanetid='Teacher2');
ann=Announcement();
ann.course=course;
ann.author=teacher;
ann.text='heel veel Announcements nummer: $i';
ann.save();
" | python3 manage.py shell
done


echo "Done."
echo "doei"
echo "hoi"
