package com.ncc.audiosync;

import android.net.wifi.p2p.WifiP2pDevice;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.view.View;
import android.widget.Button;

import nl.erlkdev.adhocmonitor.NodeStatus;

import java.net.InetAddress;
import java.util.Arrays;
import java.util.List;


public class MainActivity extends AppCompatActivity implements PeersListFragment.ListInterface {
    static final int PORT = 8888;

    /* App variables */
    private Monitor monitor;
    private AudioPlayer audioplayer;
    private NetworkFunctions networkFunctions;
    private SntpClient sntpThread;

    /* UI variables */
    private Button clickButton;
    private Button disconnectButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /* NTP Server list. */
        List<String> NTPServers = Arrays.asList("time.google.com",
                "pool.ntp.org",
                "0.europe.pool.ntp.org",
                "1.europe.pool.ntp.org",
                "2.europe.pool.ntp.org",
                "3.europe.pool.ntp.org");

        /* Start the SNTP request thread. */
        sntpThread = new SntpClient(MainActivity.this, NTPServers);
        sntpThread.start();

        /* Start the monitor. */
        monitor = new Monitor(this.getApplicationContext());

        /* Start the audio player. */
        audioplayer = new AudioPlayer(MainActivity.this);

        /* Display the ip address on screen. */
        final TextView t = this.findViewById(R.id.hello_world);
        t.setText(Monitor.getIPAddress(true));

        /* Set the monitor status to waiting. */
        monitor.changeStatus(NodeStatus.WAITING);

        /* Start the network functions. */
        networkFunctions = new NetworkFunctions(MainActivity.this);

        clickButton = findViewById(R.id.discover_button);
        clickButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                networkFunctions.startDiscovering();
            }
        });

        disconnectButton = findViewById(R.id.disconnect_button);
        disconnectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                networkFunctions.disconnectFromGroup();
            }
        });
    }


    /* register the broadcast receiver with the intent values to be matched */
    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(networkFunctions.mReceiver, networkFunctions.mIntentFilter);
    }
    /* unregister the broadcast receiver */
    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(networkFunctions.mReceiver);
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
    }

    public AudioPlayer getAudioPlayer() {
        return this.audioplayer;
    }

    public Monitor getMonitor() {
        return monitor;
    }

    public NetworkFunctions getNetworkFunctions() {
        return this.networkFunctions;
    }


    /* FUNCTION WE IMPLEMENT. */

    public void sendMessage(String msg, InetAddress host) {
        networkFunctions.sendMessage(msg, host);
    }

    public void connectToDevice(WifiP2pDevice device) {
        networkFunctions.connectToDevice(device);
    }
}
