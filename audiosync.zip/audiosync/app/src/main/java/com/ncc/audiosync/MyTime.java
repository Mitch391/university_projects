package com.ncc.audiosync;

import android.os.SystemClock;
import android.util.Log;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;


public class MyTime {

    private static long clockOffset = 0;
    private static List<Double> offsetList = new ArrayList<>();
    private static long startTime = System.currentTimeMillis();
    private static long startTimeElapsed = SystemClock.elapsedRealtime();


    public static long getTime() {
        long tmp = startTime + clockOffset + SystemClock.elapsedRealtime() - startTimeElapsed;

        return startTime + clockOffset + SystemClock.elapsedRealtime() - startTimeElapsed;
    }


    public static void addOffsetTiming(double offset) {
        Log.d("MyTime", "Added new offset" + String.valueOf(offset));
        offsetList.add(offset);

        /* Calculate the clock offset. This can be the mean or the median. Choose one. */
//        averageClockOffset();
        clockMedian();
    }

    private static void averageClockOffset() {
        double sum = 0;

        for(double offset : offsetList) {
            sum += offset;
        }

        clockOffset = Math.round(sum / (double) offsetList.size());

        Log.d("MyTime", "New average: " + String.valueOf(clockOffset));
    }


    private static void clockMedian() {
        Collections.sort(offsetList);
        int size = offsetList.size();
        int idx;
        double offset;

        /* Check if the list size is even or uneven. */
        if(size % 2 == 0) {
            idx = size / 2;
            offset = (offsetList.get(idx) + offsetList.get(idx - 1)) / 2.0;
        }
        else {
            idx = (size - 1) / 2;
            offset = offsetList.get(idx);
        }

        clockOffset = Math.round(offset);

        Log.d("MyTime", "Median: " + String.valueOf(clockOffset));
    }


    /* Convert from milliseconds to minutes and seconds */
    public static String timeConvert(int milliseconds) {
        long min = TimeUnit.MILLISECONDS.toMinutes(milliseconds);
        long sec = TimeUnit.MILLISECONDS.toSeconds(milliseconds % 60000);
        String sMin = timeFix(min);
        String sSec = timeFix(sec);

        return sMin + ":" + sSec;
    }

    private static String timeFix(long time) {
        if (time < 10) {
            return "0" + String.valueOf(time);
        }
        return String.valueOf(time);
    }
}
