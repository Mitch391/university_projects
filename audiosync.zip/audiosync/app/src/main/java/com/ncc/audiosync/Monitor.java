package com.ncc.audiosync;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.util.Log;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import nl.erlkdev.adhocmonitor.*;

import static android.content.Context.BIND_AUTO_CREATE;


public class Monitor {

    /* Variables for connecting to the monitor. */
    private Intent mAdhocMonitorIntent;
    private Context context;                        /* Context of the main activity. */
    private String mAddress;                        /* IP address of device. */
    private String hostAddress = "145.109.1.163";  /* IP address of the monitor GUI. */
    private AdhocMonitorService mMonitor;

    private List<String> neighbours = new ArrayList<String>();


    /**
     * Start the monitor and connect it to the monitor GUI.
     */
    public Monitor(Context c) {
        this.context = c;
        this.mAddress = getIPAddress(true);

        /* Create monitor intent service. */
        mAdhocMonitorIntent = new Intent(this.context, AdhocMonitorService.class);

        /* Bind monitor service. */
        context.bindService(mAdhocMonitorIntent, new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName className, IBinder service) {
                Log.d("MonitorService", "Adhoc Monitor service is connected");
                AdhocMonitorBinder adhocMonitorBinder = (AdhocMonitorBinder) service;
                mMonitor = adhocMonitorBinder.getService();

                /* Starts the monitor. */
                mMonitor.startMonitor(mAddress, hostAddress, new AdhocMonitorService.MonitorErrorListener() {
                    @Override
                    public void onError(String errorMsg) {
                        Log.d("MonitorService", errorMsg);
                    }
                });

                /* Set the status of the node. */
                mMonitor.getMonitorNode().setNodeStatus(NodeStatus.WAITING);
            }

            @Override
            public void onServiceDisconnected(ComponentName arg0) {
                Log.d("MonitorService", "Adhoc Monitor service is disconnected");
            }
        }, BIND_AUTO_CREATE);

        /* Start the monitor service. */
        context.startService(mAdhocMonitorIntent);
    }

    /* Increase the number of processor ticks. */
    public void increaseTicks(int nTicks) {
//        if(mMonitor != null)
//            for(int i = 0; i < nTicks; i++)
//                mMonitor.getMonitorNode().incrProcessTicks();
    }


    public void changeStatus(NodeStatus s) {
//        if(mMonitor != null)
//            mMonitor.getMonitorNode().setNodeStatus(s);
    }


    public void addNeighbour(String neighbour) {
        if(!this.neighbours.contains(neighbour)) {
            this.neighbours.add(neighbour);
            this.setNeighbours(this.neighbours.toArray(new String[this.neighbours.size()]));
            Log.d("TEST", this.neighbours.toArray().toString());
        }
    }


    public void removeNeighbour(String neighbour) {
        this.neighbours.remove(neighbour);
        this.setNeighbours(this.neighbours.toArray(new String[this.neighbours.size()]));
    }


    public void setNeighbours(String[] currentNeighbours) {
//        if(mMonitor != null)
//            this.mMonitor.getMonitorNode().setCurrentNeighbours(currentNeighbours);
    }

    /* Set the number of bytes received and send. */
    public void sendData(String to, int byteAmount) {
//        if(mMonitor != null)
//            mMonitor.getMonitorNode().addSendIO(to, byteAmount);
    }

    /* Set the number of bytes received and send. */
    public void receiveData(String from, int byteAmount) {
//        if(mMonitor != null)
//            mMonitor.getMonitorNode().addRecieveIO(from, byteAmount);
    }


    /**
     * This function gets the ip address of the device.
     * Source: https://stackoverflow.com/questions/6064510/how-to-get-ip-address-of-the-device-from-code
     */
    public static String getIPAddress(boolean useIPv4) {
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface intf : interfaces) {
                List<InetAddress> addrs = Collections.list(intf.getInetAddresses());
                for (InetAddress addr : addrs) {
                    if (!addr.isLoopbackAddress()) {
                        String sAddr = addr.getHostAddress();
                        //boolean isIPv4 = InetAddressUtils.isIPv4Address(sAddr);
                        boolean isIPv4 = sAddr.indexOf(':')<0;

                        if (useIPv4) {
                            if (isIPv4)
                                return sAddr;
                        } else {
                            if (!isIPv4) {
                                int delim = sAddr.indexOf('%'); // drop ip6 zone suffix
                                return delim<0 ? sAddr.toUpperCase() : sAddr.substring(0, delim).toUpperCase();
                            }
                        }
                    }
                }
            }
        } catch (Exception ex) { } // for now eat exceptions
        return "";
    }
}
