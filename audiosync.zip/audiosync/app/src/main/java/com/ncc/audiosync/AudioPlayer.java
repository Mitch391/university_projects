package com.ncc.audiosync;

import android.app.Activity;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import nl.erlkdev.adhocmonitor.NodeStatus;

public class AudioPlayer extends Activity {

    private Handler mediaHandler;
    private List<String> songNames;
    private TextView maxTime;
    private TextView currTime;
    private SeekBar seekBar;
    private Spinner songSelect;

    private int currSong;

    public List<SongInfo> songs;
    public MediaPlayer mediaPlayer;

    private MainActivity mainActivity;


    public AudioPlayer(MainActivity m) {
        mainActivity = m;
        currSong = 0;

        /* Get the onscreen controls */
        final Button playpause = m.findViewById(R.id.button);
        seekBar = m.findViewById(R.id.musicSeekBar);
        maxTime = m.findViewById(R.id.maxTime);
        currTime = m.findViewById(R.id.currTime);
        songSelect = m.findViewById(R.id.songSelect);

        /* Init mediaPlayer and seekBar */
        listRaw();
        musicInit(songs.get(currSong));

        /* Init Spinner with song names */
        ArrayAdapter<String> adapter = new ArrayAdapter<>(mainActivity,
                android.R.layout.simple_spinner_dropdown_item, songNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        songSelect.setAdapter(adapter);

        /* Update UI */
        mainActivity.runOnUiThread(new Runnable() {

            @Override
            public void run() {
                if(mediaPlayer != null){
                    int currPos = mediaPlayer.getCurrentPosition();
                    seekBar.setProgress(currPos);
                    currTime.setText(MyTime.timeConvert(currPos));
                }
                mediaHandler.postDelayed(this, 1);
            }
        });

        /* Scrub seekBar */
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                mainActivity.getNetworkFunctions().newBroadcast(currSong,
                        MyTime.getTime(),
                        seekBar.getProgress(), NetworkFunctions.MSG_SEEK);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(mediaPlayer != null && fromUser){
                    mediaPlayer.seekTo(progress);
                }
            }
        });

        /* Listen for click on the Spinner */
        songSelect.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(mainActivity.getBaseContext(), songNames.get(i), Toast.LENGTH_SHORT).show();
                mediaPlayer.release();
                mediaPlayer = null;
                currSong = i;
                musicInit(songs.get(i));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        /* Listen for button click */
        playpause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                player();
                mainActivity.getMonitor().changeStatus(NodeStatus.PROCESSING);
            }
        });
    }

    /* Play or pause the music when the button is pressed. It also broadcast the new action to the
     * network. */
    public void player() {
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
            long offset = mediaPlayer.getCurrentPosition();
            Log.d("MUSIC", String.valueOf(offset));
            Log.d("MUSIC millis", String.valueOf(MyTime.getTime()));
            this.mainActivity.getNetworkFunctions().newBroadcast(currSong,
                                                                 MyTime.getTime(),
                                                                 offset,
                                                                 NetworkFunctions.MSG_PAUSE);
        } else {
            mediaPlayer.start();
            long offset = mediaPlayer.getCurrentPosition();
            Log.d("MUSIC", String.valueOf(offset));
            Log.d("MUSIC millis", String.valueOf(MyTime.getTime()));
            Log.d("MyTime", String.valueOf(MyTime.getTime()));
            this.mainActivity.getNetworkFunctions().newBroadcast(currSong,
                                                                 MyTime.getTime(),
                                                                 offset,
                                                                 NetworkFunctions.MSG_START);
        }
    }

    /* Plays a song we received from a network message. */
    public void playNetworkSong(int songId, long startTime, long timeOffset) {

        if (currSong != songId) {
            currSong = songId;
            mediaPlayer.release();
            mediaPlayer = null;
        }

        this.musicInit(mainActivity.getAudioPlayer().songs.get(songId));
        this.mediaPlayer.start();

        /* Calculate the start time of our music. */
        long networkDelay = MyTime.getTime() - startTime;
        long musicTime = networkDelay+ timeOffset;

        /* Log messages. */
        Log.d("MUSIC delay", String.valueOf(networkDelay));
        Log.d("MUSIC millis", String.valueOf(MyTime.getTime()));
        Log.d("MUSIC time", String.valueOf(musicTime));

        this.mediaPlayer.seekTo((int)musicTime);
    }

    /* Pauses a song we received from a network message. */
    public void pauseNetworkSong() {
        this.mediaPlayer.pause();

        /* Log messages. */
        Log.d("MUSIC", String.valueOf(mediaPlayer.getCurrentPosition()));
        Log.d("MUSIC millis", String.valueOf(MyTime.getTime()));
    }

    public void seekNetworkSong(int songId, long startTime, long timeOffset){

        if (currSong != songId) {
            currSong = songId;
            mediaPlayer.release();
            mediaPlayer = null;

            this.musicInit(mainActivity.getAudioPlayer().songs.get(songId));
            this.mediaPlayer.start();

        }

        /* Calculate the start time of our music. */
        long networkDelay = MyTime.getTime() - startTime;
        long musicTime = networkDelay+ timeOffset;

        /* Log messages. */
        Log.d("MUSIC delay", String.valueOf(networkDelay));
        Log.d("MUSIC millis", String.valueOf(MyTime.getTime()));
        Log.d("MUSIC time", String.valueOf(musicTime));

        this.mediaPlayer.seekTo((int)musicTime);
    }


    /* Init musicPlayer with song given in args */
    public void musicInit(SongInfo song) {
        mediaPlayer = MediaPlayer.create(mainActivity, Uri.parse("android.resource://" +
                mainActivity.getPackageName() + "/raw/" + song.uriName));

        seekBar.setMax(mediaPlayer.getDuration());
        String maxTimeStr = MyTime.timeConvert(mediaPlayer.getDuration());
        maxTime.setText(maxTimeStr);
    }

    /* Get all songs from raw folder and put them in songs, their names in songNames */
    public void listRaw(){
        mediaHandler = new Handler();
        songNames = new ArrayList<String>();
        songs = new ArrayList<>();
        Field[] fields=R.raw.class.getFields();
        for(int count=0; count < fields.length; count++){
            MediaMetadataRetriever mmr = new MediaMetadataRetriever();
            Uri musicUri = Uri.parse("android.resource://" + mainActivity.getPackageName() + "/raw/" +
                    fields[count].getName());
            mmr.setDataSource(mainActivity, musicUri);
            songs.add(new SongInfo(count, fields[count].getName(), mmr));
            songNames.add(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE));
            Log.i("Raw Asset: ", fields[count].getName());
        }
    }
}
