package com.ncc.audiosync;

import android.app.ListFragment;
import android.content.Context;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pDeviceList;
import android.net.wifi.p2p.WifiP2pInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;


public class PeersListFragment extends ListFragment implements WifiP2pManager.PeerListListener, WifiP2pManager.ConnectionInfoListener{

    private List<WifiP2pDevice> peers = new ArrayList<>();
    WiFiArrayAdapter adapter;

    /* Interface for communication with mainactivity. */
    public interface ListInterface {
        void connectToDevice(WifiP2pDevice device);

        void sendMessage(String msg, InetAddress host);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.list_fragment, container, false);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        //this.setListAdapter(new WiFiPeerListAdapter(getActivity(), R.layout.activity_mainx, peers));
        //adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, getDeviceArray(peers));
        adapter = new WiFiArrayAdapter(getActivity(), R.layout.list_item, peers);

        this.setListAdapter(adapter);
        Log.d("TEST", "Adapter has been set.");
    }

    @Override
    public void onListItemClick(ListView lv, View view, int position, long id) {
        WifiP2pDevice device = peers.get(position);
        Log.d("TEST", "Clicked on device " + device.deviceName);
        ((ListInterface) getActivity()).connectToDevice(device);
    }

    @Override
    public void onPeersAvailable(WifiP2pDeviceList peerList) {
        peers.clear();
        peers.addAll(peerList.getDeviceList());
        // Needed when using standar ArrayAdapter, but the custom adapter broke while using this.
        //adapter.clear();
        //adapter.addAll(peers);
        adapter.notifyDataSetChanged();

        if (peers.size() == 0) {
            Log.d("ERROR", "No devices found");
        }
        else {
            Log.d("TEST", "Found something");
        }
    }

    @Override
    public void onConnectionInfoAvailable(WifiP2pInfo networkInfo) {
        if (!networkInfo.isGroupOwner) {
            Log.d("TEST", "I'm connected as client!");
            ((ListInterface) getActivity()).sendMessage("Test message", networkInfo.groupOwnerAddress);
        }
    }

    public String getDeviceStatus(int status) {
        String statusString;
        switch(status) {
            case 0: statusString = "Connected";
                    break;
            case 1: statusString = "Invited";
                    break;
            case 2: statusString = "Failed";
                    break;
            case 3: statusString = "Available, tap to connect";
                    break;
            case 4: statusString = "Unavailable";
                    break;
            default: statusString = "Unknown status";
                    break;
        }
        return statusString;
    }

    private class WiFiArrayAdapter extends ArrayAdapter<WifiP2pDevice> {
        private List<WifiP2pDevice> items;

        public WiFiArrayAdapter(Context c, int resourseId, List<WifiP2pDevice> peers) {
            super(c, resourseId, peers);
            Log.d("TEST", "Making WiFiArrayAdapter");
            items = peers;
        }

        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public @NonNull View getView(int pos, View convertView, @NonNull ViewGroup parent) {
            View newView = convertView;

            if (newView == null) {
                LayoutInflater vi = (LayoutInflater) getActivity().getSystemService(
                        Context.LAYOUT_INFLATER_SERVICE);
                newView = vi.inflate(R.layout.list_item, null);
            }
            WifiP2pDevice peer = items.get(pos);

            TextView dName = (TextView) newView.findViewById(R.id.deviceName);
            TextView dStatus = (TextView) newView.findViewById(R.id.deviceStatus);

            dName.setText(peer.deviceName);
            dStatus.setText(getDeviceStatus(peer.status));
            return newView;
        }

    }
}
