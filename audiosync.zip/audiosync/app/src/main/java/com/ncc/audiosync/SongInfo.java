package com.ncc.audiosync;

import android.media.MediaMetadataRetriever;

/**
 * Created by mitch on 10/01/18.
 */

public class SongInfo {
    int index;
    String uriName;
    MediaMetadataRetriever mmr;

    SongInfo(int index, String uriName, MediaMetadataRetriever mmr) {
        this.index = index;
        this.uriName = uriName;
        this.mmr = mmr;
    }
}
