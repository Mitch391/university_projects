package com.ncc.audiosync;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.NetworkInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.util.Log;


/**
 * Created by jordy on 9-1-18.
 */

public class WiFiDirectBroadcastReceiver extends BroadcastReceiver {

    private WifiP2pManager mManager;
    private WifiP2pManager.Channel mChannel;
    private MainActivity mActivity;
    private WiFiDirectListener wifiDirectListener;

    public WiFiDirectBroadcastReceiver(WifiP2pManager manager, WifiP2pManager.Channel channel,
                                       MainActivity activity) {
        super();
        this.mManager = manager;
        this.mChannel = channel;
        this.mActivity = activity;
        wifiDirectListener = new WiFiDirectListener(mActivity);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION.equals(action)) {
            int state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1);
            if (state == WifiP2pManager.WIFI_P2P_STATE_ENABLED) {
                Log.d("WIFISTATE", "WIFI P2P IS ENABLED");
            } else {
                Log.d("WIFISTATE", "WIFI P2P IS NOT ENABLED");
            }

        } else if (WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION.equals(action)) {
            /* request available peers from the wifi p2p manager. This is an
             * asynchronous call and the calling activity is notified with a
             * callback on PeerListListener.onPeersAvailable()
             */

            if (mManager == null) return;

            int extra_disc = intent.getIntExtra("EXTRA_DISCOVERY_STATE",
                    WifiP2pManager.WIFI_P2P_DISCOVERY_STARTED);

            /* Check if the discovery as started or stopped */
            if(extra_disc == WifiP2pManager.WIFI_P2P_DISCOVERY_STARTED){
                // Something worth looking at: EXTRA_P2P_DEVICE_LIST
                mManager.requestPeers(mChannel, (WifiP2pManager.PeerListListener) mActivity.getFragmentManager().findFragmentById(R.id.fragment));
            } else {
                Log.d("TEST", "KOMT HIJ OOIT HIER?");
                // Something worth looking at: EXTRA_P2P_DEVICE_LIST
                mManager.requestPeers(mChannel, (WifiP2pManager.PeerListListener) mActivity.getFragmentManager().findFragmentById(R.id.fragment));
            }

        } else if (WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION.equals(action)) {
            // Respond to new connection or disconnections
            if (mManager == null) return;

            NetworkInfo networkInfo = (NetworkInfo) intent
                    .getParcelableExtra(WifiP2pManager.EXTRA_NETWORK_INFO);

            Log.d("TEST", "Connection info: " + networkInfo.isConnected());
            if(networkInfo.isConnected()) {
                mManager.requestConnectionInfo(mChannel, wifiDirectListener);
            }

        } else if (WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION.equals(action)) {
            // Respond to this device's wifi state changing
        }
    }
}
