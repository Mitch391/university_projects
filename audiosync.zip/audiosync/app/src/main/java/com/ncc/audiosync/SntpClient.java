/**
 * We took a copy of this file from the following source and modified it to make
 * it work in our application.
 * Source: http://support.ntp.org/bin/view/Support/JavaSntpClient
 */

/**
 * NtpClient - an NTP client for Java.  This program connects to an NTP server
 * and prints the response to the console.
 *
 * The local clock offset calculation is implemented according to the SNTP
 * algorithm specified in RFC 2030.
 *
 * Note that on windows platforms, the curent time-of-day timestamp is limited
 * to an resolution of 10ms and adversely affects the accuracy of the results.
 *
 *
 * This code is copyright (c) Adam Buckley 2004
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.  A HTML version of the GNU General Public License can be
 * seen at http://www.gnu.org/licenses/gpl.html
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * @author Adam Buckley
 */


package com.ncc.audiosync;

import android.util.Log;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.text.DecimalFormat;
import java.util.List;


//public class SntpClient extends AsyncTask<Void, Void, Double>
public class SntpClient extends Thread implements Runnable
{
    private List<String> servers;
    private MainActivity mainActivity;

    public SntpClient(MainActivity mainActivity, List<String> serverNames) {
        super();
        this.mainActivity = mainActivity;
        this.servers = serverNames;
    }


    @Override
    public void run() {
        for (int i = 0; i<3; i++) {
            for(String server : servers) {
                try {
                    double time = sendRequest(server);
                    pushTime(time);
                }
                catch(Exception e) {
                    Log.d("SNTP Error", e.getMessage());
                }
            }
        }
    }

    private void pushTime(final double time) {
        mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                MyTime.addOffsetTiming(time);
            }
        });
    }


    private double sendRequest(String serverName) throws Exception {
        // Send request
        DatagramSocket socket = new DatagramSocket();
        InetAddress address = InetAddress.getByName(serverName);
        byte[] buf = new NtpMessage().toByteArray();
        DatagramPacket packet =
                new DatagramPacket(buf, buf.length, address, 123);

        // Set the transmit timestamp *just* before sending the packet
        // ToDo: Does this actually improve performance or not?
        NtpMessage.encodeTimestamp(packet.getData(), 40,
                (System.currentTimeMillis() / 1000.0) + 2208988800.0);

        socket.send(packet);


        // Get response
        Log.d("SNTP", "NTP request sent, waiting for response...\n");
        //        System.out.println("NTP request sent, waiting for response...\n");
        packet = new DatagramPacket(buf, buf.length);
        socket.receive(packet);

        // Immediately record the incoming timestamp
        double destinationTimestamp =
                (System.currentTimeMillis() / 1000.0) + 2208988800.0;


        // Process response
        NtpMessage msg = new NtpMessage(packet.getData());

        // Corrected, according to RFC2030 errata
        double roundTripDelay = (destinationTimestamp - msg.originateTimestamp) -
                (msg.transmitTimestamp - msg.receiveTimestamp);

        double localClockOffset =
                ((msg.receiveTimestamp - msg.originateTimestamp) +
                        (msg.transmitTimestamp - destinationTimestamp)) / 2;


        Log.d("SNTP", "NTP server: " + serverName);
        Log.d("SNTP", msg.toString());
        Log.d("SNTP", "Dest. timestamp:     " +
                NtpMessage.timestampToString(destinationTimestamp));
        Log.d("SNTP", "Round-trip delay: " +
                new DecimalFormat("0.00").format(roundTripDelay * 1000) + " ms");
        Log.d("SNTP", "Local clock offset: " +
                new DecimalFormat("0.00").format(localClockOffset * 1000) + " ms");

        socket.close();

        return localClockOffset * 1000;
    }
}