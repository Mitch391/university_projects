package com.ncc.audiosync;

import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;


public class NetworkProtocol {
    public int wave;        /* Unique id that identifies the wave. */
    public String init;     /* IP-address that identifies the initiator of the wave */
    public int type;        /* Message type */
    public long offset;     /* Time offset in the song. Value is in ms where 0 is the start of the song */
    public long time;       /* Time the song started playing on the initiator's device. */
    public int songId;      /* Identifier for the song that is playing. */
    public String receivedFrom; /* Sender of this message. This can be different than the initiator. */

    public JSONObject json = null;

    // Deze alleen nodig voor ping/pong want geen tijd
    public NetworkProtocol(int wave, int type, int songId, String init) {
        this.wave = wave;
        this.type = type;
        this.songId = songId;
        this.init = init;
    }

    public NetworkProtocol(String json) {
        try {
            JSONObject recv = new JSONObject(json);
            fromJSON(recv);
            Log.d("JSON SUCCESS", "JSON SUCCESFULLY DECODED.");
        } catch (JSONException ex) {
            Log.d("JSON ERROR: ", ex.toString());
        }
    }

    public NetworkProtocol(int wave, int type, int songId, String init, long time, long offset) {
        this.wave = wave;
        this.type = type;
        this.songId = songId;
        this.init = init;
        this.time = time;
        this.offset = offset;
    }

    public JSONObject toJSON() {
        /* Create a new json object. */
        this.json = new JSONObject();

        /* Fill the json object with data from our class variables. */
        try {
            this.json.putOpt("wave", wave);
            this.json.putOpt("init", init);
            this.json.putOpt("sender", Monitor.getIPAddress(true));
            this.json.putOpt("type", type);
            this.json.putOpt("songId", songId);
            this.json.putOpt("offset", offset);
            this.json.putOpt("time", time);

            Log.d("JSON", this.json.toString(4));
        } catch (JSONException e) {
            Log.d("JSON", e.getMessage());
        }

        return this.json;
    }


    public void fromJSON(JSONObject input){
        this.wave = input.optInt("wave");
        this.init = input.optString("init");
        this.type = input.optInt("type");
        this.songId = input.optInt("songId");
        this.offset = input.optLong("offset");
        this.time = input.optLong("time");
        this.receivedFrom = input.optString("sender");
    }
}
