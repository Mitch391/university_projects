package com.ncc.audiosync;

import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pDeviceList;
import android.net.wifi.p2p.WifiP2pGroup;
import android.net.wifi.p2p.WifiP2pInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by jelle on 13-1-18.
 */

public class WiFiDirectListener implements WifiP2pManager.ConnectionInfoListener, WifiP2pManager.GroupInfoListener {

    MainActivity mActivity;

    public WiFiDirectListener(MainActivity activity){
        mActivity = activity;
    }

    @Override
    public void onConnectionInfoAvailable(WifiP2pInfo networkInfo) {
        if (!networkInfo.isGroupOwner) {
            Log.d("TEST", "I'm connected as client!");
            //NetworkProtocol msg = new NetworkProtocol(0, 0, 0, "kip", startTime, offset);
            mActivity.getNetworkFunctions().sendMessage("First connection", networkInfo.groupOwnerAddress);
        }
        else {}
    }

    @Override
    public void onGroupInfoAvailable(WifiP2pGroup groupInfo) {
    }
}
