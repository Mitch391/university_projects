/**
 * File: NetworkFunction.java
 *
 * Information:
 *      This file contains all the functions that decide what to do with a message. For example,
 *      we receive a message and see that we must start the music. We start the selected song and
 *      broadcast the message to our neighbours. This file also contains function to send message
 *      which are created by the class NetworkProtocol.
 */

package com.ncc.audiosync;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.net.wifi.p2p.WifiP2pConfig;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pManager;
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceInfo;
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceRequest;
import android.net.wifi.p2p.nsd.WifiP2pServiceRequest;
import android.util.Log;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import nl.erlkdev.adhocmonitor.NodeStatus;

import static android.os.Looper.getMainLooper;


public class NetworkFunctions {
    public static final int MSG_INIT = 0;
    public static final int MSG_START = 1;
    public static final int MSG_PAUSE = 2;
    public static final int MSG_SEEK  = 3;

//    List<NetworkProtocol> messageHistory = new ArrayList<>();
    Map<String, Integer> messageHistory = new HashMap<>();

    /* Message variables. */
    List<InetAddress> peerList = new ArrayList<>();

    /* Network variables. */
    List<WifiP2pDevice> peersDiscovered = new ArrayList<>();
    WifiP2pManager mManager;
    WifiP2pManager.Channel mChannel;
    BroadcastReceiver mReceiver;
    IntentFilter mIntentFilter;
    ServerThread serverThread;
    InetAddress currentClient;

    /* Other variables. */
    private MainActivity mainActivity;
    private String IPAddress;
    private long timeLastClicked = 0;

    private List whiteList = Arrays.asList("c2:ee:fb:59:9e:c1",
            "c2:ee:fb:35:67:cb",
            "aa:81:95:5c:3f:a2",
            "ea:50:8b:8d:d9:e5",
            "8e:f5:a3:f3:0f:a8",
            "b2:e5:ed:f5:de:db",
            "d0:59:e4:ae:ab:4c",
            "c6:43:8f:f2:f0:26",
            "06:d6:aa:12:6b:82");
    //  Create a string map containing information about your service.
    Map record = new HashMap();


    public NetworkFunctions(MainActivity mainActivity) {
        this.mainActivity = mainActivity;
        IPAddress = Monitor.getIPAddress(true);

        /* Wi-Fi P2P setup. */
        mManager = (WifiP2pManager) mainActivity.getSystemService(Context.WIFI_P2P_SERVICE);
        mChannel = mManager.initialize(mainActivity, getMainLooper(), null);
        mReceiver = new WiFiDirectBroadcastReceiver(mManager, mChannel, mainActivity);

        // Intent Filter setup.
        mIntentFilter = new IntentFilter();
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION);
        serverThread = new ServerThread(mainActivity);
        serverThread.start();
        record.put("buddyname", "Device" + (int) (Math.random() * 1000));
        record.put("available", "visible");

//        startRegistration();
//        discoverService();
//        record.remove("available");
//        record.put("available", "not visible");

    }

    /* Handle a message we received from the network. */
    public void receive(String msg, InetAddress client) {
        Log.d("TEST", msg);

        NetworkProtocol recvMessage = new NetworkProtocol(msg);

        if(!peerList.contains(client)){
            peerList.add(client);
            sendMessage("You have been added", client);
        }

        Integer r = messageHistory.get(recvMessage.init);
        if (r == null) {
            messageHistory.put(recvMessage.init, recvMessage.wave);
        } else if (r != recvMessage.wave) {
            messageHistory.remove(recvMessage.init);
            messageHistory.put(recvMessage.init, recvMessage.wave);
        } else
            return;

        currentClient = client;

        /* Update monitor data. */
        mainActivity.getMonitor().sendData(recvMessage.receivedFrom,
                                           msg.getBytes().length);
        mainActivity.getMonitor().receiveData(Monitor.getIPAddress(true),
                                              msg.getBytes().length);

        mainActivity.getMonitor().changeStatus(NodeStatus.PROCESSING);
        mainActivity.getMonitor().addNeighbour(recvMessage.receivedFrom);

        /* Decide what to do with the message. */
        switch (recvMessage.type) {
            case MSG_START: startMusic(recvMessage); break;
            case MSG_PAUSE: pauseMusic(recvMessage); break;
            case MSG_SEEK:  seekMusic(recvMessage);  break;
        }
    }

    public void sendMessage(String msg, InetAddress host) {
        Log.d("TEST", "Sending message");
        new ClientAsyncTask(msg, host).execute();
    }

    /* Starts music in the MainActivity */
    public void startMusic(NetworkProtocol recvMessage) {
        mainActivity.getAudioPlayer().playNetworkSong(recvMessage.songId, recvMessage.time, recvMessage.offset);

        /* Broadcast the received message to our neighbours. */
        broadcast(recvMessage.toJSON().toString());
    }

    /* Pauses music in the MainActivity */
    private void pauseMusic(NetworkProtocol recvMessage) {
        mainActivity.getAudioPlayer().pauseNetworkSong();

        /* Broadcast the received message to our neighbours. */
        broadcast(recvMessage.toJSON().toString());
    }

    private void seekMusic(NetworkProtocol recvMessage) {
        mainActivity.getAudioPlayer().seekNetworkSong(recvMessage.songId, recvMessage.time, recvMessage.offset);

        /* Broadcast the received message to our neighbours. */
        broadcast(recvMessage.toJSON().toString());
    }


    public void newBroadcast(int songId, long startTime, long offset, int msg_type) {
        int wave = 0;
        if (messageHistory.get(IPAddress) != null) {
            wave = messageHistory.get(IPAddress);
            wave++;
            messageHistory.remove(IPAddress);
            messageHistory.put(IPAddress, wave);
        }
        else
            messageHistory.put(IPAddress, wave);

        NetworkProtocol msg = new NetworkProtocol(wave, msg_type, songId, IPAddress, startTime, offset);
        broadcast(msg.toJSON().toString());

    }


    /* Propagates message to neighbors */
    public void broadcast(String broadcast_msg) {
        // send recv to all neighbors
        if (System.currentTimeMillis() - timeLastClicked > 1000) {
            for(InetAddress peer : peerList) {
            /* Don't send messages back where you got them from. */
                if (peer != currentClient) {
                    sendMessage(broadcast_msg, peer);
                }
                else {
                    Log.d("TEST", "Message caught! Stopped a loop.");
                }
            }
        }
        else{
            Log.d("TEST", "Stop spamming plz.");
        }

        currentClient = null;

    }

    public void startDiscovering() {
        mManager.discoverPeers(mChannel, new WifiP2pManager.ActionListener() {
            @Override
            public void onSuccess() {
                Log.d("SUCCES", "Starting discovery...");

            }

            @Override
            public void onFailure(int reasonCode) {
                Log.d("ERROR", "Something went wrong: errorcode " + reasonCode);
            }
        });
    }


    public void connectToDevice(WifiP2pDevice device) {
        WifiP2pConfig config = new WifiP2pConfig();
        config.deviceAddress = device.deviceAddress;
        if (!whiteList.contains(device.deviceAddress)) {
            Log.d("FAILURE", "Device not whitelisted: " + device.deviceAddress);
            return;
        }

        mManager.connect(mChannel, config, new WifiP2pManager.ActionListener() {
            @Override
            public void onSuccess() {}

            @Override
            public void onFailure(int reason) {
                Log.d("FAILURE", "Couldn't connect to device\tReason: " + reason);
            }
        });
    }

    public void disconnectFromGroup() {
        if (mManager != null) {
            mManager.removeGroup(mChannel, new WifiP2pManager.ActionListener() {
                @Override
                public void onSuccess() {
                    Log.d("SUCCESS", "Successfully disconnected");
                }

                @Override
                public void onFailure(int i) {
                    Log.d("FAILIRE", "Couldn't disconnect for reason: " + i);
                }
            });
        }
    }

    private void startRegistration() {
        mManager.clearLocalServices(mChannel, new WifiP2pManager.ActionListener() {
            @Override
            public void onSuccess() {
                // Service information.  Pass it an instance name, service type
                // _protocol._transportlayer , and the map containing
                // information other devices will want once they connect to this one.
                final WifiP2pDnsSdServiceInfo serviceInfo =
                        WifiP2pDnsSdServiceInfo.newInstance("_test", "_presence._tcp", record);

                // Add the local service, sending the service info, network channel,
                // and listener that will be used to indicate success or failure of
                // the request.
                mManager.addLocalService(mChannel, serviceInfo, new WifiP2pManager.ActionListener() {
                    @Override
                    public void onSuccess() {
                        Log.d("SERVICE", "Service added to network");
                        Log.d("SERVICE", serviceInfo.toString());
                        // Command successful! Code isn't necessarily needed here,
                        // Unless you want to update the UI or add logging statements.
                    }

                    @Override
                    public void onFailure(int arg0) {
                        // Command failed.  Check for P2P_UNSUPPORTED, ERROR, or BUSY
                    }
                });
            }

            @Override
            public void onFailure(int i) {

            }
        });
    }

    private void discoverService() {
        WifiP2pManager.DnsSdTxtRecordListener txtListener = new WifiP2pManager.DnsSdTxtRecordListener() {
            @Override
        /* Callback includes:
         * fullDomain: full domain name: e.g "printer._ipp._tcp.local."
         * record: TXT record dta as a map of key/value pairs.
         * device: The device running the advertised service.
         */

            public void onDnsSdTxtRecordAvailable(
                    String fullDomain, Map record, WifiP2pDevice device) {
                Log.d("SERVICE", "DnsSdTxtRecord available -" + record.toString());
            }
        };

        WifiP2pManager.DnsSdServiceResponseListener servListener = new WifiP2pManager.DnsSdServiceResponseListener() {
           public void onDnsSdServiceAvailable(String instanceName, String registrationType,
                                               WifiP2pDevice resourceType) {}

        };

        mManager.setDnsSdResponseListeners(mChannel, servListener, txtListener);

        WifiP2pServiceRequest serviceRequest = WifiP2pDnsSdServiceRequest.newInstance();
        mManager.addServiceRequest(mChannel,
                serviceRequest,
                new WifiP2pManager.ActionListener() {
                    @Override
                    public void onSuccess() {
                        // Success!
                    }

                    @Override
                    public void onFailure(int code) {
                        // Command failed.  Check for P2P_UNSUPPORTED, ERROR, or BUSY
                    }
                });


        mManager.discoverServices(mChannel, new WifiP2pManager.ActionListener(){
            @Override
            public void onSuccess() {
                discoverService();
            }

            @Override
            public void onFailure(int code) {}
        });
    }

}
