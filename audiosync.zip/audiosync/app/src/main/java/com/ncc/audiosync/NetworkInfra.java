package com.ncc.audiosync;

import android.os.AsyncTask;
import android.util.Log;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;


class HandleMessage implements Runnable {
    String message;
    InetAddress client;
    MainActivity mActivity;

    public HandleMessage(String message, InetAddress client, MainActivity mActivity){
        this.message = message;
        this.client = client;
        this.mActivity = mActivity;
    }

    @Override
    public void run() {
        mActivity.getNetworkFunctions().receive(this.message, this.client);
    }
}

class ServerThread extends Thread {
    MainActivity mActivity;

    public ServerThread(MainActivity mActivity){
        super();
        this.mActivity = mActivity;
    }

    public void run(){
        try {
            /**
             * Create a server socket and wait for client connections. This
             * call blocks until a connection is accepted from a client
             */
            ServerSocket serverSocket = new ServerSocket(MainActivity.PORT);
            Log.d("SERVER", "Server socket opened!");

            while(true) {
                Socket clientSocket = serverSocket.accept();
                Log.d("SERVER", "Client Accepted!");

                DataInputStream dIn = new DataInputStream(clientSocket.getInputStream());
                String message = dIn.readUTF();
                InetAddress client = clientSocket.getInetAddress();

                mActivity.runOnUiThread(new HandleMessage(message, client, mActivity));

                dIn.close();
                clientSocket.close();
            }
        } catch (IOException e) {
            Log.d("ERROR", e.getMessage().toString() + "!");
        }
    }
}

class ClientAsyncTask extends AsyncTask<Void, Void, String> {
    private InetAddress mHostAddress;
    private String msg;

    public ClientAsyncTask(String msg, InetAddress hostAddress) {
        super();
        this.msg = msg;
        this.mHostAddress = hostAddress;
    }

    protected String doInBackground(Void... params) {
        Socket socket = new Socket();

        try {
            socket.bind(null);
            socket.connect(new InetSocketAddress(mHostAddress.getHostAddress(), MainActivity.PORT),
                    5000);
            DataOutputStream dOut = new DataOutputStream(socket.getOutputStream());
            dOut.writeUTF(msg);
            dOut.flush();
            socket.close();
            Log.d("CLIENT", "Message sent");
            return null;
        } catch (IOException e) {
            Log.d("FAILURE", e.toString());
            Log.d("FAILURE", e.getStackTrace().toString());
            e.printStackTrace();
            try {
                socket.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
        return null;
    }
}
